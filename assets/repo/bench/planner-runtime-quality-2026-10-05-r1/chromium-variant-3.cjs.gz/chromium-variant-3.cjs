/*!
 * NWSAPI 2.3.0-prerelease - Fast CSS Selectors API Engine
 * Copyright (c) 2007-2026 Diego Perini
 * See https://github.com/dperini/nwsapi
 */
function _array_like_to_array(arr, len) {
	if (len == null || len > arr.length) len = arr.length
	for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]
	return arr2
}
function _array_without_holes(arr) {
	if (Array.isArray(arr)) return _array_like_to_array(arr)
}
function _define_property(obj, key, value) {
	if (key in obj) {
		Object.defineProperty(obj, key, {
			value: value,
			enumerable: true,
			configurable: true,
			writable: true
		})
	} else {
		obj[key] = value
	}
	return obj
}
function _iterable_to_array(iter) {
	if ((typeof Symbol !== 'undefined' && iter[Symbol.iterator] != null) || iter['@@iterator'] != null) return Array.from(iter)
}
function _non_iterable_spread() {
	throw new TypeError('Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.')
}
function _object_spread(target) {
	for (var i = 1; i < arguments.length; i++) {
		var source = arguments[i] != null ? arguments[i] : {}
		var ownKeys = Object.keys(source)
		if (typeof Object.getOwnPropertySymbols === 'function') {
			ownKeys = ownKeys.concat(
				Object.getOwnPropertySymbols(source).filter(function (sym) {
					return Object.getOwnPropertyDescriptor(source, sym).enumerable
				})
			)
		}
		ownKeys.forEach(function (key) {
			_define_property(target, key, source[key])
		})
	}
	return target
}
function _to_consumable_array(arr) {
	return _array_without_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array(arr) || _non_iterable_spread()
}
function _unsupported_iterable_to_array(o, minLen) {
	if (!o) return
	if (typeof o === 'string') return _array_like_to_array(o, minLen)
	var n = Object.prototype.toString.call(o).slice(8, -1)
	if (n === 'Object' && o.constructor) n = o.constructor.name
	if (n === 'Map' || n === 'Set') return Array.from(n)
	if (n === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen)
}
;(function Export(global, factory) {
	'use strict'
	// Load shims before the library. All engines share these startup references.
	var uncurryThis = Function.prototype.bind.bind(Function.prototype.call),
		FunctionPrototypeToString = uncurryThis(Function.prototype.toString),
		nativePattern = RegExp(
			'^' +
				FunctionPrototypeToString(Object.prototype.hasOwnProperty)
					.replace(/[\\^$.*+?()[\]{}|]/g, function (character) {
						return '\\' + character
					})
					.replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, function (_match, keyword) {
						return (keyword || '') + '.*?'
					}) +
				'$'
		),
		isNative = function (value) {
			if (typeof value != 'function') {
				return false
			}
			try {
				return nativePattern.test(FunctionPrototypeToString(value))
			} catch (_error) {
				return false
			}
		},
		StringPrototypeIncludes = String.prototype.includes,
		StringFromCodePoint = String.fromCodePoint,
		ObjectPrototypeHasOwnProperty = Object.prototype.hasOwnProperty,
		primordials = {
			MapCtor: typeof Map == 'function' ? Map : undefined,
			WeakMapCtor: typeof WeakMap == 'function' ? WeakMap : undefined,
			WeakRefCtor: typeof WeakRef == 'function' ? WeakRef : undefined,
			FinalizationRegistryCtor: typeof FinalizationRegistry == 'function' ? FinalizationRegistry : undefined,
			// oxlint-disable-next-line compat/compat -- A missing Symbol or iterator disables iteration support.
			SymbolIterator: typeof Symbol == 'function' ? Symbol.iterator : undefined,
			StringPrototypeIncludes: isNative(StringPrototypeIncludes) ? uncurryThis(StringPrototypeIncludes) : undefined,
			StringFromCharCode: String.fromCharCode,
			StringFromCodePoint: isNative(StringFromCodePoint) ? StringFromCodePoint : undefined,
			ObjectCreate: Object.create,
			ObjectDefineProperty: Object.defineProperty,
			ObjectDefineProperties: Object.defineProperties,
			ObjectPrototypeHasOwnProperty: uncurryThis(ObjectPrototypeHasOwnProperty),
			ArrayPrototypeSlice: uncurryThis(Array.prototype.slice)
		}
	// Ordinary shims cannot provide weak ownership. Disable those optimizations.
	if (!isNative(primordials.WeakRefCtor)) {
		primordials.WeakRefCtor = undefined
	}
	if (!isNative(primordials.FinalizationRegistryCtor)) {
		primordials.FinalizationRegistryCtor = undefined
	}
	var mapNames = ['MapCtor', 'WeakMapCtor']
	{
		validateMapConstructors()
	}
	primordials.ObjectDefineProperty(factory, '_primordials', {
		value: primordials
	})
	primordials.ObjectDefineProperty(factory, '_core', {
		value: (function () {
			var core = (function (exports1) {
				//#region src/core/state/create.mts
				function createState(global, Factory) {
					return new initializeState(global, Factory)
				}
				var initializeState = function (global, Factory) {
					this.global = global
					this.Factory = Factory
					this.version = void 0
					this.primordials = void 0
					this.hostReaders = void 0
					this.doc = void 0
					this.root = void 0
					this.ELEMENT_PROTO = void 0
					this.sliceCall = void 0
					this.CFG = void 0
					this.REX = void 0
					this.STD = void 0
					this.Patterns = void 0
					this.reLinkName = void 0
					this.qsNotArgs = void 0
					this.qsInvalid = void 0
					this.reNthElem = void 0
					this.reNthType = void 0
					this.reOptimizer = void 0
					this.reSimpleId = void 0
					this.reValidator = void 0
					this.Config = void 0
					this.legacyHooks = void 0
					this.createWeakMap = void 0
					this.NAMESPACE = void 0
					this.QUIRKS_MODE = void 0
					this.HTML_DOCUMENT = void 0
					this.ATTR_STD_OPS = void 0
					this.HTML_TABLE = void 0
					this.Combinators = void 0
					this.Selectors = void 0
					this.Operators = void 0
					this.concatCall = void 0
					this.concatList = void 0
					this.CACHE_LIMIT = void 0
					this.createCache = void 0
					this.toNodeList = void 0
					this.isInstanceOf = void 0
					this.documentOrder = void 0
					this.mergeResults = void 0
					this.hasDupes = void 0
					this.unique = void 0
					this.switchContext = void 0
					this.codePointToUTF16 = void 0
					this.stringFromCodePoint = void 0
					this.escapeIdentifier = void 0
					this.unescapeIdentifier = void 0
					this.splitList = void 0
					this.matchLogical = void 0
					this.matchNth = void 0
					this.normalizeCombinators = void 0
					this.method = void 0
					this.fetch = void 0
					this.byIdRaw = void 0
					this.byId = void 0
					this.byTagNS = void 0
					this.typeRoutes = void 0
					this.byTags = void 0
					this.collectionRoots = void 0
					this.collectionStates = void 0
					this.collectionSnapshot = void 0
					this.collectionCopy = void 0
					this.asciiLower = void 0
					this.matchesTag = void 0
					this.hasClass = void 0
					this.foreignTypeRoots = void 0
					this.hasForeignTypes = void 0
					this.byTag = void 0
					this.byClass = void 0
					this.attributeValueNS = void 0
					this.hasAttributeNS = void 0
					this.includes = void 0
					this.attrOf = void 0
					this.hasAttrOf = void 0
					this.tagOf = void 0
					this.idOf = void 0
					this.upOf = void 0
					this.nextOf = void 0
					this._prevOf = void 0
					this.firstOf = void 0
					this.attrNamesOf = void 0
					this.connectedOf = void 0
					this.modernReaders = void 0
					this.useLegacy = void 0
					this.classOf = void 0
					this.readDirect = void 0
					this.readGuarded = void 0
					this.nthElement = void 0
					this.nthFiltered = void 0
					this.nthOfType = void 0
					this.ancestorMasks = void 0
					this.lastMaskNode = void 0
					this.lastMaskValue = void 0
					this.tagBits = void 0
					this.tagBitCount = void 0
					this.tagBit = void 0
					this.ancestorMask = void 0
					this.FILTER_SAMPLE = void 0
					this.FILTER_KEEP = void 0
					this.FILTER_RETRY = void 0
					this.mayMatch = void 0
					this.clearAncestorMasks = void 0
					this.isHTML = void 0
					this.isDefined = void 0
					this.isRequired = void 0
					this.isContentEditable = void 0
					this.isDisabled = void 0
					this.isFocusable = void 0
					this.matchesNative = void 0
					this.matchingNative = void 0
					this.matcherDoc = void 0
					this.matcherRecord = void 0
					this.matcherCache = void 0
					this.isOpen = void 0
					this.isClosed = void 0
					this.fullscreenState = void 0
					this.isFullscreen = void 0
					this.isModal = void 0
					this.isPictureInPicture = void 0
					this.isPopoverOpen = void 0
					this.isLink = void 0
					this.isMediaState = void 0
					this.configure = void 0
					this.errors = void 0
					this.emit = void 0
					this.initialize = void 0
					this.setIdentifierSyntax = void 0
					this.compilePrefixes = void 0
					this.F_INIT = void 0
					this.S_HEAD = void 0
					this.M_HEAD = void 0
					this.N_HEAD = void 0
					this.S_LOOP = void 0
					this.M_LOOP = void 0
					this.N_LOOP = void 0
					this.S_BODY = void 0
					this.M_BODY = void 0
					this.N_BODY = void 0
					this.S_TAIL = void 0
					this.M_TAIL = void 0
					this.N_TAIL = void 0
					this.S_TEST = void 0
					this.M_TEST = void 0
					this.N_TEST = void 0
					this.S_VARS = void 0
					this.M_VARS = void 0
					this.N_VARS = void 0
					this.canReuseAncestor = void 0
					this.compile = void 0
					this.isCompound = void 0
					this.validateLogical = void 0
					this.prepareHas = void 0
					this.readPseudo = void 0
					this.isIdent = void 0
					this.hasPseudoElement = void 0
					this.treePseudo = void 0
					this.validPseudoElement = void 0
					this.isPseudoExtension = void 0
					this.validPseudoStates = void 0
					this.validPseudoTail = void 0
					this.validPseudoSyntax = void 0
					this.hasHost = void 0
					this.prepareCompound = void 0
					this.shadowRootOf = void 0
					this.shadowParent = void 0
					this.isHost = void 0
					this.hasSlotted = void 0
					this.directionality = void 0
					this.isDirection = void 0
					this.isLanguage = void 0
					this.validBlocks = void 0
					this.notFlag = void 0
					this.codeFactories = void 0
					this.compileSelector = void 0
					this.ancestor = void 0
					this.match_assert = void 0
					this.match_collect = void 0
					this.prepareForgiving = void 0
					this.forgivingKey = void 0
					this.matchForgivingKey = void 0
					this.matchPreparedForgiving = void 0
					this.selectorComments = void 0
					this.stringContinuations = void 0
					this.parse = void 0
					this.match = void 0
					this.matchPublic = void 0
					this.matchForgiving = void 0
					this.forgivingResolvers = void 0
					this.selectorGeneration = void 0
					this.hasChild = void 0
					this.hasCandidates = void 0
					this.has = void 0
					this.firstMatch = void 0
					this.firstRoots = void 0
					this.firstClass = void 0
					this.first = void 0
					this.firstCompiled = void 0
					this.DESCENT_PROBE = void 0
					this.childPlans = void 0
					this.chainPlans = void 0
					this.selectChildren = void 0
					this.partCounts = void 0
					this.reTagChain = void 0
					this.reSiblingChain = void 0
					this.reChildRoute = void 0
					this.reChainPart = void 0
					this.fetchLevel = void 0
					this.countPart = void 0
					this.descendChain = void 0
					this.parseChain = void 0
					this.siblingChain = void 0
					this.parseSiblingChain = void 0
					this.descentDeclined = void 0
					this.siblingDeclined = void 0
					this.select = void 0
					this.optimize = void 0
					this.collect = void 0
					this.hoverWanted = void 0
					this.hoverTracked = void 0
					this.hoverDoc = void 0
					this.hoverRecord = void 0
					this.hoverChanged = void 0
					this.trackHover = void 0
					this._closest = void 0
					this._matches = void 0
					this._querySelector = void 0
					this._querySelectorAll = void 0
					this._querySelectorDoc = void 0
					this._querySelectorAllDoc = void 0
					this.argsWith = void 0
					this.install = void 0
					this.uninstall = void 0
					this.none = void 0
					this.lastContext = void 0
					this.matchLambdas = void 0
					this.selectLambdas = void 0
					this.matchResolvers = void 0
					this.selectResolvers = void 0
					this.firstResolvers = void 0
					this.hasPlans = void 0
					this.Snapshot = void 0
					this.Dom = void 0
				}
				//#endregion
				//#region src/core/ancestor/closest.mts
				function ancestor(engine, selectors, element, callback) {
					if (element && element.ownerDocument !== engine.doc) engine.switchContext(element)
					if (!element) {
						engine.parse(selectors, true)
						return null
					}
					var resolvers = closestPlan(engine, selectors, callback),
						planDocument = engine.doc,
						planGeneration = engine.selectorGeneration,
						planLegacy = engine.Config.LEGACY,
						planForgiving = engine.Config.FORGIVING,
						planVerbosity = engine.Config.VERBOSITY,
						previousScope = engine.Snapshot.from,
						scope = element || engine.doc
					engine.Snapshot.from = scope
					try {
						while (element) {
							if (element.ownerDocument !== engine.doc) {
								engine.switchContext(element)
								engine.Snapshot.from = scope
							}
							if (
								engine.doc !== planDocument ||
								engine.selectorGeneration !== planGeneration ||
								engine.Config.LEGACY !== planLegacy ||
								engine.Config.FORGIVING !== planForgiving ||
								engine.Config.VERBOSITY !== planVerbosity
							) {
								resolvers = closestPlan(engine, selectors, callback)
								planDocument = engine.doc
								planGeneration = engine.selectorGeneration
								planLegacy = engine.Config.LEGACY
								planForgiving = engine.Config.FORGIVING
								planVerbosity = engine.Config.VERBOSITY
							}
							if (engine.match_assert(resolvers, element, callback)) break
							element = engine.upOf(element)
						}
						return element
					} finally {
						engine.Snapshot.from = previousScope
					}
				}
				function closestPlan(engine, selectors, callback) {
					var key = 'closest:' + (callback ? 'true:' : 'false:') + selectors,
						plan = engine.matchResolvers.get(key)
					if (!plan) {
						var parsed = engine.parse(selectors, true)
						plan = parsed ? engine.match_collect(parsed, callback) : []
						engine.matchResolvers.set(key, plan)
					}
					return plan
				}
				//#endregion
				//#region src/core/match/selector.mts
				function match_assert(_engine, f, element, callback) {
					for (var i = 0, l = f.length, r = false; l > i; ++i)
						if (f[i](element, callback, null, false)) {
							if (!callback) return true
							r = true
						}
					return r
				}
				function match_collect(engine, selectors, callback) {
					for (var i = 0, l = selectors.length || 0, f = Array(l); l > i; ++i) f[i] = engine.compile(selectors[i], false, callback)
					return f
				}
				function match(engine, selectors, element, callback) {
					if (arguments.length - 1 === 0) {
						engine.emit(engine.qsNotArgs, TypeError)
						return false
					}
					var resolver,
						cacheKey = !!callback + ':' + selectors
					if (element && element.ownerDocument !== engine.doc) engine.switchContext(element)
					if (element && (resolver = engine.matchResolvers.get(cacheKey))) return engine.match_assert(resolver, element, callback)
					resolver = engine.match_collect(engine.parse(selectors, false), callback)
					engine.matchResolvers.set(cacheKey, resolver)
					return engine.match_assert(resolver, element, callback)
				}
				function matchPublic(engine, selectors, element, callback) {
					if (arguments.length - 1 === 0) {
						engine.emit(engine.qsNotArgs, TypeError)
						return false
					}
					if (element && element.ownerDocument !== engine.doc) engine.switchContext(element)
					var previousScope = engine.Snapshot.from
					engine.Snapshot.from = element || engine.doc
					try {
						return engine.match(selectors, element, callback)
					} finally {
						engine.Snapshot.from = previousScope
					}
				}
				function matchForgiving(engine, list, element) {
					for (var i = 0, l = list.length; l > i; ++i)
						try {
							if (engine.match(list[i], element)) return true
						} catch (e) {}
					return false
				}
				function prepareForgiving(engine, selectors) {
					var selectVars = engine.S_VARS
					var matchVars = engine.M_VARS
					var nodeVars = engine.N_VARS
					var previousErrors = engine.errors
					var key = JSON.stringify([
							engine.selectorGeneration,
							engine.Config.FORGIVING,
							engine.Config.VERBOSITY,
							engine.Config.LEGACY,
							engine.HTML_DOCUMENT,
							engine.QUIRKS_MODE,
							engine.NAMESPACE,
							selectors
						]),
						resolvers = engine.forgivingResolvers.get(key)
					if (resolvers) return resolvers
					engine.S_VARS = []
					engine.M_VARS = []
					engine.N_VARS = []
					resolvers = Array(selectors.length)
					try {
						for (var length = selectors.length, i = 0; i < length; ++i) {
							engine.errors = previousErrors
							if (!selectors[i]) {
								resolvers[i] = null
								continue
							}
							try {
								var parsed = engine.parse(selectors[i], false)
								if (!parsed) {
									resolvers[i] = null
									continue
								}
								var branches = engine.match_collect(parsed, void 0)
								resolvers[i] = branches
							} catch (unused) {
								resolvers[i] = null
							}
							if (engine.errors !== previousErrors) {
								resolvers[i] = null
								engine.errors = previousErrors
							}
						}
					} finally {
						engine.S_VARS = selectVars
						engine.M_VARS = matchVars
						engine.N_VARS = nodeVars
						engine.errors = previousErrors
					}
					return engine.forgivingResolvers.set(key, resolvers)
				}
				function matchPreparedForgiving(engine, resolvers, element) {
					for (var length = resolvers.length, i = 0; i < length; ++i) {
						var resolver = resolvers[i]
						if (resolver)
							try {
								if (engine.match_assert(resolver, element, void 0)) return true
							} catch (unused) {}
					}
					return false
				}
				function forgivingKey(engine, selectors) {
					var key = JSON.stringify([
							engine.selectorGeneration,
							engine.Config.FORGIVING,
							engine.Config.VERBOSITY,
							engine.Config.LEGACY,
							engine.HTML_DOCUMENT,
							engine.QUIRKS_MODE,
							engine.NAMESPACE,
							selectors
						]),
						resolvers = engine.forgivingResolvers.get(key)
					if (!resolvers) {
						resolvers = engine.prepareForgiving(selectors)
						engine.forgivingResolvers.set(key, resolvers)
					}
					return key
				}
				function matchForgivingKey(engine, key, element) {
					var resolvers = engine.forgivingResolvers.get(key)
					if (!resolvers) {
						var profile = JSON.parse(key)
						resolvers = engine.prepareForgiving(profile[7])
						engine.forgivingResolvers.set(key, resolvers)
					}
					return engine.matchPreparedForgiving(resolvers, element)
				}
				//#endregion
				//#region src/core/predicate/string-quote.mts
				function isStringQuote(char) {
					return char === '"' || char === "'"
				}
				//#endregion
				//#region src/core/parser/token-boundary.mts
				function joinsSelectorTokens(before, after) {
					return (
						(/[\w\u0080-\uffff-]/.test(before) && /[\w\u0080-\uffff(\\-]/.test(after)) ||
						(before == '#' && /[\w\u0080-\uffff\\-]/.test(after)) ||
						(/[~|^$*]/.test(before) && after == '=')
					)
				}
				//#endregion
				//#region src/core/parser/comments.mts
				function selectorComments(engine, text) {
					if (!engine.includes(text, '/*')) return text
					var result = '',
						quote = '',
						i = 0,
						end,
						c,
						before,
						after,
						escapedEnd = -1,
						hex
					while (i < text.length) {
						c = text[i++]
						if (c == '\\') {
							hex = /^[0-9a-fA-F]{1,6}/.exec(text.slice(i))
							consumeHexEscape()
						} else if (quote) {
							result += c
							if (c == quote) quote = ''
						} else if (isStringQuote(c)) {
							quote = c
							result += c
						} else if (c == '/' && text[i] == '*') consumeComment()
						else result += c
					}
					return result
					function consumeComment() {
						end = text.indexOf('*/', i + 1)
						i = end < 0 ? text.length : end + 2
						while (text.slice(i, i + 2) == '/*') {
							end = text.indexOf('*/', i + 2)
							i = end < 0 ? text.length : end + 2
						}
						before = result.length == escapedEnd ? 'a' : result[result.length - 1] || ''
						after = text[i] || ''
						if (/:nth-(?:last-)?child\([^()]*[\t\n\f\r ]of$/i.test(result)) result += ' '
						else if (joinsSelectorTokens(before, after))
							result +=
								(/^of(?:[\t\n\f\r ]|\/\*)/i.test(text.slice(i)) && /:nth-(?:last-)?child\([^()]*$/i.test(result)) ||
								(/^[is](?:[\t\n\f\r ]|\])/i.test(text.slice(i)) && /\[[^\]]*=[^\]]+$/i.test(result))
									? ' '
									: ''
					}
					function consumeHexEscape() {
						if (!quote && hex) {
							result += '\\' + ('000000' + hex[0]).slice(-6) + ' '
							i += hex[0].length
							if (/[\t\n\r\f ]/.test(text[i] || '')) {
								if (text[i++] == '\r' && text[i] == '\n') ++i
							}
							escapedEnd = result.length
						} else {
							result += c
							if (i < text.length) result += text[i++]
						}
					}
				}
				//#endregion
				//#region src/core/parser/string.mts
				function stringContinuations(_engine, selectors) {
					if (!/[\r\n\f]/.test(selectors)) return selectors
					var i = 0,
						j,
						c,
						next,
						quote = '',
						result = '',
						length = selectors.length
					while (i < length) {
						c = selectors[i++]
						if (c == '\\' && i == length && quote) break
						if (c == '\\' && i < length) {
							next = selectors[i]
							if (quote && /[\r\n\f]/.test(next)) {
								++i
								if (next == '\r' && selectors[i] == '\n') ++i
								continue
							}
							if (quote && /[0-9a-f]/i.test(next)) {
								consumeStringEscape()
								continue
							}
							result += c + selectors[i++]
							continue
						}
						updateStringQuote()
						result += c
					}
					return result + quote
					function updateStringQuote() {
						if (c == quote) quote = ''
						else if (!quote && isStringQuote(c)) quote = c
					}
					function consumeStringEscape() {
						j = i
						while (i < length && i - j < 6 && /[0-9a-f]/i.test(selectors[i])) ++i
						result += '\\' + ('000000' + selectors.slice(j, i)).slice(-6)
						consumeContinuation()
					}
					function consumeContinuation() {
						if (/[\x20\t\r\n\f]/.test(selectors[i] || '')) {
							next = selectors[i++]
							if (next == '\r' && selectors[i] == '\n') ++i
						}
					}
				}
				//#endregion
				//#region src/core/ancestor/mask.mts
				var TAG_BIT_LIMIT = 256
				function tagBit(engine, name) {
					if (engine.HTML_DOCUMENT) name = engine.asciiLower(name)
					var i = 0,
						l = name.length,
						h = 0,
						bit = engine.tagBits[name]
					if (bit !== void 0) return bit
					for (; l > i; ++i) h = (h * 31 + name.charCodeAt(i)) | 0
					bit = 1 << (h & 31)
					if (engine.tagBitCount >= TAG_BIT_LIMIT) {
						engine.tagBits = engine.primordials.ObjectCreate(null)
						engine.tagBitCount = 0
					}
					++engine.tagBitCount
					return (engine.tagBits[name] = bit)
				}
				function ancestorMask(engine, node) {
					if (engine.ancestorMasks === null) engine.ancestorMasks = engine.createWeakMap()
					var i,
						mask,
						chain = [],
						parent = node.parentElement
					if (parent === engine.lastMaskNode) return engine.lastMaskValue
					while (parent) {
						mask = engine.ancestorMasks.get(parent)
						if (mask !== void 0) break
						chain[chain.length] = parent
						parent = parent.parentElement
					}
					mask = mask === void 0 ? 0 : mask | engine.tagBit(parent.localName)
					for (i = chain.length - 1; i > -1; --i) {
						engine.ancestorMasks.set(chain[i], mask)
						mask |= engine.tagBit(chain[i].localName)
					}
					engine.lastMaskNode = node.parentElement
					engine.lastMaskValue = mask
					return mask
				}
				function mayMatch(engine, node, mask, state) {
					if (state.rest > 0) {
						--state.rest
						return true
					}
					var keep = (engine.ancestorMask(node) & mask) === mask
					if (keep) ++state.kept
					if (++state.seen === engine.FILTER_SAMPLE) {
						if (state.kept >= engine.FILTER_KEEP) state.rest = engine.FILTER_RETRY
						state.seen = 0
						state.kept = 0
					}
					return keep
				}
				function clearAncestorMasks(engine) {
					engine.ancestorMasks = null
					engine.lastMaskNode = null
					engine.lastMaskValue = 0
					return true
				}
				//#endregion
				//#region src/core/predicate/element.mts
				function isHTML(_engine, node) {
					var doc = node.ownerDocument || node
					return doc.nodeType == 9 && 'contentType' in doc ? doc.contentType.indexOf('/html') > 0 : doc.createElement('DiV').localName == 'div'
				}
				function isDefined(engine, element) {
					var native,
						custom,
						name = engine.tagOf(element),
						registry,
						view
					if (element.namespaceURI !== 'http://www.w3.org/1999/xhtml') return true
					native = engine.matchesNative(element, ':defined', void 0)
					if (native !== void 0) return native
					if (name.indexOf('-') < 0) {
						if (!engine.hasAttrOf(element, 'is')) return true
						name = engine.attrOf(element, 'is') || name
					}
					view = element.ownerDocument.defaultView
					registry = view && view.customElements
					if (!registry || !registry.get) return false
					custom = registry.get(name)
					return !!custom && element instanceof custom
				}
				function isRequired(engine, node) {
					return (
						!!node.required &&
						(/^(select|textarea)$/.test(engine.tagOf(node)) ||
							(engine.tagOf(node) == 'input' && !/^(hidden|range|color|button|submit|reset|image)$/.test(node.type)))
					)
				}
				//#endregion
				//#region src/core/compile/position/filtered.mts
				function nthFiltered(engine, element, selector, reverse, state) {
					var parent = element.parentNode || element,
						siblings = state && (state.parent === parent ? state.siblings : state.parents && state.parents.get(parent)),
						resolvers,
						child,
						index
					siblings = collectFilteredSiblings()
					if (state) {
						state.parent = parent
						state.siblings = siblings
					}
					index = siblings.positions ? siblings.positions.get(element) || 0 : siblings.nodes.indexOf(element) + 1
					return index && reverse ? siblings.nodes.length - index + 1 : index
					function collectFilteredSiblings() {
						if (!siblings) {
							siblings = {
								nodes: [],
								positions: engine.createWeakMap()
							}
							resolvers = engine.matchResolvers.get('false:' + selector)
							if (!resolvers) {
								resolvers = engine.match_collect(engine.parse(selector, false), void 0)
								engine.matchResolvers.set('false:' + selector, resolvers)
							}
							child = element.parentNode ? engine.firstOf(parent) : element
							while (child) {
								if (engine.match_assert(resolvers, child, void 0)) {
									siblings.nodes[siblings.nodes.length] = child
									siblings.positions && siblings.positions.set(child, siblings.nodes.length)
								}
								child = engine.nextOf(child)
							}
							if (state) {
								state.parents || (state.parents = engine.createWeakMap())
								state.parents && state.parents.set(parent, siblings)
							}
						}
						return siblings
					}
				}
				//#endregion
				//#region src/core/compile/adjacent.mts
				function compileAdjacent(state) {
					state.firstChildOnly = false
					state.match = state.selector.match(state.engine.Patterns['adjacent'])
					state.ancestry.pending.length = 0
					if (state.pendingTag) {
						state.source = state.pendingTag + state.source + '}'
						state.pendingTag = ''
					}
					state.source = 'var N' + state.k + '=e;if(e&&(e=' + state.read.prev('e') + ')){' + state.source + '}e=N' + state.k + ';'
				}
				//#endregion
				//#region src/core/compile/ancestor.mts
				function compileAncestor(state) {
					state.firstChildOnly = false
					state.match = state.selector.match(state.engine.Patterns['ancestor'])
					state.ancestry.required.push.apply(state.ancestry.required, state.ancestry.pending)
					state.ancestry.pending.length = 0
					state.ancestry.walk = true
					if (state.pendingTag) {
						state.source = state.pendingTag + state.source + '}'
						state.pendingTag = ''
					}
					if (state.ancestry.reuse) {
						state.source =
							'var N' +
							state.k +
							'=e;if((e=e&&' +
							state.read.up('e') +
							')===_pStart){if(_pResult){' +
							state.ancestry.reuse +
							'}}else{_pStart=e;_pResult=true;while(e){' +
							state.source +
							'e=' +
							state.read.up('e') +
							';}_pResult=false;}e=N' +
							state.k +
							';'
						return
					}
					state.source =
						'var N' +
						state.k +
						'=e;while(e&&(e=' +
						(state.shadow ? 's.shadowParent(e,x||(c.nodeType?c:s.from))' : state.read.up('e')) +
						')){' +
						state.source +
						'}e=N' +
						state.k +
						';'
				}
				//#endregion
				//#region src/core/compile/attribute/condition.mts
				function attributeCondition(state) {
					return (
						state.attributeGuard +
						'if((' +
						(state.attributeGuard && state.match[2] ? 'n!==null&&' : '') +
						(!state.match[2]
							? state.NS
								? 's.hasAttributeNS(e,"' + state.name + '")'
								: state.attributeGuard
									? 'n!==null'
									: state.read.has('e', state.name)
							: !state.match[4] && state.engine.ATTR_STD_OPS[state.match[2]] && state.match[2] != '~='
								? state.attributeSource + '==""'
								: state.match[2] == '=' && state.type == '' && state.test.p3 == 'true'
									? state.attributeSource + '=="' + state.value + '"'
									: '(' +
										state.attributePattern +
										').test(' +
										(state.match[2] == '~=' && state.test.p3 == 'true' ? '(' + state.attributeSource + '||"")' : state.attributeSource) +
										')==' +
										state.test.p3) +
						')){' +
						state.source +
						'}'
					)
				}
				//#endregion
				//#region src/core/compile/attribute/compile.mts
				function compileAttribute(state) {
					var normalizeAttributeValueDone = false
					var normalizeAttributeValueValue
					state.match = state.selector.match(state.engine.Patterns['attribute'])
					if (!state.match) return
					state.NS = /^\[[\t\n\f\r ]*\*\|/.test(state.match[0])
					state.name = state.match[1]
					var parts = state.engine.unescapeIdentifier(state.name).split(':')
					state.expr = parts.length == 2 ? parts[1] : parts[0]
					state.name = state.engine.escapeIdentifier(state.name).replace(/\\.|\x22/g, function (part) {
						return part == '"' ? '\\"' : part
					})
					state.attributeSource = state.read.attr('e', state.name)
					state.attributeGuard = ''
					if (!state.NS && (!state.engine.HTML_DOCUMENT || /^\[[\t\n\f\r ]*\|/.test(state.match[0]))) {
						state.attributeSource = 'n'
						state.attributeGuard = 'n=s.attributeValueNS(e,"' + state.name + '");'
					}
					cacheSharedAttribute(state)
					if (state.match[2] && !(state.test = state.engine.Operators[state.match[2]])) {
						state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
						return ''
					}
					normalizeAttributeValue()
					if (normalizeAttributeValueDone) return normalizeAttributeValueValue
					prepareAttributePattern()
					if (state.NS && state.match[2]) {
						state.source = 'if(s.hasAttributeNS(e,"' + state.name + '",' + state.attributePattern + ',' + state.test.p3 + ')){' + state.source + '}'
						return
					}
					state.source = attributeCondition(state)
					return
					function prepareAttributePattern() {
						state.match[5] = (state.match[5] || '').toLowerCase()
						state.type =
							state.match[5] == 'i' || (state.match[5] != 's' && state.engine.HTML_DOCUMENT && state.engine.HTML_TABLE[state.expr.toLowerCase()]) ? 'i' : ''
						if (state.match[2]) {
							state.attributePattern = '/' + state.test.p1 + state.match[4] + state.test.p2 + '/'
							state.attributePattern =
								!state.match[5] && state.type == 'i'
									? '(e.namespaceURI=="http://www.w3.org/1999/xhtml"?' + state.attributePattern + 'i:' + state.attributePattern + ')'
									: state.attributePattern + state.type
						}
					}
					function normalizeAttributeValue() {
						if (state.match[4] === '')
							state.test =
								state.match[2] == '~='
									? {
											p1: '(?!)',
											p2: '',
											p3: 'true'
										}
									: state.match[2] in state.engine.ATTR_STD_OPS && state.match[2] != '~='
										? {
												p1: '^',
												p2: '$',
												p3: 'true'
											}
										: state.test
						else if (state.match[2] == '~=' && /[\t\n\f\r ]/.test(state.engine.unescapeIdentifier(state.match[4]))) {
							state.source = 'if(false){' + state.source + '}'
							normalizeAttributeValueValue = void 0
							normalizeAttributeValueDone = true
							return
						} else if (state.match[4]) {
							state.value = state.engine.escapeIdentifier(state.match[4])
							state.match[4] = state.value.replace(state.engine.REX.RegExpChar, '\\$&')
							state.value = state.value.replace(/\\.|\x22/g, function (part) {
								return part == '"' ? '\\"' : part
							})
						}
					}
				}
				function cacheSharedAttribute(state) {
					var _state_compiler
					if (
						state.NS ||
						state.attributeGuard ||
						!((_state_compiler = state.compiler) === null || _state_compiler === void 0 ? void 0 : _state_compiler.sharedAttributes) ||
						!(state.name in state.compiler.sharedAttributes)
					)
						return
					var slot = state.compiler.sharedAttributes[state.name]
					if (!slot) {
						var _state_compiler1
						slot = '_a' + state.compiler.nextIdentifier++
						state.compiler.sharedAttributes[state.name] = slot
						;(_state_compiler1 = state.compiler).variables || (_state_compiler1.variables = [])
						state.compiler.variables.push(slot + '=null', '_v' + slot.slice(2))
					}
					state.attributeSource = '(' + slot + '===e?_v' + slot.slice(2) + ':(' + slot + '=e,_v' + slot.slice(2) + '=' + state.attributeSource + '))'
				}
				//#endregion
				//#region src/core/compile/child.mts
				function compileChild(state) {
					state.firstChildOnly = false
					state.match = state.selector.match(state.engine.Patterns['children'])
					state.ancestry.required.push.apply(state.ancestry.required, state.ancestry.pending)
					state.ancestry.pending.length = 0
					if (state.pendingTag) {
						state.source = state.pendingTag + state.source + '}'
						state.pendingTag = ''
					}
					state.source =
						'var N' +
						state.k +
						'=e;if(e&&(e=' +
						(state.shadow ? 's.shadowParent(e,x||(c.nodeType?c:s.from))' : state.read.up('e')) +
						')){' +
						state.source +
						'}e=N' +
						state.k +
						';'
				}
				//#endregion
				//#region src/core/compile/class.mts
				function compileClass(state) {
					var nested, scan
					state.match = state.selector.match(state.engine.Patterns['className'])
					state.classTests = []
					scan = state.mode === true && !state.engine.QUIRKS_MODE && !!state.ancestry.classes
					do nested = addClassTest(state, scan)
					while (nested)
					state.compat = ''
					buildCompat(state, scan)
					state.source = 'if(' + state.compat + '){' + state.source + '}'
					return
					function addClassTest(state, scan) {
						var raw = state.engine.unescapeIdentifier(state.match[1]),
							argument,
							nested
						state.expr = /[\t\n\f\r ]/.test(raw) ? '(?!)' : state.engine.escapeIdentifier(state.match[1]).replace(state.engine.REX.RegExpChar, '\\$&')
						state.classTests.push(
							scan ? (/[\t\n\f\r ]/.test(raw) ? 'false' : JSON.stringify(raw)) : '/(^|\\s)' + state.expr + '(\\s|$)/' + (state.engine.QUIRKS_MODE ? 'i' : '')
						)
						if (state.compiler && !scan) {
							state.classIndex = state.compiler.classes.indexOf(state.classTests[state.classTests.length - 1])
							if (state.classIndex < 0) {
								state.classIndex = state.compiler.classes.length
								state.compiler.classes.push(state.classTests[state.classTests.length - 1])
							}
							state.classTests[state.classTests.length - 1] = '_c' + state.classIndex
						}
						argument = state.match[state.match.length - 1]
						nested = argument.charAt(0) == '.' && argument.match(state.engine.Patterns['className'])
						if (nested) state.match = nested
						return nested
					}
					function buildCompat(state, scan) {
						for (state.classIndex = state.classTests.length - 1; state.classIndex >= 0; --state.classIndex)
							state.compat +=
								(state.compat ? '&&' : '') +
								(scan
									? scanExpression(state, state.classIndex == state.classTests.length - 1)
									: state.classTests[state.classIndex] +
										'.test(' +
										(state.classIndex == state.classTests.length - 1 ? (state.classTests.length > 1 ? 'n=' : '') + state.read.cls('e') : 'n') +
										')')
					}
					function scanExpression(state, first) {
						var entry = state.classTests[state.classIndex],
							ref = first ? '(n=' + state.read.cls('e') + ')' : 'n'
						if (entry == 'false') return 'false'
						return 's.hasClass(' + ref + ',' + entry + ')'
					}
				}
				//#endregion
				//#region src/core/compile/extension.mts
				function compileExtension(state) {
					state.firstChildOnly = false
					state.match[state.match.length - 1] = '*'
					state.source = state.engine.Combinators[state.selector[0]](state.match) + state.source
				}
				//#endregion
				//#region src/core/compile/id.mts
				function compileId(state) {
					state.match = state.selector.match(state.engine.Patterns['id'])
					state.expr = state.engine.escapeIdentifier(state.match[1]).replace(/\\.|\x22/g, function (part) {
						return part == '"' ? '\\"' : part
					})
					state.source = 'if((' + state.read.id('e') + '=="' + state.expr + '")){' + state.source + '}'
				}
				//#endregion
				//#region src/core/compile/namespace.mts
				function compileNamespace(state) {
					state.match = state.selector.match(state.engine.Patterns['namespace'])
					if (state.match[1] == '*') state.source = 'if(true){' + state.source + '}'
					else if (!state.match[1]) state.source = 'if((!e.namespaceURI)){' + state.source + '}'
					else state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
				}
				//#endregion
				//#region src/core/compile/pseudo/action.mts
				function compilePseudoAction(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'hover':
							state.engine.trackHover()
							state.source = 'if(e===s.HOVER||s.matchesNative(e,":hover")){' + state.source + '}'
							break
						case 'active':
							state.source = 'if(e===s.doc.activeElement){' + state.source + '}'
							break
						case 'focus':
							state.source = 'if(s.isFocusable(e)){' + state.source + '}'
							break
						case 'focus-visible':
							state.source = 'if(s.isFocusable(e)){' + state.source + '}'
							break
						case 'focus-within':
							state.source = 'if(s.matchesNative(e,":focus-within",!!s.doc.hasFocus&&s.doc.hasFocus()&&e.contains(s.doc.activeElement))){' + state.source + '}'
							break
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/display.mts
				function compilePseudoDisplay(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'open':
							state.source = 'if(s.isOpen(e)){' + state.source + '}'
							break
						case 'closed':
							state.source = 'if(s.isClosed(e)){' + state.source + '}'
							break
						case 'modal':
							state.source = 'if(s.isModal(e)){' + state.source + '}'
							break
						case 'fullscreen':
							state.source = 'if(s.isFullscreen(e)){' + state.source + '}'
							break
						case 'picture-in-picture':
							state.source = 'if(s.isPictureInPicture(e)){' + state.source + '}'
							break
						case 'popover':
						case 'popover-open':
							state.source = 'if(s.isPopoverOpen(e)){' + state.source + '}'
							break
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/extension.mts
				function compilePseudoExtension(state) {
					state.expr = false
					state.status = false
					for (var extension in state.engine.Selectors) {
						state.expr = extension
						if ((state.match = state.selector.match(state.engine.Selectors[state.expr].Expression))) {
							state.result = state.engine.Selectors[state.expr].Callback(state.match, state.source, state.mode, state.callback)
							if ('match' in state.result) state.match = state.result.match
							state.vars = state.result.modvar
							if (state.mode) state.vars && state.engine.S_VARS.indexOf(state.vars) < 0 && (state.engine.S_VARS[state.engine.S_VARS.length] = state.vars)
							else state.vars && state.engine.M_VARS.indexOf(state.vars) < 0 && (state.engine.M_VARS[state.engine.M_VARS.length] = state.vars)
							state.source = state.result.source
							state.status = state.result.status
							if (state.status) break
						}
					}
					if (!state.status) {
						state.engine.emit("unknown pseudo-class selector '" + state.selector + "'")
						return ''
					}
					if (!state.expr) {
						state.engine.emit("unknown token in selector '" + state.selector + "'")
						return ''
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/heading.mts
				function compilePseudoHeading(state) {
					if (state.match[1] !== void 0 && !/^[\t\n\f\r ]*[-+]?\d+[\t\n\f\r ]*(?:,[\t\n\f\r ]*[-+]?\d+[\t\n\f\r ]*)*$/.test(state.match[1])) {
						state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
						return ''
					}
					state.test =
						state.match[1] === void 0
							? '123456'
							: state.match[1]
									.split(',')
									.map(function (level) {
										var n = +level
										return n >= 1 && n <= 6 ? n : ''
									})
									.join('')
					state.source = !state.test
						? 'if(false){' + state.source + '}'
						: 'if((n=' +
							state.read.tag('e') +
							')==' +
							state.test
								.split('')
								.map(function (level) {
									return '"h' + level + '"'
								})
								.join('||n==') +
							'){if(e.namespaceURI=="http://www.w3.org/1999/xhtml"){' +
							state.source +
							'}}'
				}
				//#endregion
				//#region src/core/compile/pseudo/input/state.mts
				function compilePseudoInput(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'enabled':
							state.source =
								'n=e.localName;if((("form" in e||("optgroup"==n||/^optgroup$/i.test(n)))&&"disabled" in e&&!s.isDisabled(e))||(n.indexOf("-")>=0&&s.matchesNative(e,":enabled"))){' +
								state.source +
								'}'
							break
						case 'disabled':
							state.source =
								'n=e.localName;if((("form" in e||("optgroup"==n||/^optgroup$/i.test(n)))&&"disabled" in e&&s.isDisabled(e))||(n.indexOf("-")>=0&&s.matchesNative(e,":disabled"))){' +
								state.source +
								'}'
							break
						case 'read-only':
						case '-moz-read-only':
						case 'read-write':
						case '-moz-read-write':
							state.source =
								'n=e.localName;if(' +
								(state.match[1].indexOf('read-only') >= 0 ? '!' : '') +
								'(("input"==n||/^input$/i.test(n))?((e.namespaceURI=="http://www.w3.org/1999/xhtml"&&!e.hasAttribute("type")||s.includes("|date|datetime-local|email|month|number|password|search|tel|text|time|url|week|","|"+e.type+"|"))&&!e.readOnly&&!s.isDisabled(e)):("textarea"==n||/^textarea$/i.test(n))?!e.readOnly&&!s.isDisabled(e):s.isContentEditable(e))){' +
								state.source +
								'}'
							break
						case 'autofill':
						case '-webkit-autofill':
							state.source = 'if(s.matchesNative(e,":autofill")||s.matchesNative(e,":-webkit-autofill")){' + state.source + '}'
							break
						case 'placeholder-shown':
							state.source =
								'n=e.localName;if(((("input"==n||"textarea"==n)||/^(?:input|textarea)$/i.test(n))&&e.hasAttribute("placeholder")&&(s.includes("|textarea|password|number|search|email|text|tel|url|","|"+e.type+"|"))&&e.value=="")){' +
								state.source +
								'}'
							break
						case 'default':
							if (state.engine.S_VARS.indexOf('_t') < 0) state.engine.S_VARS.push('_t')
							if (state.engine.S_VARS.indexOf('_u') < 0) state.engine.S_VARS.push('_u')
							if (state.engine.S_VARS.indexOf('_d') < 0) state.engine.S_VARS.push('_d=0')
							state.source =
								'_u=e.localName;_t=e.type;if(("form" in e&&(o=e.form))){_d=0;n=null;if(_t=="image")n=o.getElementsByTagName("input");_t=="submit"&&(n=o.elements);while(n&&n[_d]&&e!==n[_d]){if(n[_d].type=="image")break;if(n[_d].type=="submit")break;_d++;}}if((o=e.form)&&((n&&e===n[_d])&&s.includes("|image|submit|","|"+_t+"|"))||(("option"==_u||/^option$/i.test(_u))&&e.defaultSelected)||((s.includes("|radio|checkbox|","|"+_t+"|"))&&e.defaultChecked)){' +
								state.source +
								'}'
							break
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/input/value.mts
				function compilePseudoInputValue(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'checked':
							state.source =
								'n=e.localName;if((("input"==n||/^input$/i.test(n))&&(s.includes("|radio|checkbox|","|"+e.type+"|")&&e.checked))||(("option"==n||/^option$/i.test(n))&&(e.selected||e.checked))){' +
								state.source +
								'}'
							break
						case 'indeterminate':
							if (state.engine.S_VARS.indexOf('_t') < 0) state.engine.S_VARS.push('_t')
							state.source =
								'_t=e.type;n=e.localName;if((("progress"==n||/^progress$/i.test(n))&&!e.hasAttribute("value"))||(("input"==n||/^input$/i.test(n))&&("checkbox"==_t&&e.indeterminate&&!e.switch&&!e.hasAttribute("switch"))||("radio"==_t&&e.name&&!s.first("input[name="+e.name+"]:checked",e.form)))){' +
								state.source +
								'}'
							break
						case 'required':
							state.source = 'if(s.isRequired(e)){' + state.source + '}'
							break
						case 'optional':
							state.source =
								'n=e.localName;if((("button"==n||"input"==n||"select"==n||"textarea"==n||/^(?:button|input|select|textarea)$/i.test(n))&&!s.isRequired(e))){' +
								state.source +
								'}'
							break
						case 'invalid':
							state.source =
								'n=e.localName;if((((("form"==n||/^form$/i.test(n))&&!e.noValidate)||(e.willValidate&&!e.formNoValidate))&&!e.checkValidity())||(("fieldset"==n||/^fieldset$/i.test(n))&&s.first(":invalid",e))||(n.indexOf("-")>=0&&s.matchesNative(e,":invalid"))){' +
								state.source +
								'}'
							break
						case 'valid':
							state.source =
								'n=e.localName;if((((("form"==n||/^form$/i.test(n))&&!e.noValidate)||(e.willValidate&&!e.formNoValidate))&&e.checkValidity())||(("fieldset"==n||/^fieldset$/i.test(n))&&!s.first(":invalid",e))||(n.indexOf("-")>=0&&s.matchesNative(e,":valid"))){' +
								state.source +
								'}'
							break
						case 'in-range':
						case 'out-of-range':
							if (state.engine.S_VARS.indexOf('_t') < 0) state.engine.S_VARS.push('_t')
							if (state.engine.S_VARS.indexOf('_u') < 0) state.engine.S_VARS.push('_u')
							state.source =
								'n=e.localName;if(("input"==n||/^input$/i.test(n))&&(e.willValidate&&!e.formNoValidate)&&(_u=e.validity)&&(s.includes("|date|datetime-local|month|number|range|time|week|","|"+(_t=e.type)+"|"))&&' +
								('in-range' == state.match[1] ? '(!_u.rangeUnderflow&&!_u.rangeOverflow)' : '(_u.rangeUnderflow||_u.rangeOverflow)') +
								'&&("range"==_t||e.getAttribute("min")||e.getAttribute("max"))){' +
								state.source +
								'}'
							break
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/linguistic.mts
				function compilePseudoLinguistic(state) {
					state.argument = state.match[2].toLowerCase()
					state.source = 'if(s.isDirection(e,' + JSON.stringify(state.argument) + ')){' + state.source + '}'
				}
				//#endregion
				//#region src/core/compile/pseudo/location.mts
				function compilePseudoLocation(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'any-link':
							state.source = 'if((s.isLink(e)||e.visited)){' + state.source + '}'
							break
						case 'link':
							state.source = 'if(s.isLink(e)){' + state.source + '}'
							break
						case 'visited':
							state.source = 'if((s.isLink(e)&&e.visited)){' + state.source + '}'
							break
						case 'target':
							state.source = 'if(s.doc.location.hash&&e.id&&e.id==s.doc.location.hash.slice(1)&&(s.doc.compareDocumentPosition(e)&16)){' + state.source + '}'
							break
						case 'defined':
							state.source = 'if(s.isDefined(e)){' + state.source + '}'
							break
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
				}
				//#endregion
				//#region src/core/compile/state.mts
				function nextCompileIdentifier(state, prefix) {
					if (state.compiler) return prefix + state.compiler.nextIdentifier++
					return prefix + state.engine.notFlag++
				}
				//#endregion
				//#region src/core/compile/pure.mts
				var token = /* @__PURE__ */ new RegExp(
					'^(?:[.#][_a-zA-Z][-\\w]*|\\[[_a-zA-Z][-\\w]*(?:[~|^$*]?=(?:"[^"\\\\\\r\\n]*"|\'[^\'\\\\\\r\\n]*\'|[_a-zA-Z][-\\w]*))?\\]|[a-zA-Z][-\\w]*|\\*)'
				)
				var separator = /^[\t\n\f\r ]*([>+~]?)[\t\n\f\r ]*/
				function pureCompiler(engine) {
					return !engine.Config.LEGACY && engine.selectorGeneration === 0
				}
				function parsePure(selector) {
					if (!selector || selector.length > 512) return null
					var compounds = []
					var relations = []
					var current = ''
					while (selector) {
						var match = token.exec(selector)
						if (match) {
							if (current && /^[a-zA-Z*]/.test(match[0])) return null
							current += match[0]
							selector = selector.slice(match[0].length)
							continue
						}
						var between = separator.exec(selector)
						if (!current || !between[0]) return null
						compounds.push(current)
						relations.push(between[1] || ' ')
						current = ''
						selector = selector.slice(between[0].length)
					}
					if (!current) return null
					compounds.push(current)
					return {
						compounds: compounds,
						relations: relations
					}
				}
				function pureCompound(selector) {
					var parsed = parsePure(selector)
					return !!parsed && parsed.compounds.length === 1
				}
				function pureSelector(selector) {
					return parsePure(selector) !== null
				}
				//#endregion
				//#region src/core/compile/logical.mts
				function inlineLogical(state, argument, negate) {
					if (!state.compiler || !pureCompiler(state.engine) || argument.length > 512) return false
					var branches = state.engine.splitList(argument)
					if (
						(branches.length === 1 && pureCompound(branches[0])) ||
						(!negate &&
							branches.every(function (branch) {
								return /^[a-z][a-z0-9-]*$/.test(branch)
							}))
					)
						return false
					if (branches.length > 8 || !branches.every(pureSelector)) return false
					var saved = nextCompileIdentifier(state, '_logicalNode')
					var matched = nextCompileIdentifier(state, '_logicalMatch')
					var label = nextCompileIdentifier(state, '_logicalExit')
					var source = ''
					for (var index = 0, length = branches.length; index < length; ++index) {
						var branch = branches[index]
						source += state.engine.compileSelector(branch, matched + '=true;break ' + label + ';', state.mode, state.callback, void 0, state.compiler)
					}
					state.source =
						'var ' +
						saved +
						'=e,' +
						matched +
						'=false;' +
						label +
						':{' +
						source +
						'}e=' +
						saved +
						';if(' +
						(negate ? '!' : '') +
						matched +
						'){' +
						state.source +
						'}'
					return true
				}
				//#endregion
				//#region src/core/compile/relative.mts
				function inlineRelative(state, argument) {
					if (!state.compiler || !pureCompiler(state.engine) || !/^[>+~]/.test(argument)) return false
					var parts = parsePure('*' + argument)
					if (
						!parts ||
						parts.relations.includes(' ') ||
						parts.relations.filter(function (value) {
							return value === '~'
						}).length > 1
					)
						return false
					var saved = nextCompileIdentifier(state, '_relativeNode')
					var matched = nextCompileIdentifier(state, '_relativeMatch')
					var label = nextCompileIdentifier(state, '_relativeExit')
					var source = matched + '=true;break ' + label + ';'
					for (var i = parts.compounds.length - 1; i > 0; --i) {
						var relation = parts.relations[i - 1]
						source = state.engine.compileSelector(parts.compounds[i], source, state.mode, state.callback, void 0, state.compiler)
						if (relation === '+') source = 'if((e=' + state.read.next('e') + ')){' + source + '}'
						else {
							var cursor = nextCompileIdentifier(state, '_relativeCursor')
							var first = relation === '>' ? 's.firstOf(e)' : state.read.next('e')
							source = 'var ' + cursor + '=' + first + ';while(' + cursor + '){e=' + cursor + ';' + source + cursor + '=' + state.read.next(cursor) + ';}'
						}
					}
					state.source = 'var ' + saved + '=e,' + matched + '=false;' + label + ':{' + source + '}e=' + saved + ';if(' + matched + '){' + state.source + '}'
					return true
				}
				//#endregion
				//#region src/core/compile/pseudo/type-union.mts
				function typeUnionCondition(state, tags) {
					var direct = tags.map(function (tag, index) {
						return (index ? 'n' : '(n=' + state.read.tag('e') + ')') + '==' + JSON.stringify(state.engine.HTML_DOCUMENT ? state.engine.asciiLower(tag) : tag)
					})
					if (!state.engine.HTML_DOCUMENT) return direct.join('||')
					var fallback = tags.map(function (tag) {
						return 's.matchesTag(e,' + JSON.stringify(tag) + ')'
					})
					if (state.engine.Config.LEGACY)
						return direct
							.map(function (check, index) {
								return '(' + check + '||' + fallback[index] + ')'
							})
							.join('||')
					return '(' + direct.join('||') + ')||(e.namespaceURI!=' + JSON.stringify(state.engine.NAMESPACE) + '&&(' + fallback.join('||') + '))'
				}
				//#endregion
				//#region src/core/compile/pseudo/logical.mts
				function compilePseudoLogical(state) {
					var compileLogicalCompoundDone = false
					var compileLogicalCompoundValue
					state.match[1] = state.match[1].toLowerCase()
					state.expr = state.match[2].replace(/\x22/g, '\\"')
					switch (state.match[1]) {
						case 'is':
						case 'where':
							if (inlineLogical(state, state.match[2], false)) break
							compileLogicalCompound()
							if (compileLogicalCompoundDone) return compileLogicalCompoundValue
							break
						case 'matches':
							if (!state.engine.validateLogical(state.match[2], false)) return ''
							state.source = 'if(s.match("' + state.expr + '",e)){' + state.source + '}'
							break
						case 'not':
							if (inlineLogical(state, state.match[2], true)) break
							if (state.engine.hasPseudoElement(state.match[2])) {
								state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
								return ''
							}
							if (state.engine.isCompound((state.argument = state.match[2]))) {
								state.flag = nextCompileIdentifier(state, '_n')
								state.nested = state.engine.compileSelector(state.argument, state.flag + '=true;', state.mode, state.callback, void 0, state.compiler)
								state.source = 'var ' + state.flag + '=false;' + state.nested + 'if(!' + state.flag + '){' + state.source + '}'
							} else {
								if (!state.engine.validateLogical(state.match[2], false)) return ''
								state.source = 'if(!s.match("' + state.expr + '",e)){' + state.source + '}'
							}
							break
						case 'has':
							return compileHas(state)
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
					function compileLogicalCompound() {
						if (/^(?:[a-z][a-z0-9-]*)?(?:[.#][_a-zA-Z][-\w]*)+$/.test(state.match[2]))
							state.source = state.engine.compileSelector(state.match[2], state.source, state.mode, state.callback, void 0, state.compiler)
						else if (/^[a-z][a-z0-9-]*(?:[\t\n\f\r ]*,[\t\n\f\r ]*[a-z][a-z0-9-]*)*$/.test(state.match[2]))
							state.source = 'if(' + typeUnionCondition(state, state.engine.splitList(state.match[2])) + '){' + state.source + '}'
						else if (state.engine.Config.FORGIVING) {
							var resolverKey = state.engine.forgivingKey(state.engine.splitList(state.match[2]))
							state.source = 'if(s.matchForgivingKey(' + JSON.stringify(resolverKey) + ',e)){' + state.source + '}'
						} else {
							if (!state.engine.validateLogical(state.match[2], false)) {
								compileLogicalCompoundValue = ''
								compileLogicalCompoundDone = true
								return
							}
							state.source = 'if(s.match("' + state.expr + '",e)){' + state.source + '}'
						}
					}
				}
				function compileHas(state) {
					state.argument = state.engine.prepareHas(state.match[2])
					if (state.argument === null) {
						state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
						return ''
					}
					state.match[2] = state.argument
					if (!state.engine.validateLogical(state.match[2], true)) return ''
					if (inlineRelative(state, state.match[2])) return
					var child = /^>[\t\n\f\r ]*([a-z][a-z0-9-]*|\*)$/.exec(state.match[2])
					if (child) {
						state.source = 'if(s.hasChild(e,"' + child[1] + '")){' + state.source + '}'
						return
					}
					state.source = 'if(s.has(' + JSON.stringify(state.match[2]) + ',e)){' + state.source + '}'
				}
				//#endregion
				//#region src/core/compile/position/constant.mts
				function compilePositionConstant(state) {
					state.test = state.type ? 'next' : 'previous'
					state.source = 'n=1,o=e;while(n<=' + state.a + '&&(o=o.' + state.test + 'ElementSibling))++n;if(n==' + state.a + '){' + state.source + '}'
				}
				//#endregion
				//#region src/core/compile/position/dense.mts
				function compilePositionDense(state) {
					state.flag = nextCompileIdentifier(state, '_p')
					state.engine.S_VARS.push(state.flag, state.flag + 'v')
					state.source =
						'o=e.parentNode;if(o===' +
						state.flag +
						'){n=e===' +
						state.flag +
						'v;}else if(o&&k+1<l&&c[k+1].parentNode===o){' +
						state.flag +
						'=o;' +
						state.flag +
						'v=o.' +
						(state.type ? 'last' : 'first') +
						'ElementChild;n=1;while(n<' +
						state.a +
						'&&' +
						state.flag +
						'v){' +
						state.flag +
						'v=' +
						state.flag +
						'v.' +
						(state.type ? 'previous' : 'next') +
						'ElementSibling;++n;}n=e===' +
						state.flag +
						'v;}else{n=1,o=e;while(n<=' +
						state.a +
						'&&(o=o.' +
						(state.type ? 'next' : 'previous') +
						'ElementSibling))++n;n=n==' +
						state.a +
						';}if(n){' +
						state.source +
						'}'
				}
				//#endregion
				//#region src/core/compile/position/match.mts
				function compilePositionMatch(state) {
					if (state.expr) {
						state.flag = nextCompileIdentifier(state, '_t')
						state.engine.S_VARS.push(state.flag, state.flag + 's')
						state.source =
							state.flag +
							'=e.localName;' +
							state.flag +
							's=e.namespaceURI;n=1;o=e;while((o=o.' +
							(state.type ? 'next' : 'previous') +
							'ElementSibling)){if(o.localName===' +
							state.flag +
							'&&o.namespaceURI===' +
							state.flag +
							's){++n;' +
							(/^n==(\d+)$/.test(state.test) ? 'if(n>' + state.test.slice(3) + ')break;' : '') +
							'}}if((' +
							state.test +
							')){' +
							state.source +
							'}'
						return
					}
					var count = 'n=1;o=e;while((o=o.' + (state.type ? 'next' : 'previous') + 'ElementSibling))++n;'
					if (!state.type && !state.callback && canSharePosition(state)) {
						state.ancestry.position = true
						count = 'if(p){n=s.firstPosition(e,p);}else{' + count + '}'
					}
					state.source = count + 'if((' + state.test + ')){' + state.source + '}'
				}
				function canSharePosition(state) {
					for (var name in state.engine.Selectors) if (state.engine.Selectors[name]) return false
					for (name in state.engine.Combinators) if (state.engine.Combinators[name]) return false
					return true
				}
				//#endregion
				//#region src/core/compile/position/ordered.mts
				function compilePositionOrdered(state) {
					state.flag = nextCompileIdentifier(state, '_i')
					state.engine.S_VARS.push(state.flag, state.flag + 'n', state.flag + 's', state.flag + 't')
					state.source =
						'if(' +
						state.flag +
						's){n=s.nthElement(e,false);}else{n=1;o=' +
						state.flag +
						't?e.previousElementSibling:e.previousSibling;if((!' +
						state.flag +
						'||o!==' +
						state.flag +
						')&&!' +
						state.flag +
						't&&o!==(o=e.previousElementSibling))' +
						state.flag +
						't=true;while(o&&o!==' +
						state.flag +
						'&&n<8){++n;o=o.previousElementSibling;}if(o===' +
						state.flag +
						'&&' +
						state.flag +
						'){n+=' +
						state.flag +
						'n;}else if(o){n=s.nthElement(e,false);' +
						state.flag +
						's=true;}' +
						state.flag +
						'=e;' +
						state.flag +
						'n=n;}if((' +
						state.test +
						')){' +
						state.source +
						'}'
				}
				//#endregion
				//#region src/core/compile/position/shared.mts
				function compilePositionShared(state) {
					state.expr = state.expr ? 'OfType' : 'Element'
					state.type = state.type ? 'true' : 'false'
					state.source =
						'n=s.nth' +
						state.expr +
						'(e,' +
						state.type +
						(state.expr == 'OfType' && !state.engine.Config.LEGACY ? ',!f' : '') +
						');if((' +
						state.test +
						')){' +
						state.source +
						'}'
				}
				//#endregion
				//#region src/core/compile/position/route.mts
				function compilePositionRoute(state) {
					var stableSelection = state.mode === true && !state.callback && !state.engine.Config.LEGACY
					if (state.test == 'n==' + state.a && state.a >= 1 && !state.expr) {
						if (stableSelection) {
							compilePositionDense(state)
							return
						}
						compilePositionConstant(state)
						return
					}
					if (state.mode === false && !state.engine.Config.LEGACY) {
						compilePositionMatch(state)
						return
					}
					if (stableSelection && !state.expr && !state.type) {
						compilePositionOrdered(state)
						return
					}
					compilePositionShared(state)
				}
				//#endregion
				//#region src/core/compile/position/simple.mts
				function compilePositionSimple(state, nthFilter) {
					if (state.match[2] == 'n' && nthFilter === void 0) {
						state.source = 'if(true){' + state.source + '}'
						return true
					} else if (state.match[2] == '1' && nthFilter === void 0) {
						state.test = state.type ? 'next' : 'previous'
						if (state.engine.S_VARS.indexOf('_u') < 0) state.engine.S_VARS.push('_u')
						state.source = state.expr
							? 'n=e;o=e.localName;_u=e.namespaceURI;while((n=n.' +
								state.test +
								'ElementSibling)&&(n.localName!=o||n.namespaceURI!=_u));if(!n){' +
								state.source +
								'}'
							: 'if(!e.' + state.test + 'ElementSibling){' + state.source + '}'
						return true
					}
					return false
				}
				//#endregion
				//#region src/core/compile/position/expression.mts
				function positionalFormula(state) {
					return state.a >= 1
						? state.f
							? 'n>' + (state.b - 1) + (Math.abs(state.a) != 1 ? '&&' + state.test : '')
							: 'n==' + state.a
						: state.a <= -1
							? state.f
								? 'n<' + (state.b + 1) + (Math.abs(state.a) != 1 ? '&&' + state.test : '')
								: 'n==' + state.a
							: state.a === 0
								? state.n[0]
									? 'n==' + state.b
									: 'n>' + (state.b - 1)
								: 'false'
				}
				//#endregion
				//#region src/core/compile/position/formula.mts
				function compilePositionFormula(state) {
					state.f = /n/i.test(state.match[2])
					state.n = state.match[2].split('n')
					state.a = parseInt(state.n[0], 10) || 0
					state.b = parseInt(state.n[1], 10) || 0
					if (state.n[0] == '-') state.a = -1
					if (state.n[0] == '+') state.a = 1
					state.test = (state.b ? '(n' + (state.b > 0 ? '-' : '+') + Math.abs(state.b) + ')' : 'n') + '%' + state.a + '==0'
					state.test = positionalFormula(state)
				}
				//#endregion
				//#region src/core/compile/position/condition.mts
				function compilePositionTest(state) {
					if (state.match[2] == 'even' || state.match[2] == '2n0' || state.match[2] == '2n+0' || state.match[2] == '2n') state.test = 'n%2==0'
					else if (state.match[2] == 'odd' || state.match[2] == '2n1' || state.match[2] == '2n+1') state.test = 'n%2==1'
					else compilePositionFormula(state)
				}
				//#endregion
				//#region src/core/compile/pseudo/position.mts
				function compilePseudoPosition(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'nth-child':
						case 'nth-of-type':
						case 'nth-last-child':
						case 'nth-last-of-type':
							state.expr = /-of-type/i.test(state.match[1])
							var nthFilter = state.match[3]
							if (nthFilter !== void 0 && (state.expr || !state.engine.validateLogical(nthFilter, false))) {
								state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
								return ''
							}
							if (state.match[1] && state.match[2]) {
								state.type = /last/i.test(state.match[1])
								if (compilePositionSimple(state, nthFilter)) return
								compilePositionTest(state)
								if (nthFilter !== void 0) {
									state.flag = nextCompileIdentifier(state, '_f')
									state.engine.S_VARS.push(state.flag)
									state.source =
										'n=s.nthFiltered(e,' +
										JSON.stringify(nthFilter) +
										',' +
										!!state.type +
										',f?null:(' +
										state.flag +
										'||(' +
										state.flag +
										'=v?(v.' +
										state.flag +
										'||(v.' +
										state.flag +
										'={})):{})));if(n>0&&(' +
										state.test +
										')){' +
										state.source +
										'}'
									return
								}
								compilePositionRoute(state)
							} else state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/resource.mts
				function compilePseudoResource(state) {
					state.source = 'if(s.isMediaState(e,' + JSON.stringify(state.match[1].toLowerCase()) + ')){' + state.source + '}'
				}
				//#endregion
				//#region src/core/compile/pseudo/structural.mts
				function compilePseudoStructural(state) {
					state.match[1] = state.match[1].toLowerCase()
					switch (state.match[1]) {
						case 'scope':
							state.source = 'if(e===(s.from.nodeType===9?s.from.documentElement:s.from)){' + state.source + '}'
							break
						case 'root':
							state.source = 'if((e===s.doc.documentElement)){' + state.source + (state.mode ? 'break main;' : '') + '}'
							break
						case 'empty':
							state.source = 'n=e.firstChild;while(n&&n.nodeType!=1&&n.nodeType!=3&&n.nodeType!=4){n=n.nextSibling}if(!n){' + state.source + '}'
							break
						case 'only-child':
							state.source = 'if((!e.nextElementSibling&&!e.previousElementSibling)){' + state.source + '}'
							break
						case 'last-child':
							state.source = 'if((!e.nextElementSibling)){' + state.source + '}'
							break
						case 'first-child':
							state.firstChildOnly = true
							state.source = 'if((!e.previousElementSibling)){' + state.source + '}'
							break
						case 'only-of-type':
							if (state.engine.S_VARS.indexOf('_u') < 0) state.engine.S_VARS.push('_u')
							state.source =
								'o=e.localName;_u=e.namespaceURI;n=e;while((n=n.nextElementSibling)&&(n.localName!=o||n.namespaceURI!=_u));if(!n){n=e;while((n=n.previousElementSibling)&&(n.localName!=o||n.namespaceURI!=_u));}if(!n){' +
								state.source +
								'}'
							break
						case 'last-of-type':
							if (state.engine.S_VARS.indexOf('_u') < 0) state.engine.S_VARS.push('_u')
							state.source =
								'n=e;o=e.localName;_u=e.namespaceURI;while((n=n.nextElementSibling)&&(n.localName!=o||n.namespaceURI!=_u));if(!n){' + state.source + '}'
							break
						case 'first-of-type':
							if (state.engine.S_VARS.indexOf('_u') < 0) state.engine.S_VARS.push('_u')
							state.source =
								'n=e;o=e.localName;_u=e.namespaceURI;while((n=n.previousElementSibling)&&(n.localName!=o||n.namespaceURI!=_u));if(!n){' + state.source + '}'
							break
						default:
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/time.mts
				function compilePseudoTime(state) {
					state.expr = ':' + state.match[1].toLowerCase()
					if (state.expr === ':current' && state.match[2].charCodeAt(0) === 40) {
						state.match = state.engine.matchLogical(state.selector, /^:(current)\(/i)
						if (
							!state.match ||
							!state.match[2] ||
							!state.engine.splitList(state.match[2]).every(function (item) {
								return state.engine.isCompound(item)
							}) ||
							!state.engine.validateLogical(state.match[2], false)
						) {
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return
						}
						state.expr += '(' + state.match[2] + ')'
					}
					state.source = 'if(s.matchesNative(e,' + JSON.stringify(state.expr) + ')){' + state.source + '}'
				}
				//#endregion
				//#region src/core/compile/pseudo/class.mts
				function compilePseudoClass(state) {
					if ((state.match = /^:heading(?:\(([^)]*)(?:\)|$))?(?![-\w])(.*)/i.exec(state.selector))) return compilePseudoHeading(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['structural']))) return compilePseudoStructural(state)
					else if ((state.match = state.engine.matchNth(state.selector))) return compilePseudoPosition(state)
					else if ((state.match = state.engine.matchLogical(state.selector))) return compilePseudoLogical(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['linguistic']))) return compilePseudoLinguistic(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['locationpc']))) return compilePseudoLocation(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['useraction']))) return compilePseudoAction(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['inputstate']))) return compilePseudoInput(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['inputvalue']))) return compilePseudoInputValue(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['rsrc_state']))) return compilePseudoResource(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['disp_state']))) return compilePseudoDisplay(state)
					else if ((state.match = state.selector.match(state.engine.Patterns['time_state']))) return compilePseudoTime(state)
					else return compilePseudoExtension(state)
				}
				//#endregion
				//#region src/core/validation/pseudo/host-argument.mts
				function rejectsHostArgument(state) {
					return state.argument === null
						? state.name != 'host'
						: (state.argument = state.engine.prepareCompound(state.argument)) === null ||
								state.engine.hasPseudoElement(state.argument) ||
								!state.engine.validateLogical(state.argument, false)
				}
				//#endregion
				//#region src/core/compile/pseudo/modern.mts
				function compilePseudoModern(state) {
					var compileFunctionalStateDone = false
					var compileFunctionalStateValue
					state.name = state.pseudo.name
					state.argument = state.pseudo.argument
					if (state.name == 'lang') {
						var ranges = state.argument === null ? [] : state.engine.splitList(state.argument),
							languageTests = [],
							range,
							quoted
						for (var rangeIndex = 0, rangesLength = ranges.length; rangeIndex < rangesLength; ++rangeIndex) {
							range = ranges[rangeIndex]
							quoted = /^(?:"(?:[^"\\\n\r\f]|\\[^\n\r\f])*"|'(?:[^'\\\n\r\f]|\\[^\n\r\f])*')$/.test(range)
							if (!quoted && !state.engine.isIdent(range)) break
							languageTests.push('s.isLanguage(e,' + JSON.stringify(state.engine.unescapeIdentifier(quoted ? range.slice(1, -1) : range)) + ')')
						}
						if (!ranges.length || languageTests.length !== ranges.length) {
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return ''
						}
						state.source = 'if(' + languageTests.join('||') + '){' + state.source + '}'
					} else if (state.name == 'host' || state.name == 'host-context') {
						if (rejectsHostArgument(state)) {
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return ''
						}
						state.source =
							'if(s.isHost(e,' + JSON.stringify(state.argument) + ',' + (state.name == 'host-context') + ',x||(c.nodeType?c:s.from))){' + state.source + '}'
					} else {
						compileFunctionalState()
						if (compileFunctionalStateDone) return compileFunctionalStateValue
					}
					state.match = [state.selector.slice(0, state.selector.length - state.pseudo.rest.length), state.pseudo.rest]
					return
					function compileFunctionalState() {
						if (state.name == 'has-slotted') {
							if (
								state.argument !== null &&
								(!state.argument ||
									state.engine.hasPseudoElement(state.argument) ||
									!state.engine.isCompound(state.engine.normalizeCombinators(state.argument), true) ||
									!state.engine.validateLogical(state.argument, false))
							) {
								state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
								compileFunctionalStateValue = ''
								compileFunctionalStateDone = true
								return
							}
							state.source = 'if(s.hasSlotted(e,' + JSON.stringify(state.argument) + ')){' + state.source + '}'
						} else {
							if (
								state.name == 'state'
									? state.argument === null || !state.engine.isIdent(state.argument)
									: state.name == 'active-view-transition-type'
										? state.argument === null ||
											!state.engine.splitList(state.argument).every(function (value) {
												return state.engine.isIdent(value.replace(state.engine.REX.TrimSpaces, ''), true)
											})
										: state.argument !== null
							) {
								state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
								compileFunctionalStateValue = ''
								compileFunctionalStateDone = true
								return
							}
							state.expr = ':' + state.name + (state.argument === null ? '' : '(' + state.argument + ')')
							state.source = 'if(s.matchesNative(e,' + JSON.stringify(state.expr) + ')){' + state.source + '}'
						}
					}
				}
				//#endregion
				//#region src/core/compile/pseudo/dispatch.mts
				function compilePseudo(state) {
					if (
						(state.selector.charAt(1) == ':' || state.engine.Patterns['pseudo_sng'].test(state.selector)) &&
						!state.engine.isPseudoExtension(state.selector)
					) {
						if (!state.engine.validPseudoTail(state.selector)) {
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return ''
						}
						state.source =
							'if(!e.nodeType&&e.element&&e.type&&e.type.toLowerCase()==' +
							JSON.stringify(state.selector.charAt(1) == ':' ? state.selector.toLowerCase() : ':' + state.selector.toLowerCase()) +
							'){e=e.element;' +
							state.source +
							'}'
						state.match = [state.selector, '']
						return
					}
					state.pseudo = state.engine.readPseudo(state.selector)
					if (
						state.pseudo &&
						/^(?:lang|host|host-context|has-slotted|state|active-view-transition-type|active-view-transition|user-valid|user-invalid|xr-overlay|interest-source|interest-target|target-current|target-before|target-after)$/.test(
							state.pseudo.name
						)
					)
						return compilePseudoModern(state)
					return compilePseudoClass(state)
				}
				//#endregion
				//#region src/core/compile/sibling.mts
				function compileSibling(state) {
					state.match = state.selector.match(state.engine.Patterns['relative'])
					state.ancestry.pending.length = 0
					if (state.pendingTag) {
						state.source = state.pendingTag + state.source + '}'
						state.pendingTag = ''
					}
					var memo = ''
					if (state.mode === true && !state.firstChildOnly && !state.engine.Config.LEGACY) {
						state.flag = nextCompileIdentifier(state, '_sw')
						state.engine.S_VARS.push(state.flag + '=s.createWeakMap()')
						memo = 'if(' + state.flag + '.get(e)!==false){'
					}
					state.source =
						'var N' +
						state.k +
						'=e;' +
						(state.firstChildOnly ? 'if(e&&(e=e.parentNode)&&(e=e.firstElementChild)&&e!==N' + state.k + ')' : 'while(e&&(e=' + state.read.prev('e') + '))') +
						'{' +
						memo +
						state.source +
						(memo ? state.flag + '.set(e,false);}' : '') +
						'}e=N' +
						state.k +
						';'
					state.firstChildOnly = false
				}
				//#endregion
				//#region src/core/compile/type.mts
				function compileType(state) {
					state.match = state.selector.match(state.engine.Patterns['tagName'])
					state.expr = state.engine.unescapeIdentifier(state.match[1])
					state.ancestry.pending[state.ancestry.pending.length] = state.expr
					state.pendingTag = state.engine.HTML_DOCUMENT
						? 'if(' +
							state.read.tag('e') +
							'==' +
							JSON.stringify(state.engine.asciiLower(state.expr)) +
							'||s.matchesTag(e,' +
							JSON.stringify(state.expr) +
							')){'
						: 'if((' + state.read.tag('e') + '==' + JSON.stringify(state.expr) + ')){'
				}
				//#endregion
				//#region src/core/compile/universal.mts
				function compileUniversal(state) {
					state.match = state.selector.match(state.engine.Patterns['universal'])
				}
				//#endregion
				//#region src/core/compile/unknown.mts
				function compileUnknown(state) {
					state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
					return false
				}
				//#endregion
				//#region src/core/compile/token.mts
				function compileToken(state) {
					switch (state.symbol) {
						case 42:
							return compileUniversal(state)
						case 35:
							return compileId(state)
						case 46:
							return compileClass(state)
						case 124:
							return compileNamespace(state)
						case 91:
							return compileAttribute(state)
						case 126:
							return compileSibling(state)
						case 43:
							return compileAdjacent(state)
						case 9:
						case 32:
							return compileAncestor(state)
						case 62:
							return compileChild(state)
						default:
							return compileOtherToken(state)
					}
				}
				function compileOtherToken(state) {
					if (state.symbol === 95 || (state.symbol >= 65 && state.symbol <= 90) || (state.symbol >= 97 && state.symbol <= 122)) return compileType(state)
					if (state.selector[0] in state.engine.Combinators) return compileExtension(state)
					return state.symbol === 58 ? compilePseudo(state) : compileUnknown(state)
				}
				//#endregion
				//#region src/core/compile/mixed.mts
				function compileMixed(state) {
					if (!state.compiler || state.callback || !pureCompiler(state.engine) || !/[>+]/.test(state.selector)) return null
					var chain = parsePure(state.selector)
					if (
						!chain ||
						chain.compounds.length < 4 ||
						!chain.relations.some(fixed) ||
						chain.relations.filter(function (value) {
							return !fixed(value)
						}).length < 2
					)
						return null
					var prefix = nextCompileIdentifier(state, '_mixed')
					var memo = prefix + 'Memo'
					var functions = chain.compounds
						.map(function (compound, index) {
							return helper(state, chain, compound, index, prefix)
						})
						.join('')
					;(state.compiler.prelude || (state.compiler.prelude = [])).push(functions)
					;(state.compiler.variables || (state.compiler.variables = [])).push(memo + '=null')
					var last = chain.compounds.length - 1
					var source = greedy(state, chain, prefix) + 'if(' + prefix + 'Hit||' + prefix + last + '(e,' + memo + '||(' + memo + '=[0]))){' + state.source + '}'
					return state.engine.compileSelector(chain.compounds[last], source, state.mode, state.callback, void 0, state.compiler)
				}
				function fixed(relation) {
					return relation === '>' || relation === '+'
				}
				function step(state, relation, element) {
					return relation === ' ' || relation === '>' ? state.read.up(element) : state.read.prev(element)
				}
				function helper(state, chain, compound, index, prefix) {
					var relation = chain.relations[index - 1]
					var success = 'r=true;'
					if (index) {
						var call = prefix + (index - 1) + '(e,m)'
						success =
							'e=' +
							step(state, relation, 'e') +
							';' +
							(fixed(relation) ? 'r=!!e&&' + call + ';' : 'while(e){if(' + call + '){r=true;break;}e=' + step(state, relation, 'e') + ';}')
					}
					var predicate = state.engine.compileSelector(compound, success, false, false)
					return (
						'function ' +
						prefix +
						index +
						'(e,m){var n,o,original=e,map=m[' +
						(index + 1) +
						'],r=false;if(map&&map.has(e)){return map.get(e);}if(!map&&++m[0]>64){map=m[' +
						(index + 1) +
						']=s.createWeakMap();}' +
						predicate +
						'if(map){map.set(original,r);}return r;}'
					)
				}
				function greedy(state, chain, prefix) {
					var label = prefix + 'Exit'
					var flag = prefix + 'Part'
					var source = 'var ' + prefix + 'Node=e,' + prefix + 'Hit=false,' + flag + ';' + label + ':{'
					for (var i = chain.compounds.length - 2; i >= 0; --i) {
						var relation = chain.relations[i]
						var advance = 'e=' + step(state, relation, 'e') + ';'
						var predicate = state.engine.compileSelector(chain.compounds[i], flag + '=true;', state.mode, false, void 0, state.compiler)
						source += advance + flag + '=false;'
						source += fixed(relation) ? 'if(e){' + predicate + '}' : 'while(e){' + predicate + 'if(' + flag + '){break;}' + advance + '}'
						source += 'if(!' + flag + '){break ' + label + ';}'
					}
					return source + prefix + 'Hit=true;}e=' + prefix + 'Node;'
				}
				//#endregion
				//#region src/core/compile/guards.mts
				function orderGuards(engine, selector) {
					var _exec
					if (!pureCompiler(engine) || selector.length > 512 || !/[\[:]/.test(selector)) return selector
					var parts = parsePure(selector)
					if (parts)
						return parts.compounds
							.map(function (part) {
								return orderCompound(engine, part)
							})
							.map(function (part, index) {
								return (index ? parts.relations[index - 1] : '') + part
							})
							.join('')
					var pseudo = /^(.*)(:(has|is|where|not|nth-child|nth-last-child|nth-of-type|nth-last-of-type)\((.*)\))$/.exec(selector)
					if (!pseudo || !pureCompound(pseudo[1]) || !pureArgument(engine, pseudo[3], pseudo[4])) return selector
					var compound = orderCompound(engine, pseudo[1])
					var type = ((_exec = /^(?:[a-zA-Z][-\w]*|\*)/.exec(compound)) === null || _exec === void 0 ? void 0 : _exec[0]) || ''
					return type + pseudo[2] + compound.slice(type.length)
				}
				function pureArgument(engine, name, argument) {
					if (name.slice(0, 4) === 'nth-') return /^(?:even|odd|[+-]?\d+|[+-]?\d*n(?:\s*[+-]\s*\d+)?)$/.test(argument)
					return engine.splitList(argument).every(function (branch) {
						return pureSelector(name === 'has' && /^[>+~]/.test(branch) ? '*' + branch : branch)
					})
				}
				function orderCompound(engine, compound) {
					var pieces = compound.match(/\[(?:"[^"]*"|'[^']*'|[^\]])*\]|[.#][_a-zA-Z][-\w]*|[a-zA-Z][-\w]*|\*/g)
					var seen = engine.primordials.ObjectCreate(null)
					var buckets = ['', '', '', '']
					for (var index = 0, length = pieces.length; index < length; ++index) {
						var piece = pieces[index]
						if (!seen[piece]) {
							seen[piece] = true
							var bucket = piece[0] === '[' ? 1 : piece[0] === '.' ? 2 : piece[0] === '#' ? 3 : 0
							buckets[bucket] += piece
						}
					}
					return buckets.join('')
				}
				//#endregion
				//#region src/core/compile/selector.mts
				function compileSelector(engine, expression, source, mode, callback, ancestry, compiler) {
					var state = {
						engine: engine,
						expression: expression,
						source: source,
						mode: mode,
						callback: callback,
						ancestry: ancestry,
						compiler: compiler
					}
					state.k = 0
					state.previousErrors = state.engine.errors
					state.pendingTag = ''
					state.firstChildOnly = false
					state.selector = state.expression
					state.shadow = state.expression.indexOf(':') >= 0 && state.engine.hasHost(state.expression)
					state.read = state.engine.Config.LEGACY ? state.engine.legacyHooks.read : state.mode === false ? state.engine.readGuarded : state.engine.readDirect
					state.selector = state.engine.selectorComments(state.selector)
					state.ancestry = state.ancestry || {
						required: [],
						pending: [],
						walk: false
					}
					state.selector = state.engine.normalizeCombinators(state.selector)
					state.selector = orderGuards(engine, state.selector)
					var mixed = compileMixed(state)
					if (mixed !== null) return mixed
					if (state.ancestry.reuse && !state.engine.canReuseAncestor(state.selector)) state.ancestry.reuse = ''
					selector_recursion_label: while (state.selector) {
						++state.k
						state.symbol = state.selector.charCodeAt(0)
						classifyNamespace()
						var result = compileToken(state)
						if (result === false) break selector_recursion_label
						if (result !== void 0) return result
						if (!state.match) {
							state.engine.emit("'" + state.expression + "'" + state.engine.qsInvalid)
							return ''
						}
						state.selector = state.match.pop()
					}
					if (state.pendingTag) state.source = state.pendingTag + state.source + '}'
					return state.engine.errors == state.previousErrors ? state.source : ''
					function classifyNamespace() {
						if (
							(state.symbol == 42 ||
								state.symbol == 95 ||
								(state.symbol >= 48 && state.symbol <= 57) ||
								(state.symbol >= 65 && state.symbol <= 90) ||
								(state.symbol >= 97 && state.symbol <= 122)) &&
							state.engine.STD.apimethods.test(state.selector)
						)
							state.symbol = 124
					}
				}
				//#endregion
				//#region src/core/compile/position/nth-element.mts
				function createNthElement(engine) {
					var idx = 0,
						len = 0,
						set = 0,
						parent = void 0,
						parents = Array(),
						nodes = Array()
					return function (element, dir) {
						var loadSiblingSetDone = false
						var loadSiblingSetValue
						if (dir == 2) {
							idx = 0
							len = 0
							set = 0
							nodes.length = 0
							parents.length = 0
							parent = void 0
							return -1
						}
						var e,
							i,
							j,
							k,
							l,
							p = engine.Config.LEGACY ? engine.upOf(element) : element.parentNode
						loadSiblingSet()
						if (loadSiblingSetDone) return loadSiblingSetValue
						if (element !== nodes[i][j] && element !== nodes[i][(j = 0)])
							for (j = 0, e = nodes[i], k = l - 1; l > j; ++j, --k) {
								if (e[j] === element) break
								if (e[k] === element) {
									j = k
									break
								}
							}
						idx = j + 1
						len = l
						return dir ? l - j : idx
						function loadSiblingSet() {
							if (parent === p) {
								i = set
								j = idx
								l = len
							} else {
								l = parents.length
								parent = p
								for (i = -1, j = 0, k = l - 1; l > j; ++j, --k) {
									if (parents[j] === parent) {
										i = j
										break
									}
									if (parents[k] === parent) {
										i = k
										break
									}
								}
								if (i < 0) {
									parents[(i = l)] = parent
									l = 0
									nodes[i] = Array()
									e = parent ? engine.firstOf(parent) || element : element
									if (engine.Config.LEGACY) {
										var siblings = engine.legacyHooks.siblings(e, element)
										nodes[i] = siblings.nodes
										j = siblings.index
										l = siblings.nodes.length
									} else
										while (e) {
											nodes[i][l] = e
											if (e === element) j = l
											e = e.nextElementSibling
											++l
										}
									set = i
									idx = 0
									len = l
									if (l < 2) {
										loadSiblingSetValue = l
										loadSiblingSetDone = true
										return
									}
								} else {
									l = nodes[i].length
									set = i
								}
							}
						}
					}
				}
				//#endregion
				//#region src/core/compile/position/nth-of-type.mts
				function createNthOfType(engine) {
					var current,
						currentIndex = 0,
						currentLength = 0,
						snapshots = Array()
					return function (element, dir, stable) {
						if (dir == 2) {
							snapshots.length = 0
							current = void 0
							currentIndex = 0
							currentLength = 0
							return -1
						}
						var adjacent = stablePosition(current, currentIndex, currentLength, element, dir, stable)
						if (adjacent !== void 0) return adjacent
						var target = element
						var local = engine.Config.LEGACY ? engine.tagOf(target) : target.localName
						var namespace = target.namespaceURI
						var name = typeName(engine, namespace, local)
						var parent = target.parentNode
						if (stable === false && !engine.Config.LEGACY) return scanPosition(engine, parent, target, local, namespace, dir)
						var type = getTypePositions(engine, getParentSnapshot(snapshots, parent, engine, target), target, name, local, namespace)
						if (!type) {
							current = void 0
							return 1
						}
						current = type.nodes
						currentLength = type.nodes.length
						currentIndex = type.positions ? type.positions.get(target) || 1 : findPosition(type.nodes, target)
						return dir ? currentLength - currentIndex + 1 : currentIndex
					}
				}
				function stablePosition(current, index, length, element, dir, stable) {
					if (!stable || !current) return
					if (current[index] === element) {
						++index
						return dir ? length - index + 1 : index
					}
					if (current[index - 1] === element) return dir ? length - index + 1 : index
				}
				function getParentSnapshot(snapshots, parent, engine, target) {
					for (var i = 0, length = snapshots.length; i < length; ++i) if (snapshots[i].parent === parent) return snapshots[i]
					var snapshot = {
						parent: parent,
						types: engine.primordials.ObjectCreate(null)
					}
					snapshots[snapshots.length] = snapshot
					if (!engine.Config.LEGACY) buildSnapshot(snapshot, engine, target)
					return snapshot
				}
				function getTypePositions(engine, snapshot, target, name, local, namespace) {
					var type = snapshot.types[name]
					if (type || !engine.Config.LEGACY) return type
					var parent = snapshot.parent
					var start = parent ? engine.firstOf(parent) || target : target
					type = {
						nodes: engine.legacyHooks.siblings(start, target, local, namespace).nodes
					}
					addPositions(engine, type)
					snapshot.types[name] = type
					return type
				}
				function buildSnapshot(snapshot, engine, target) {
					var node = snapshot.parent ? engine.firstOf(snapshot.parent) : target
					while (node) {
						var _type_positions
						var sibling = node
						var name = typeName(engine, sibling.namespaceURI, sibling.localName)
						var type = snapshot.types[name]
						if (!type) {
							type = {
								nodes: []
							}
							addPositions(engine, type)
							snapshot.types[name] = type
						}
						type.nodes[type.nodes.length] = sibling
						;(_type_positions = type.positions) === null || _type_positions === void 0 ? void 0 : _type_positions.set(sibling, type.nodes.length)
						node = sibling.nextElementSibling
					}
				}
				function addPositions(engine, type) {
					var WeakMapCtor = engine.primordials.WeakMapCtor
					if (WeakMapCtor) {
						type.positions = new WeakMapCtor()
						for (var i = 0, length = type.nodes.length; i < length; ++i) type.positions.set(type.nodes[i], i + 1)
					}
				}
				function scanPosition(engine, parent, target, local, namespace, dir) {
					var node = parent ? engine.firstOf(parent) : target
					var index = 0
					var total = 0
					while (node) {
						var sibling = node
						if (sibling.localName === local && sibling.namespaceURI === namespace) {
							++total
							if (sibling === target) index = total
						}
						node = sibling.nextElementSibling
					}
					var position = index || 1
					return dir ? total - position + 1 : position
				}
				function typeName(engine, namespace, local) {
					return namespace == engine.NAMESPACE ? local : (namespace || '') + '\0' + local
				}
				function findPosition(nodes, target) {
					for (var i = 0, length = nodes.length; i < length; ++i) if (nodes[i] === target) return i + 1
					return 1
				}
				//#endregion
				//#region src/core/ancestor/token-pattern.mts
				function ancestorTokenPattern(token) {
					return token == '.'
						? 'className'
						: token == '#'
							? 'id'
							: token == '*'
								? 'universal'
								: token == '>'
									? 'children'
									: token == '+'
										? 'adjacent'
										: token == '~'
											? 'relative'
											: token == ' ' || token == '	'
												? 'ancestor'
												: 'tagName'
				}
				//#endregion
				//#region src/core/ancestor/reuse.mts
				function canReuseAncestor(engine, selector) {
					var scanReusableAncestorsDone = false
					var scanReusableAncestorsValue
					if (!/[\t\n\f\r ]/.test(selector)) return false
					for (var extension in engine.Selectors) if (engine.Selectors[extension]) return false
					for (extension in engine.Combinators) if (engine.Combinators[extension]) return false
					var walks = 0,
						token,
						pattern,
						match
					scanReusableAncestors()
					if (scanReusableAncestorsDone) return scanReusableAncestorsValue
					return walks == 1
					function scanReusableAncestors() {
						while (selector) {
							token = selector.charAt(0)
							pattern = ancestorTokenPattern(token)
							if (token == ':') {
								match = selector.match(engine.Patterns['structural'])
								if (match) {
									if (match[1].toLowerCase() == 'root' || match[1].toLowerCase() == 'scope') {
										scanReusableAncestorsValue = false
										scanReusableAncestorsDone = true
										return
									}
								} else {
									var nth = engine.readPseudo(selector)
									if (!nth || !engine.Patterns['treestruct'].test(selector) || nth.argument === null || nth.argument.toLowerCase().indexOf('of') >= 0) {
										scanReusableAncestorsValue = false
										scanReusableAncestorsDone = true
										return
									}
									selector = nth.rest
									continue
								}
							} else {
								if (pattern == 'ancestor' && ++walks > 1) {
									scanReusableAncestorsValue = false
									scanReusableAncestorsDone = true
									return
								}
								match = selector.match(engine.Patterns[pattern])
							}
							if (!match || match[match.length - 1] === selector) {
								scanReusableAncestorsValue = false
								scanReusableAncestorsDone = true
								return
							}
							selector = match[match.length - 1]
						}
					}
				}
				//#endregion
				//#region src/core/compile/cache-key.mts
				function compileCacheKey(engine, selector, mode, callback, relative, existenceOnly) {
					var key =
						(mode === true || mode === false || mode === null
							? engine.compilePrefixes[(relative ? 6 : 0) + (mode === null ? 4 : mode ? 2 : 0) + (callback ? 1 : 0)]
							: (relative ? 'relative:' : 'selector:') + mode + ':' + !!callback + ':') + selector
					if (existenceOnly) key = 'exists:' + key
					return key
				}
				//#endregion
				//#region src/core/compile/factory.mts
				function bindResolver(engine, source, filter) {
					var cache = engine.codeFactories,
						_$factory = cache && cache.factories.get(source)
					if (!_$factory) {
						_$factory = Function('s', 'a', source)
						if (cache !== void 0 && source.length <= 8192) {
							if (!cache)
								cache = engine.codeFactories = {
									factories: engine.createCache(64),
									units: 0
								}
							if (cache.units + source.length > 32768) {
								cache.factories.clear()
								cache.units = 0
							}
							cache.factories.set(source, _$factory)
							cache.units += source.length
						}
					}
					var resolver = _$factory(engine.Snapshot, filter)
					resolver.cacheSize = source.length * 2 + 64
					return resolver
				}
				//#endregion
				//#region src/core/compile/resolver.mts
				function compile(engine, selector, mode, callback, relative, existenceOnly) {
					var prepareCompileModeDone = false
					var prepareCompileModeValue
					var cacheKey = compileCacheKey(engine, selector, mode, callback, relative, existenceOnly)
					var mask = 0,
						filter,
						filtered,
						ancestry,
						compiler,
						_$factory,
						head = '',
						loop = '',
						macro = '',
						source = '',
						vars = ''
					prepareCompileMode()
					if (prepareCompileModeDone) return prepareCompileModeValue
					ancestry = {
						required: [],
						pending: [],
						walk: false
					}
					compiler = {
						nextIdentifier: 0,
						classes: []
					}
					prepareAncestry()
					collectSharedAttributes(selector, compiler)
					source = engine.compileSelector(
						relative && !/^[>+~]/.test(selector) ? ' ' + selector : selector,
						relative ? 'if(e===s.anchor){' + macro + '}' : macro,
						mode,
						callback,
						ancestry,
						compiler
					)
					if ((mode || mode === null) && !callback && source === macro) {
						engine.selectLambdas.set(cacheKey, null)
						return null
					}
					guardAncestors()
					loop += mode || mode === null ? '{' + source + '}' : source
					if (mask) loop = 'try{' + loop + '}finally{s.clearAncestorMasks();}'
					clearSiblingPositions()
					collectVariables()
					finalizeVariables()
					_$factory = bindResolver(
						engine,
						'"use strict";' + (compiler.prelude || []).join('') + engine.F_INIT + '{' + head + vars + ';' + loop + 'return r;}',
						filter
					)
					annotateResolver(_$factory, filtered, ancestry.position)
					if (mode || mode === null) engine.selectLambdas.set(cacheKey, _$factory)
					else engine.matchLambdas.set(cacheKey, _$factory)
					return _$factory
					function prepareCompileMode() {
						switch (mode) {
							case true:
								if ((_$factory = engine.selectLambdas.get(cacheKey)) !== void 0) {
									prepareCompileModeValue = _$factory
									prepareCompileModeDone = true
									return
								}
								macro = engine.S_BODY + (existenceOnly ? 'break main;' : (callback ? engine.S_TEST : '') + engine.S_TAIL)
								head = engine.S_HEAD
								loop = engine.S_LOOP
								break
							case false:
								if ((_$factory = engine.matchLambdas.get(cacheKey)) !== void 0) {
									prepareCompileModeValue = _$factory
									prepareCompileModeDone = true
									return
								}
								macro = engine.M_BODY + (callback ? engine.M_TEST : '') + engine.M_TAIL
								head = engine.M_HEAD
								loop = engine.M_LOOP
								break
							case null:
								if ((_$factory = engine.selectLambdas.get(cacheKey)) !== void 0) {
									prepareCompileModeValue = _$factory
									prepareCompileModeDone = true
									return
								}
								macro = engine.N_BODY + (callback ? engine.N_TEST : '') + engine.N_TAIL
								head = engine.N_HEAD
								loop = engine.N_LOOP
						}
					}
					function collectSharedAttributes(selector, context) {
						if (engine.Config.LEGACY || callback) return
						var parsed = parsePure(selector)
						if (!parsed) return
						for (var compoundIndex = 0, compoundCount = parsed.compounds.length; compoundIndex < compoundCount; ++compoundIndex) {
							var compound = parsed.compounds[compoundIndex]
							var counts = engine.primordials.ObjectCreate(null)
							var seen = engine.primordials.ObjectCreate(null)
							var attributes = attributeSelectors(compound)
							for (var i = 0, length = attributes.length; i < length; ++i) {
								var _exec
								var token = attributes[i]
								var name = (_exec = /^\[[\t\n\f\r ]*([_a-zA-Z][\w-]*)/.exec(token)) === null || _exec === void 0 ? void 0 : _exec[1]
								if (name && !seen[token]) {
									seen[token] = true
									counts[name] = (counts[name] || 0) + 1
								}
							}
							for (var name1 in counts)
								if (counts[name1] > 1) {
									var _context
									;(_context = context).sharedAttributes || (_context.sharedAttributes = engine.primordials.ObjectCreate(null))
									context.sharedAttributes[name1] = ''
								}
						}
					}
					function prepareAncestry() {
						if ((mode || mode === null) && !engine.Config.LEGACY) ancestry.classes = compiler.classes
						if ((mode || mode === null) && !callback && !relative && !engine.Config.LEGACY) ancestry.reuse = macro
					}
					function guardAncestors() {
						if ((mode || mode === null) && ancestry.walk && ancestry.required.length > 1 && !callback && !engine.Config.LEGACY) {
							for (var requiredLength = ancestry.required.length, i = 0; i < requiredLength; ++i) mask |= engine.tagBit(ancestry.required[i])
							filter = {
								seen: 0,
								kept: 0,
								rest: 0
							}
							source = 'if(s.mayMatch(e,' + mask + ',a)){' + source + '}'
						}
					}
					function clearSiblingPositions() {
						var clearPositions =
							(engine.reNthElem.test(selector) ? 's.nthElement(null, 2);' : '') + (engine.reNthType.test(selector) ? 's.nthOfType(null, 2);' : '')
						if (clearPositions) loop = 'try{' + loop + '}finally{' + clearPositions + '}'
					}
					function collectVariables() {
						if (engine.S_VARS[0] || engine.M_VARS[0] || engine.N_VARS[0]) {
							filtered = engine.S_VARS.some(function (name) {
								return name.slice(0, 2) == '_f'
							})
							vars = ',' + (engine.S_VARS.join(',') || engine.M_VARS.join(',') || engine.N_VARS[0])
							engine.S_VARS.length = 0
							engine.M_VARS.length = 0
							engine.N_VARS.length = 0
						}
					}
					function finalizeVariables() {
						if (compiler.variables) vars += ',' + compiler.variables.join(',')
						if (ancestry.reuse) vars += ',_pStart=null,_pResult=false'
						if (compiler.classes.length)
							for (var classesLength = compiler.classes.length, i = 0; i < classesLength; ++i) vars += ',_c' + i + '=' + compiler.classes[i]
						if (engine.Config.LEGACY) {
							var rewritten = engine.legacyHooks.compile(loop)
							loop = rewritten.source
							vars += rewritten.variables
						}
					}
				}
				function attributeSelectors(compound) {
					var attributes = []
					var length = compound.length
					for (var i = 0; i < length; ++i) {
						if (compound[i] !== '[') continue
						var start = i
						var quote = ''
						var escaped = false
						for (++i; i < length; ++i) {
							var character = compound[i]
							if (escaped) escaped = false
							else if (character === '\\') escaped = true
							else if (quote) {
								if (character === quote) quote = ''
							} else if (character === '"' || character === "'") quote = character
							else if (character === ']') {
								attributes[attributes.length] = compound.slice(start, i + 1)
								break
							}
						}
					}
					return attributes
				}
				function annotateResolver(resolver, filtered, position) {
					if (filtered) resolver.filtered = true
					if (position) resolver.position = true
				}
				//#endregion
				//#region src/core/validation/error.mts
				function emit(engine, message, proto) {
					var err
					++engine.errors
					if (engine.Config.VERBOSITY) {
						if (proto) err = new proto(message)
						else err = new engine.global.DOMException(message, 'SyntaxError')
						throw err
					}
					if (engine.Config.LOGERRORS && console && console.log) console.log(message)
				}
				//#endregion
				//#region src/core/initialize/document.mts
				function initialize(engine, doc) {
					engine.setIdentifierSyntax()
					engine.lastContext = engine.switchContext(doc, true)
				}
				//#endregion
				//#region src/core/predicate/compound/separator.mts
				function isCompoundSeparator(depth, chr, siblings) {
					return (
						depth === 0 &&
						(chr == 44 || chr == 62 || (!siblings && chr == 43) || (!siblings && chr == 126) || chr == 32 || chr == 9 || chr == 10 || chr == 12 || chr == 13)
					)
				}
				//#endregion
				//#region src/core/predicate/compound/match.mts
				function isCompound(_engine, text, siblings) {
					var chr,
						depth = 0,
						escaped,
						i = 0,
						l = text.length,
						quote = 0
					for (; l > i; ++i) {
						chr = text.charCodeAt(i)
						if (escaped) {
							escaped = false
							continue
						}
						if (chr == 92) escaped = true
						else if (quote) {
							if (chr == quote) quote = 0
						} else if (chr == 34 || chr == 39) quote = chr
						else if (chr == 40 || chr == 91) ++depth
						else if (chr == 41 || chr == 93) --depth
						else if (isCompoundSeparator(depth, chr, siblings)) return false
					}
					return l > 0
				}
				//#endregion
				//#region src/core/initialize/syntax.mts
				function setIdentifierSyntax(engine) {
					var syntax = engine.Factory._identifierSyntax(engine.CFG.operators, engine.CFG.combinators)
					engine.reOptimizer = new RegExp(syntax.optimizer)
					engine.reValidator = new RegExp(syntax.validator)
					engine.reSimpleId = new RegExp(syntax.simpleId)
					engine.Patterns.id = new RegExp(syntax.id)
					engine.Patterns.tagName = new RegExp(syntax.tagName)
					engine.Patterns.className = new RegExp(syntax.className)
					engine.Patterns.attribute = new RegExp(syntax.attribute)
				}
				//#endregion
				//#region src/core/match/slot.mts
				function hasSlotted(engine, element, argument) {
					if (element.localName != 'slot' || element.namespaceURI != 'http://www.w3.org/1999/xhtml') return false
					var slot = element
					if (typeof slot.assignedNodes != 'function') return false
					var nodes = slot.assignedNodes({
						flatten: true
					})
					if (argument === null) return nodes.length > 0
					for (var i = 0, nodesLength = nodes.length; i < nodesLength; ++i) if (nodes[i].nodeType == 1 && engine.match(argument, nodes[i])) return true
					return false
				}
				//#endregion
				//#region src/core/match/direction.mts
				var directionProbes = Object.create(null)
				function isDirection(engine, element, direction) {
					var probe = directionProbes[direction] || (directionProbes[direction] = ':dir(' + direction + ')')
					var native = engine.Snapshot.matchesNative(element, probe, void 0)
					return native === void 0 ? engine.directionality(element) === direction : native
				}
				//#endregion
				//#region src/core/match/language/parent.mts
				function languageParent(engine, current) {
					return engine.upOf(current) || (current.parentNode && current.parentNode.host) || null
				}
				//#endregion
				//#region src/core/match/language/match.mts
				var createWantedRangeCache = Object.create
				var wantedRanges = createWantedRangeCache(null)
				var wantedRangeCount = 0
				var WANTED_RANGE_LIMIT = 256
				function wantedParts(range) {
					var parts = wantedRanges[range]
					if (parts !== void 0) return parts
					if (wantedRangeCount >= WANTED_RANGE_LIMIT) {
						wantedRanges = createWantedRangeCache(null)
						wantedRangeCount = 0
					}
					parts = range.toLowerCase().split('-')
					wantedRanges[range] = parts
					++wantedRangeCount
					return parts
				}
				function isLanguage(engine, element, range) {
					var current = element,
						language = null,
						parts,
						wanted = wantedParts(range),
						i,
						j
					language = findInheritedLanguage()
					if (!language) return range === ''
					if (!/^[a-z]{1,8}(?:-[a-z0-9]{1,8})*$/i.test(language) || !/^(?:[a-z]{1,8}|\*)(?:-(?:[a-z0-9]{1,8}|\*))*$/i.test(range)) return false
					parts = language.toLowerCase().split('-')
					if (wanted[0] != '*' && wanted[0] != parts[0]) return false
					i = 1
					j = 1
					while (i < wanted.length) {
						if (wanted[i] == '*') {
							++i
							continue
						}
						if (j >= parts.length) return false
						if (wanted[i] == parts[j]) {
							++i
							++j
							continue
						}
						if (parts[j].length == 1) return false
						++j
					}
					return true
					function findInheritedLanguage() {
						while (current) {
							language = current.getAttributeNS && current.getAttributeNS('http://www.w3.org/XML/1998/namespace', 'lang')
							if (language == null && current.namespaceURI == 'http://www.w3.org/1999/xhtml') language = engine.attrOf(current, 'lang')
							if (language !== null) break
							current = languageParent(engine, current)
						}
						return language
					}
				}
				//#endregion
				//#region src/core/validation/blocks.mts
				function validBlocks(_engine, text) {
					var consumeBlockTokenDone = false
					var consumeBlockTokenValue
					var stack = [],
						quote = '',
						char,
						i = 0
					for (var textLength = text.length; i < textLength; ++i) {
						char = text.charAt(i)
						if (char == '\\') {
							++i
							continue
						}
						if (quote) {
							if (char == quote) quote = ''
							else if (char == '\n' || char == '\r' || char == '\f') return false
						} else {
							consumeBlockToken()
							if (consumeBlockTokenDone) return consumeBlockTokenValue
						}
					}
					return true
					function consumeBlockToken() {
						if (char == '"' || char == "'") quote = char
						else if (char == '(' || char == '[') stack.push(char)
						else if (char == ')' || char == ']') {
							if (stack.pop() != (char == ')' ? '(' : '[')) {
								consumeBlockTokenValue = false
								consumeBlockTokenDone = true
								return
							}
						} else if (char == '{' || char == '}') {
							consumeBlockTokenValue = false
							consumeBlockTokenDone = true
							return
						}
					}
				}
				//#endregion
				//#region src/core/initialize/configure.mts
				function configure(engine, option, clear) {
					if (typeof option == 'string') return !!engine.Config[option]
					if (typeof option != 'object') return engine.Config
					for (var i in option) {
						if ((i == 'FORGIVING' || i == 'VERBOSITY' || i == 'NEURAL_PLANNER') && engine.Config[i] !== !!option[i]) clear = true
						if (!engine.legacyHooks && i == 'LEGACY' && option[i]) throw new TypeError('Load modules/nwsapi-legacy.js before enabling LEGACY')
						if (i == 'LEGACY' && engine.Config[i] !== !!option[i]) {
							engine.matcherDoc = engine.matcherCache = null
							clear = true
						}
						engine.Config[i] = !!option[i]
					}
					if (clear) {
						engine.childPlans.clear()
						engine.typeRoutes.clear()
						engine.descentDeclined.clear()
						engine.matchLambdas.clear()
						engine.selectLambdas.clear()
						engine.matchResolvers.clear()
						engine.forgivingResolvers.clear()
						engine.selectResolvers.clear()
						engine.firstResolvers.clear()
						engine.hasPlans = void 0
					}
					engine.useLegacy(engine.Config.LEGACY)
					engine.setIdentifierSyntax()
					return true
				}
				//#endregion
				//#region src/core/predicate/display.mts
				function isOpen(engine, node) {
					return (/^(details|dialog)$/i.test(engine.tagOf(node)) && node.open === true) || engine.matchesNative(node, ':open')
				}
				function isClosed(engine, node) {
					return (/^(details|dialog)$/i.test(engine.tagOf(node)) && node.open === false) || engine.matchesNative(node, ':closed')
				}
				function fullscreenState(_engine, node) {
					var owner = node.ownerDocument,
						standard = owner && owner.fullscreenElement,
						webkit = owner && owner.webkitFullscreenElement,
						moz = owner && owner.mozFullScreenElement,
						ms = owner && owner.msFullscreenElement
					if (standard === node || webkit === node || moz === node || ms === node) return true
					if (standard === null && !webkit && !moz && !ms) return false
				}
				function isFullscreen(engine, node) {
					var state = engine.fullscreenState(node)
					if (state === false) return false
					var native = engine.matchesNative(node, ':fullscreen', void 0)
					return native === void 0 ? state === true : native
				}
				function isModal(engine, node) {
					var fullscreen = engine.fullscreenState(node)
					if (fullscreen === false && node.namespaceURI === 'http://www.w3.org/1999/xhtml' && engine.tagOf(node) !== 'dialog') return false
					var native = engine.matchesNative(node, ':modal', void 0)
					if (native !== void 0) return native
					return fullscreen === true || (fullscreen === void 0 && engine.matchesNative(node, ':fullscreen'))
				}
				function isPictureInPicture(engine, node) {
					var doc = node.ownerDocument
					return (
						!!(doc && (doc.pictureInPictureElement === node || node.webkitPresentationMode === 'picture-in-picture')) ||
						engine.matchesNative(node, ':picture-in-picture')
					)
				}
				function isPopoverOpen(engine, node) {
					return engine.hasAttrOf(node, 'popover') && engine.matchesNative(node, ':popover-open')
				}
				//#endregion
				//#region src/core/predicate/content-editable.mts
				function isContentEditable(engine, node) {
					if (node.ownerDocument && node.ownerDocument.designMode === 'on' && engine.connectedOf(node)) return true
					var attrValue = 'inherit'
					if (engine.hasAttrOf(node, 'contenteditable')) attrValue = engine.attrOf(node, 'contenteditable')
					switch (attrValue) {
						case '':
						case 'plaintext-only':
						case 'true':
							return true
						case 'false':
							return false
						default:
							if (node.parentNode && node.parentNode.nodeType === 1) return engine.isContentEditable(node.parentNode)
							return false
					}
				}
				//#endregion
				//#region src/core/predicate/form.mts
				function isDisabled(engine, element) {
					var legend,
						name = engine.tagOf(element),
						node
					if (element.disabled === true) return true
					if (name == 'option') {
						node = engine.upOf(element)
						while (node) {
							name = engine.tagOf(node)
							if (name == 'optgroup') {
								if (node.disabled === true) return true
								break
							}
							if (/^(?:option|select|datalist|hr)$/.test(name)) break
							node = engine.upOf(node)
						}
					}
					node = engine.upOf(element)
					while (node) {
						if (node.disabled === true && engine.tagOf(node) == 'fieldset') {
							legend = engine.firstOf(node)
							while (legend && engine.tagOf(legend) != 'legend') legend = engine.nextOf(legend)
							if (!(legend && legend.contains(element))) return true
						}
						node = engine.upOf(node)
					}
					return false
				}
				function isFocusable(engine, node) {
					var native = engine.Snapshot.matchesNative(node, ':focus', void 0),
						doc = node.ownerDocument
					if (native !== void 0) return native ? node : false
					if (node.contentDocument && engine.tagOf(node) == 'iframe') return false
					if (doc.hasFocus() && node === doc.activeElement) {
						if (node.type || node.href || typeof node.tabIndex == 'number') return node
					}
					return false
				}
				//#endregion
				//#region src/core/predicate/link.mts
				function isLink(engine, node) {
					return engine.reLinkName.test(engine.tagOf(node)) && engine.hasAttrOf(node, 'href')
				}
				//#endregion
				//#region src/core/predicate/media.mts
				function isMediaState(engine, media, state) {
					var native = engine.matchesNative(media, ':' + state, void 0)
					if (native !== void 0) return native
					if (media.namespaceURI !== 'http://www.w3.org/1999/xhtml' || !/^(audio|video)$/i.test(engine.tagOf(media))) return false
					switch (state) {
						case 'playing':
							return media.paused === false && media.ended !== true
						case 'paused':
							return media.paused === true || media.ended === true
						case 'seeking':
							return media.seeking === true
						case 'muted':
							return media.muted === true
						case 'buffering':
							return engine.isMediaState(media, 'playing') && media.networkState === 2 && media.readyState < 3
						default:
							return false
					}
				}
				//#endregion
				//#region src/core/match/native.mts
				function matchesNative(engine, node, selector, unavailable) {
					var matcher,
						ownerDoc = node.ownerDocument || engine.doc
					if (arguments.length - 1 < 3) unavailable = false
					if (engine.matchingNative) {
						engine.matchingNative.delegates = true
						return unavailable
					}
					prepareMatcherRecord(engine, ownerDoc)
					matcher =
						engine._matches ||
						((ownerDoc.defaultView || engine.primordials.ObjectPrototypeHasOwnProperty(node, 'matches')) && node.matches) ||
						(engine.ELEMENT_PROTO && engine.ELEMENT_PROTO.matches)
					matcher = resolveFallbackMatcher(engine, ownerDoc, matcher)
					if (matcher !== engine.matcherRecord.matcher) {
						engine.matcherRecord.matcher = matcher
						engine.matcherRecord.delegates = false
					}
					if (!matcher || engine.matcherRecord.delegates) return unavailable
					try {
						engine.matchingNative = engine.matcherRecord
						var result = matcher.call(node, selector)
						return engine.matchingNative.delegates ? unavailable : result
					} catch (e) {
						return unavailable
					} finally {
						engine.matchingNative = null
					}
				}
				function prepareMatcherRecord(engine, ownerDoc) {
					if (ownerDoc !== engine.matcherDoc) {
						if (engine.matcherCache === null) engine.matcherCache = engine.createWeakMap()
						engine.matcherDoc = ownerDoc
						engine.matcherRecord = engine.matcherCache && engine.matcherCache.get(ownerDoc)
						if (!engine.matcherRecord) {
							engine.matcherRecord = {
								fallback: null,
								matcher: void 0,
								delegates: false
							}
							if (engine.matcherCache) engine.matcherCache.set(ownerDoc, engine.matcherRecord)
						}
					}
				}
				function resolveFallbackMatcher(engine, ownerDoc, matcher) {
					if (!matcher && engine.Config.LEGACY) {
						var view = ownerDoc.defaultView,
							proto = view && view.Element && view.Element.prototype
						if (engine.matcherRecord.fallback === null)
							engine.matcherRecord.fallback =
								engine.legacyHooks.matcher(proto) || (proto !== engine.ELEMENT_PROTO ? engine.legacyHooks.matcher(engine.ELEMENT_PROTO) : void 0)
						matcher = engine.matcherRecord.fallback
					}
					return matcher
				}
				//#endregion
				//#region src/core/predicate/logical-compound.mts
				function isLogicalCompound(name) {
					return /^(?:not|is|where)$/.test(name)
				}
				//#endregion
				//#region src/core/predicate/picker-transition.mts
				function isPickerTransition(previous, engine, name) {
					return previous == 'picker' && engine.treePseudo(name)
				}
				//#endregion
				//#region src/core/validation/pseudo/transition.mts
				function rejectsPseudoTransition(previous, name, engine) {
					return (
						previous &&
						!(previous == 'part' && name != 'part' && name != 'slotted') &&
						!(previous == 'details-content' && name != 'part' && name != 'slotted') &&
						!(previous == 'slotted' && engine.treePseudo(name)) &&
						!(/^(?:before|after)$/.test(previous) && (name == 'marker' || name == 'column')) &&
						!(previous == 'column' && name == 'scroll-marker') &&
						!isPickerTransition(previous, engine, name)
					)
				}
				//#endregion
				//#region src/core/validation/pseudo/states.mts
				function validPseudoStates(engine, text, context) {
					var token, name, argument, valid
					while (text) {
						token = engine.readPseudo(text)
						if (!token || token.double) return false
						name = token.name
						argument = token.argument
						if (name == 'is' || name == 'where') {
							if (argument === null) return false
						} else if (name == 'not') {
							if (
								!argument ||
								!engine.splitList(argument).every(function (item) {
									return engine.validPseudoStates(item, context)
								})
							)
								return false
						} else {
							validateStateContext()
							if (!valid || !engine.validateLogical(text.slice(0, text.length - token.rest.length), false)) return false
						}
						text = token.rest
					}
					return true
					function validateStateContext() {
						if (context == 'part' || context == 'details-content')
							valid = !/^(?:root|scope|empty|host|host-context|has|has-slotted|nth-.+|(?:first|last|only)-(?:child|of-type))$/.test(name)
						else if (context == 'search-text') valid = name == 'current' && argument === null
						else if (context.indexOf('view-transition-') == 0) valid = name == 'only-child' && argument === null
						else {
							valid =
								(engine.treePseudo(context) || context == 'scroll-button' || context.indexOf('-webkit-') == 0) &&
								/^(?:hover|active|focus|focus-visible|focus-within)$/.test(name)
							if (context == 'scroll-button' && /^(?:enabled|disabled)$/.test(name)) valid = true
						}
					}
				}
				function validPseudoTail(engine, text) {
					var token,
						name,
						context = '',
						states = '',
						previous
					while (text) {
						token = engine.readPseudo(text)
						if (!token) return false
						name = token.name
						if (token.double || (!context && /^(?:before|after|first-line|first-letter)$/.test(name))) {
							if (states && !engine.validPseudoStates(states, context)) return false
							states = ''
							previous = context
							if (rejectsPseudoTransition(previous, name, engine)) return false
							if (!engine.validPseudoElement(name, token.argument)) return false
							context = name
						} else states += text.slice(0, text.length - token.rest.length)
						text = token.rest
					}
					return !states || engine.validPseudoStates(states, context)
				}
				function validPseudoSyntax(engine, text) {
					var quote = '',
						bracket = 0,
						i = 0,
						char,
						token
					for (var textLength = text.length; i < textLength; ++i) {
						char = text.charAt(i)
						if (char == '\\') {
							++i
							continue
						}
						if (quote) {
							if (char == quote) quote = ''
							continue
						}
						if (isStringQuote(char)) {
							quote = char
							continue
						}
						if (char == '[') {
							++bracket
							continue
						}
						if (char == ']') {
							--bracket
							continue
						}
						if (bracket || char != ':') continue
						token = engine.readPseudo(text.slice(i))
						if (!token) continue
						if ((token.double || /^(?:before|after|first-line|first-letter)$/.test(token.name)) && !engine.isPseudoExtension(text.slice(i)))
							return engine.validPseudoTail(text.slice(i))
						i = text.length - token.rest.length - 1
					}
					return true
				}
				function hasHost(engine, text) {
					var testHostTokenDone = false
					var testHostTokenValue
					var quote = '',
						bracket = 0,
						i = 0,
						char,
						token
					for (var textLength = text.length; i < textLength; ++i) {
						char = text.charAt(i)
						if (char == '\\') {
							++i
							continue
						}
						if (quote) {
							if (char == quote) quote = ''
							continue
						}
						if (isStringQuote(char)) {
							quote = char
							continue
						}
						if (char == '[') {
							++bracket
							continue
						}
						if (char == ']') {
							--bracket
							continue
						}
						if (bracket || char != ':') continue
						token = engine.readPseudo(text.slice(i))
						testHostToken()
						if (testHostTokenDone) return testHostTokenValue
						if (token) i = text.length - token.rest.length - 1
					}
					return false
					function testHostToken() {
						if (token && !token.double && (/^host(?:-context)?$/.test(token.name) || (token.argument !== null && engine.hasHost(token.argument)))) {
							testHostTokenValue = true
							testHostTokenDone = true
							return
						}
					}
				}
				function prepareCompound(engine, text) {
					if (!engine.isCompound(text)) return null
					var quote = '',
						bracket = 0,
						i = 0,
						char,
						token,
						items,
						result = '',
						start = 0
					for (var textLength = text.length; i < textLength; ++i) {
						char = text.charAt(i)
						if (char == '\\') {
							++i
							continue
						}
						if (quote) {
							if (char == quote) quote = ''
							continue
						}
						if (isStringQuote(char)) {
							quote = char
							continue
						}
						if (char == '[') {
							++bracket
							continue
						}
						if (char == ']') {
							--bracket
							continue
						}
						if (bracket || char != ':') continue
						token = engine.readPseudo(text.slice(i))
						if (!token || token.argument === null || !isLogicalCompound(token.name)) continue
						if (!prepareLogicalToken(token)) return null
						i = text.length - token.rest.length - 1
						start = i + 1
					}
					return result + text.slice(start)
					function prepareLogicalToken(token) {
						items = engine.splitList(token.argument).map(engine.prepareCompound)
						if (
							token.name == 'not' &&
							items.some(function (item) {
								return item === null
							})
						)
							return false
						result +=
							text.slice(start, i) +
							':' +
							token.name +
							'(' +
							(items
								.filter(function (item) {
									return item !== null
								})
								.join(',') || ':not(*)') +
							')'
						return true
					}
				}
				function shadowRootOf(_engine, scope) {
					var root = scope.getRootNode ? scope.getRootNode() : scope
					return root.nodeType == 11 && 'host' in root ? root : null
				}
				function shadowParent(engine, element, scope) {
					var root = engine.shadowRootOf(scope)
					if (root && root.host === element) return null
					return element.parentElement || (root && element.parentNode === root ? root.host : null)
				}
				function isHost(engine, element, argument, contextual, scope) {
					var root = engine.shadowRootOf(scope),
						current = element
					if (!root || root.host !== element) return false
					if (argument === null) return true
					do {
						if (engine.match(argument, current)) return true
						current = contextual ? engine.upOf(current) : null
					} while (current)
					return false
				}
				//#endregion
				//#region src/core/predicate/parsed-pseudo-element.mts
				function isParsedPseudoElement(pseudo, engine, text, i) {
					return (pseudo.double && !engine.isPseudoExtension(text.slice(i))) || /^(?:before|after|first-line|first-letter)$/.test(pseudo.name)
				}
				//#endregion
				//#region src/core/validation/pseudo/control.mts
				function validControlPseudo(engine, name, argument) {
					if (name == 'picker') return argument !== null && engine.unescapeIdentifier(argument).toLowerCase() == 'select'
					if (name == 'scroll-button')
						return (
							argument !== null &&
							/^(?:\*|up|down|left|right|block-start|block-end|inline-start|inline-end)$/.test(engine.unescapeIdentifier(argument).toLowerCase())
						)
					return false
				}
				//#endregion
				//#region src/core/validation/pseudo/shadow.mts
				function validShadowPseudo(engine, name, argument) {
					if (name == 'part')
						return (
							argument !== null &&
							!!argument &&
							argument.split(/[\t\n\f\r ]+/).every(function (part) {
								return engine.isIdent(part)
							})
						)
					if (name == 'slotted')
						return argument !== null && engine.isCompound(argument) && !engine.hasPseudoElement(argument) && engine.validateLogical(argument, false)
					return false
				}
				//#endregion
				//#region src/core/validation/logical.mts
				function validateLogical(engine, argument, relative) {
					var previousErrors = engine.errors,
						selectVars = engine.S_VARS,
						matchVars = engine.M_VARS,
						nodeVars = engine.N_VARS,
						list = engine.splitList(argument),
						parsed
					engine.S_VARS = []
					engine.M_VARS = []
					engine.N_VARS = []
					try {
						for (var listLength = list.length, i = 0; i < listLength; ++i) {
							if (!list[i]) {
								engine.emit(engine.qsInvalid)
								return false
							}
							parsed = engine.parse(relative ? '* ' + list[i] : list[i], false)
							if (!parsed) return false
							for (var parsedLength = parsed.length, j = 0; j < parsedLength; ++j) engine.compileSelector(parsed[j], '', relative, false)
						}
						return engine.errors == previousErrors
					} finally {
						engine.S_VARS = selectVars
						engine.M_VARS = matchVars
						engine.N_VARS = nodeVars
					}
				}
				function prepareHas(engine, text) {
					var i = 0,
						quote = 0,
						bracket = 0,
						code,
						logical,
						items,
						kept,
						item,
						output = '',
						start = 0
					for (var textLength = text.length; i < textLength; ++i) {
						code = text.charCodeAt(i)
						if (code == 92) {
							++i
							continue
						}
						if (quote) {
							if (code == quote) quote = 0
							continue
						}
						if (code == 34 || code == 39) {
							quote = code
							continue
						}
						if (code == 91) {
							++bracket
							continue
						}
						if (code == 93) {
							--bracket
							continue
						}
						if (bracket || code != 58) continue
						if (/^:(?:has\(|:|(?:before|after|first-line|first-letter)(?![-\w]))/i.test(text.slice(i))) return null
						expandForgivingHas()
					}
					return output + text.slice(start)
					function expandForgivingHas() {
						if (engine.Config.FORGIVING && (logical = engine.matchLogical(text.slice(i), /^:(is|where)\(/i))) {
							items = engine.splitList(logical[2])
							kept = []
							for (var itemsLength = items.length, j = 0; j < itemsLength; ++j) {
								item = engine.prepareHas(items[j])
								if (item !== null) kept.push(item)
							}
							output += text.slice(start, i) + ':' + logical[1] + '(' + (kept.join(',') || ':not(*)') + ')'
							i += logical[0].length - 1
							start = i + 1
						}
					}
				}
				function readPseudo(engine, text) {
					var double = text.charAt(1) == ':',
						start = double ? 2 : 1,
						identifier = engine.Patterns.tagName.exec(text.slice(start)),
						end,
						block,
						name
					if (text.charAt(0) != ':' || !identifier) return null
					name = engine.unescapeIdentifier(identifier[1]).toLowerCase()
					end = start + identifier[1].length
					if (text.charAt(end) == '(') {
						block = engine.matchLogical(':x' + text.slice(end), /^:(x)\(/)
						return {
							name: name,
							double: double,
							argument: block[2],
							rest: block[3]
						}
					}
					return {
						name: name,
						double: double,
						argument: null,
						rest: text.slice(end)
					}
				}
				function isIdent(engine, text, custom) {
					var token = engine.Patterns.tagName.exec(text)
					return !!token && !token[2] && (!custom || !/^(?:initial|inherit|unset|revert|revert-layer|default)$/i.test(engine.unescapeIdentifier(text)))
				}
				function hasPseudoElement(engine, text) {
					var quote = '',
						bracket = 0,
						i = 0,
						char,
						pseudo
					for (var textLength = text.length; i < textLength; ++i) {
						char = text.charAt(i)
						if (char == '\\') {
							++i
							continue
						}
						if (quote) {
							if (char == quote) quote = ''
							continue
						}
						if (isStringQuote(char)) {
							quote = char
							continue
						}
						if (char == '[') {
							++bracket
							continue
						}
						if (char == ']') {
							--bracket
							continue
						}
						if (bracket || char != ':') continue
						pseudo = engine.readPseudo(text.slice(i))
						if (!pseudo) continue
						if (isParsedPseudoElement(pseudo, engine, text, i)) return true
						if (pseudo.name == 'is' || pseudo.name == 'where') i = text.length - pseudo.rest.length - 1
					}
					return false
				}
				function treePseudo(_engine, name) {
					return /^(?:before|after|marker|placeholder|file-selector-button|details-content|checkmark|picker-icon|picker|backdrop|scroll-marker|scroll-marker-group)$/.test(
						name
					)
				}
				function validPseudoElement(engine, name, argument) {
					var validateViewTransitionDone = false
					var validateViewTransitionValue
					var pieces
					if (name === 'part' || name === 'slotted') return validShadowPseudo(engine, name, argument)
					if (name == 'highlight') return argument !== null && (argument == '*' || engine.isIdent(argument, true))
					if (name === 'picker' || name === 'scroll-button') return validControlPseudo(engine, name, argument)
					validateViewTransition()
					if (validateViewTransitionDone) return validateViewTransitionValue
					if (name == 'cue' || name == 'cue-region') return argument === null || validShadowPseudo(engine, 'slotted', argument)
					return (
						argument === null &&
						(engine.treePseudo(name) ||
							/^(?:column|first-line|first-letter|selection|target-text|spelling-error|grammar-error|search-text|view-transition|-webkit-[-a-z0-9]{2,})$/.test(
								name
							))
					)
					function validateViewTransition() {
						if (/^view-transition-(?:group|image-pair|old|new|group-children)$/.test(name)) {
							if (argument === null) {
								validateViewTransitionValue = false
								validateViewTransitionDone = true
								return
							}
							pieces = argument.charAt(0) == '*' ? argument.slice(1) : argument
							if (argument.charAt(0) != '*') {
								var first = engine.Patterns.tagName.exec(pieces)
								if (!first || !engine.isIdent(first[1], true)) {
									validateViewTransitionValue = false
									validateViewTransitionDone = true
									return
								}
								pieces = first[2]
							}
							while (pieces) {
								if (pieces.charAt(0) != '.') {
									validateViewTransitionValue = false
									validateViewTransitionDone = true
									return
								}
								var part = engine.Patterns.tagName.exec(pieces.slice(1))
								if (!part || !engine.isIdent(part[1], true)) {
									validateViewTransitionValue = false
									validateViewTransitionDone = true
									return
								}
								pieces = part[2]
							}
							validateViewTransitionValue = true
							validateViewTransitionDone = true
							return
						}
					}
				}
				function isPseudoExtension(engine, text) {
					for (var name in engine.Selectors)
						if (text.search(engine.Selectors[name].Expression) == 0) {
							var token = engine.readPseudo(text)
							return !!token && token.double && !engine.validPseudoElement(token.name, token.argument)
						}
					return false
				}
				//#endregion
				//#region src/core/initialize/matching.mts
				function initializeMatching(engine) {
					engine.nthElement = createNthElement(engine)
					engine.nthFiltered = nthFiltered.bind(null, engine)
					engine.nthOfType = createNthOfType(engine)
					engine.ancestorMasks = null
					engine.lastMaskNode = null
					engine.lastMaskValue = 0
					engine.tagBits = engine.primordials.ObjectCreate(null)
					engine.tagBitCount = 0
					engine.tagBit = tagBit.bind(null, engine)
					engine.ancestorMask = ancestorMask.bind(null, engine)
					engine.FILTER_SAMPLE = 64
					engine.FILTER_KEEP = 48
					engine.FILTER_RETRY = 4096
					engine.mayMatch = mayMatch.bind(null, engine)
					engine.clearAncestorMasks = clearAncestorMasks.bind(null, engine)
					engine.isHTML = isHTML.bind(null, engine)
					engine.isDefined = isDefined.bind(null, engine)
					engine.isRequired = isRequired.bind(null, engine)
					engine.isContentEditable = isContentEditable.bind(null, engine)
					engine.isDisabled = isDisabled.bind(null, engine)
					engine.isFocusable = isFocusable.bind(null, engine)
					engine.matchesNative = matchesNative.bind(null, engine)
					engine.matchingNative = null
					engine.matcherDoc = null
					engine.matcherRecord = null
					engine.matcherCache = null
					engine.isOpen = isOpen.bind(null, engine)
					engine.isClosed = isClosed.bind(null, engine)
					engine.fullscreenState = fullscreenState.bind(null, engine)
					engine.isFullscreen = isFullscreen.bind(null, engine)
					engine.isModal = isModal.bind(null, engine)
					engine.isPictureInPicture = isPictureInPicture.bind(null, engine)
					engine.isPopoverOpen = isPopoverOpen.bind(null, engine)
					engine.isLink = isLink.bind(null, engine)
					engine.isMediaState = isMediaState.bind(null, engine)
					engine.configure = configure.bind(null, engine)
					engine.errors = 0
					engine.emit = emit.bind(null, engine)
					engine.initialize = initialize.bind(null, engine)
					engine.setIdentifierSyntax = setIdentifierSyntax.bind(null, engine)
					engine.compilePrefixes = [
						'selector:false:false:',
						'selector:false:true:',
						'selector:true:false:',
						'selector:true:true:',
						'selector:null:false:',
						'selector:null:true:',
						'relative:false:false:',
						'relative:false:true:',
						'relative:true:false:',
						'relative:true:true:',
						'relative:null:false:',
						'relative:null:true:'
					]
					engine.F_INIT = '"use strict";return function Resolver(c,f,x,r,v,p)'
					engine.S_HEAD = 'var e,n,o,j=r.length-1,k=-1,l=c.length'
					engine.M_HEAD = 'var e,n,o'
					engine.N_HEAD = 'var e,n,o,j=r.length-1,k=-1,l=c.length'
					engine.S_LOOP = 'main:while(++k<l&&(e=c[k])!==undefined)'
					engine.M_LOOP = 'e=c;'
					engine.N_LOOP = 'main:while(++k<l&&(e=c.item(k))!==undefined)'
					engine.S_BODY = 'r[++j]=c[k];'
					engine.M_BODY = ''
					engine.N_BODY = 'r[++j]=c.item(k);'
					engine.S_TAIL = 'continue main;'
					engine.M_TAIL = 'r=true;'
					engine.N_TAIL = 'continue main;'
					engine.S_TEST = 'if(f(c[k])){break main;}'
					engine.M_TEST = 'f(c);'
					engine.N_TEST = 'if(f(c.item(k))){break main;}'
					engine.S_VARS = []
					engine.M_VARS = []
					engine.N_VARS = []
					engine.canReuseAncestor = canReuseAncestor.bind(null, engine)
					engine.compile = compile.bind(null, engine)
					engine.isCompound = isCompound.bind(null, engine)
					engine.validateLogical = validateLogical.bind(null, engine)
					engine.prepareHas = prepareHas.bind(null, engine)
					engine.readPseudo = readPseudo.bind(null, engine)
					engine.isIdent = isIdent.bind(null, engine)
					engine.hasPseudoElement = hasPseudoElement.bind(null, engine)
					engine.treePseudo = treePseudo.bind(null, engine)
					engine.validPseudoElement = validPseudoElement.bind(null, engine)
					engine.isPseudoExtension = isPseudoExtension.bind(null, engine)
					engine.validPseudoStates = validPseudoStates.bind(null, engine)
					engine.validPseudoTail = validPseudoTail.bind(null, engine)
					engine.validPseudoSyntax = validPseudoSyntax.bind(null, engine)
					engine.hasHost = hasHost.bind(null, engine)
					engine.prepareCompound = prepareCompound.bind(null, engine)
					engine.shadowRootOf = shadowRootOf.bind(null, engine)
					engine.shadowParent = shadowParent.bind(null, engine)
					engine.isHost = isHost.bind(null, engine)
					engine.hasSlotted = hasSlotted.bind(null, engine)
					engine.directionality = engine.Factory._direction.directionality
					engine.isDirection = isDirection.bind(null, engine)
					engine.isLanguage = isLanguage.bind(null, engine)
					engine.validBlocks = validBlocks.bind(null, engine)
					engine.notFlag = 0
					engine.compileSelector = compileSelector.bind(null, engine)
					engine.ancestor = ancestor.bind(null, engine)
					engine.match_assert = match_assert.bind(null, engine)
					engine.match_collect = match_collect.bind(null, engine)
					engine.prepareForgiving = prepareForgiving.bind(null, engine)
					engine.matchPreparedForgiving = matchPreparedForgiving.bind(null, engine)
					engine.forgivingKey = forgivingKey.bind(null, engine)
					engine.matchForgivingKey = matchForgivingKey.bind(null, engine)
					engine.selectorComments = selectorComments.bind(null, engine)
					engine.stringContinuations = stringContinuations.bind(null, engine)
				}
				//#endregion
				//#region src/core/select/neural-planner.mts
				function neuralPlannerPolicy(host) {
					if (host === 'chromium') return cachedPolicy(chromiumPolicy)
					if (host === 'jsdom') return cachedPolicy(jsdomPolicy)
					throw new TypeError('Select the chromium or jsdom experimental policy')
				}
				function chromiumPolicy(anchors, witnesses, attributes, dense, ratio) {
					if (!supportedInputs(anchors, witnesses, attributes, dense, ratio)) return false
					var h0 = Math.max(
						0,
						4.17953744832907 +
							0.006445970393207164 * anchors +
							-0.001237694714117135 * witnesses +
							-1.6934969987790789 * (attributes >> 1) +
							1.9987740403888223 * (attributes & 1) +
							-0.28316059708595276 * dense +
							-1.2101973692576091 * ratio
					)
					var h1 = Math.max(
						0,
						2.597287748725064 +
							0.009217632292722143 * anchors +
							0.0025723836936285944 * witnesses +
							-0.888835499375548 * (attributes >> 1) +
							-1.3368763712854246 * (attributes & 1) +
							0.05107470974326134 * dense +
							-0.6854634284973145 * ratio
					)
					var h2 = Math.max(
						0,
						1.9602088835128941 +
							0.0016921339906772743 * anchors +
							-0.0011679149315742931 * witnesses +
							2.0679337313410158 * (attributes >> 1) +
							-2.0143598606744537 * (attributes & 1) +
							0.052165184170007706 * dense +
							-0.38973840077718097 * ratio
					)
					var h3 = Math.max(
						0,
						8.011757617079402 +
							-0.012647065327815697 * anchors +
							-0.0055700006392621825 * witnesses +
							-2.1309548602481425 * (attributes >> 1) +
							0.0638230346032306 * (attributes & 1) +
							0.17864754796028137 * dense +
							-0.8110613028208414 * ratio
					)
					var value = 1.018654465675354 + 0.8310559988021851 * h0 + 0.8028913736343384 * h1 + 0.6000171303749084 * h2 + 0.945857048034668 * h3
					return finiteScore(value) && value > 3.00001
				}
				function jsdomPolicy(anchors, witnesses, attributes, dense, ratio) {
					if (!supportedInputs(anchors, witnesses, attributes, dense, ratio)) return false
					var value =
						2.2545929735779073 +
						0.0063056536826381305 * anchors +
						-7610142811483255e-20 * witnesses +
						-0.9932116883067986 * (attributes >> 1) +
						-0.6860170118907837 * (attributes & 1) +
						0.1816803365945816 * dense +
						-0.19068167554763876 * ratio
					return finiteScore(value) && value > 1e-5
				}
				function supportedInputs(anchors, witnesses, attributes, dense, ratio) {
					return (
						supportedCategory(attributes, dense) &&
						witnesses > anchors * 2 &&
						(!dense || anchors > 192 || witnesses > anchors * 4) &&
						within(anchors, 32, 192) &&
						within(witnesses, 80, 768) &&
						within(ratio, 2.5, 4)
					)
				}
				function supportedCategory(attributes, dense) {
					return (attributes === 0 && dense === 1) || ((attributes === 1 || attributes === 2 || attributes === 3) && dense === 0)
				}
				function within(value, minimum, maximum) {
					return value >= minimum && value <= maximum
				}
				function finiteScore(value) {
					return value === value && value !== Infinity && value !== -Infinity
				}
				function cachedPolicy(policy) {
					var lastAnchors = -1
					var lastWitnesses = -1
					var lastAttributes = -1
					var lastDense = -1
					var answer = false
					return function (anchors, witnesses, attributes, dense, ratio) {
						if (anchors === lastAnchors && witnesses === lastWitnesses && attributes === lastAttributes && dense === lastDense) return answer
						answer = policy(anchors, witnesses, attributes, dense, ratio)
						lastAnchors = anchors
						lastWitnesses = witnesses
						lastAttributes = attributes
						lastDense = dense
						return answer
					}
				}
				//#endregion
				//#region src/core/match/child.mts
				function hasChild(engine, element, tag) {
					var child = engine.firstOf(element)
					if (tag == '*') return !!child
					while (child) {
						if (engine.matchesTag(child, tag)) return true
						child = engine.nextOf(child)
					}
					return false
				}
				//#endregion
				//#region src/core/cache/weight.mts
				var PLAN_BYTES = 2097152
				function resolverWeight(resolver) {
					return resolver ? resolver.cacheSize || 64 : 8
				}
				function resolverListWeight(resolvers) {
					var bytes = 32
					for (var i = 0, length = resolvers.length; i < length; ++i) bytes += resolverWeight(resolvers[i])
					return bytes
				}
				function queryWeight(plan) {
					var bytes = 64
					for (var i = 0, length = plan.nodeset.length; i < length; ++i) bytes += plan.nodeset[i].length * 2 + resolverWeight(plan.factory[i] || null)
					if (plan.bulkHas) bytes += queryWeight(plan.bulkHas.anchor) + queryWeight(plan.bulkHas.witness)
					return bytes
				}
				function relativeWeight(plans) {
					var bytes = 32
					for (var i = 0, length = plans.length; i < length; ++i) bytes += queryWeight(plans[i])
					return bytes
				}
				function forgivingWeight(plans) {
					var bytes = 32
					for (var i = 0, length = plans.length; i < length; ++i) bytes += plans[i] ? resolverListWeight(plans[i]) : 8
					return bytes
				}
				//#endregion
				//#region src/core/compile/position/first.mts
				function firstPosition(element, state) {
					if (element === state.element) return state.index
					var node = element.previousElementSibling,
						index = 1
					while (node) {
						if (node === state.element) {
							index += state.index
							break
						}
						++index
						node = node.previousElementSibling
					}
					state.element = element
					state.index = index
					return index
				}
				//#endregion
				//#region src/core/parser/selector.mts
				function parse(engine, selectors, type) {
					var validateSelectorGroupsDone = false
					var validateSelectorGroupsValue
					var parsed
					if (arguments.length - 1 === 0) {
						engine.emit(engine.qsNotArgs, TypeError)
						return invalidInput()
					} else if (arguments[1] === '') {
						engine.emit("''" + engine.qsInvalid)
						return invalidInput()
					} else if (/^[.#]?\d/.test(selectors)) {
						engine.emit("''" + engine.qsInvalid)
						return invalidInput()
					}
					if (typeof selectors != 'string') selectors = '' + selectors
					selectors = engine.stringContinuations(engine.selectorComments(selectors))
					if (!engine.validBlocks(selectors)) {
						engine.emit("'" + selectors + "'" + engine.qsInvalid)
						return type ? engine.none : false
					}
					parsed = selectors
						.replace(/\x00|\\$/g, '�')
						.replace(engine.REX.CombineWSP, function (part) {
							return part[0] == '\\' ? part.replace(/\r\n/g, ' ') : ' '
						})
						.replace(engine.REX.TabCharWSP, '	')
						.replace(engine.REX.CommaGroup, ',')
						.replace(engine.REX.TrimSpaces, '')
					validateSelectorGroups()
					if (validateSelectorGroupsDone) return validateSelectorGroupsValue
					var groups = selectors
					if (groups && !groups.every(engine.validPseudoSyntax)) {
						engine.emit("'" + parsed + "'" + engine.qsInvalid)
						return type ? engine.none : false
					}
					return groups
					function invalidInput() {
						return engine.Config.VERBOSITY ? void 0 : type ? engine.none : false
					}
					function validateSelectorGroups() {
						if ((selectors = parsed.match(engine.reValidator)) && selectors.join('') == parsed) {
							selectors = engine.splitList(parsed)
							if (parsed[parsed.length - 1] == ',') {
								engine.emit(engine.qsInvalid)
								validateSelectorGroupsValue = engine.Config.VERBOSITY ? void 0 : type ? engine.none : false
								validateSelectorGroupsDone = true
								return
							}
						} else if (engine.Config.FORGIVING) {
							if (!(engine.includes(parsed, ':is(') || engine.includes(parsed, ':where('))) {
								engine.emit("'" + parsed + "'" + engine.qsInvalid)
								validateSelectorGroupsValue = engine.Config.VERBOSITY ? void 0 : type ? engine.none : false
								validateSelectorGroupsDone = true
								return
							}
							selectors = engine.splitList(parsed)
						}
					}
				}
				//#endregion
				//#region src/core/dom/install.mts
				function argsWith(engine, args, tail) {
					switch (args.length) {
						case 0:
							return [tail]
						case 1:
							return [args[0], tail]
						case 2:
							return [args[0], args[1], tail]
						case 3:
							return [args[0], args[1], args[2], tail]
						case 4:
							return [args[0], args[1], args[2], args[3], tail]
						case 5:
							return [args[0], args[1], args[2], args[3], args[4], tail]
						case 6:
							return [args[0], args[1], args[2], args[3], args[4], args[5], tail]
						case 7:
							return [args[0], args[1], args[2], args[3], args[4], args[5], args[6], tail]
						case 8:
							return [args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], tail]
						default:
							return engine.sliceCall(args).concat(tail)
					}
				}
				function install(engine, all) {
					var Element = engine.global.Element,
						HTMLElement = engine.global.HTMLElement,
						Document = engine.global.Document,
						DocumentFragment = engine.global.DocumentFragment
					engine._closest = Element.prototype.closest
					engine._matches = Element.prototype.matches
					engine._querySelector = Element.prototype.querySelector
					engine._querySelectorAll = Element.prototype.querySelectorAll
					engine._querySelectorDoc = Document.prototype.querySelector
					engine._querySelectorAllDoc = Document.prototype.querySelectorAll
					function parseQSArgs() {
						var method = arguments[arguments.length - 1]
						return arguments.length < 2
							? method.apply(this, [])
							: arguments.length < 3
								? method.apply(this, [arguments[0], this])
								: method.apply(this, [arguments[0], this, typeof arguments[1] == 'function' ? arguments[1] : void 0])
					}
					Element.prototype.closest = HTMLElement.prototype.closest = function closest() {
						return parseQSArgs.apply(this, engine.argsWith(arguments, engine.ancestor))
					}
					Element.prototype.matches = HTMLElement.prototype.matches = function matches() {
						return parseQSArgs.apply(this, engine.argsWith(arguments, engine.match))
					}
					Element.prototype.querySelector = HTMLElement.prototype.querySelector = function querySelector() {
						return parseQSArgs.apply(this, engine.argsWith(arguments, engine.first))
					}
					Element.prototype.querySelectorAll = HTMLElement.prototype.querySelectorAll = function querySelectorAll() {
						return engine.toNodeList(parseQSArgs.apply(this, engine.argsWith(arguments, engine.select)))
					}
					Document.prototype.querySelector = DocumentFragment.prototype.querySelector = function querySelector() {
						return parseQSArgs.apply(this, engine.argsWith(arguments, engine.first))
					}
					Document.prototype.querySelectorAll = DocumentFragment.prototype.querySelectorAll = function querySelectorAll() {
						return engine.toNodeList(parseQSArgs.apply(this, engine.argsWith(arguments, engine.select)))
					}
					if (all && engine.legacyHooks)
						engine.legacyHooks.installFrames(engine.doc, function (window) {
							return engine.Factory(window)
						})
				}
				function uninstall(engine) {
					var Element = engine.global.Element,
						HTMLElement = engine.global.HTMLElement,
						Document = engine.global.Document,
						DocumentFragment = engine.global.DocumentFragment
					if (engine._closest) {
						Element.prototype.closest = engine._closest
						HTMLElement.prototype.closest = engine._closest
					}
					if (engine._matches) {
						Element.prototype.matches = engine._matches
						HTMLElement.prototype.matches = engine._matches
					}
					if (engine._querySelector) {
						Element.prototype.querySelector = HTMLElement.prototype.querySelector = engine._querySelector
						Element.prototype.querySelectorAll = HTMLElement.prototype.querySelectorAll = engine._querySelectorAll
					}
					if (engine._querySelectorAllDoc) {
						Document.prototype.querySelector = DocumentFragment.prototype.querySelector = engine._querySelectorDoc
						Document.prototype.querySelectorAll = DocumentFragment.prototype.querySelectorAll = engine._querySelectorAllDoc
					}
				}
				//#endregion
				//#region src/core/select/candidates.mts
				function selectCandidates(engine, token, context, resolver) {
					if (resolver && !engine.Config.LEGACY && !hasExtensions(engine)) return engine.hasCandidates(token, context)
					return engine.fetch[token[0]](token.slice(1), context)
				}
				function hasExtensions(engine) {
					for (var name in engine.Selectors) if (engine.Selectors[name]) return true
					for (var symbol in engine.Combinators) if (engine.Combinators[symbol]) return true
					return false
				}
				//#endregion
				//#region src/core/select/collect.mts
				function collect(engine, selectors, context, callback, relative, firstOnly, existenceOnly) {
					var i,
						l,
						seen = {},
						token = ['', '*', '*'],
						optimized = selectors,
						_$factory = Array(selectors.length),
						candidates,
						nodeset = Array(selectors.length),
						results = [],
						type
					for (i = 0, l = selectors.length; l > i; ++i) {
						if (!seen[selectors[i]] && (seen[selectors[i]] = true)) {
							optimizeCandidateToken()
							routeAttributeSelector()
						}
						token[2] = engine.unescapeIdentifier(token[2])
						nodeset[i] = token[1] + token[2]
						_$factory[i] = engine.compile(optimized[i], existenceOnly || !firstOnly, null, relative, existenceOnly)
						if (firstOnly) continue
						candidates = selectCandidates(engine, token[1] + token[2], context, _$factory[i] !== null)
						if (_$factory[i]) _$factory[i](candidates, callback, context, results)
						else engine.concatList(results, candidates)
					}
					if (l > 1) {
						results.sort(engine.documentOrder)
						engine.hasDupes && (results = engine.unique(results))
					}
					return {
						factory: _$factory,
						nodeset: nodeset,
						results: results
					}
					function optimizeCandidateToken() {
						type = selectors[i].match(engine.reOptimizer)
						if (type && type[1] != ':' && selectors[i].indexOf('\\') < 0 && (token = type)) {
							token[1] || (token[1] = '*')
							optimized[i] = engine.optimize(optimized[i], token)
						} else {
							token = ['', '*', '*']
							type = /:(?:is|where)\(([a-z][a-z0-9-]*(?:[\t\n\f\r ]*,[\t\n\f\r ]*[a-z][a-z0-9-]*)+)\)$/.exec(selectors[i])
							if (!firstOnly && type && /^[.#*\w\t\n\f\r >+~-]*$/.test(selectors[i].slice(0, type.index))) token = ['', '?', type[1]]
						}
					}
					function routeAttributeSelector() {
						if (
							engine.HTML_DOCUMENT &&
							!engine.Config.LEGACY &&
							(type = selectors[i].match(engine.Patterns['attribute'])) &&
							type[0] == selectors[i] &&
							type[1] == 'class' &&
							type[2] == '~=' &&
							type[4] &&
							type[5] != 'i' &&
							!/[\t\n\f\r ]/.test(engine.unescapeIdentifier(type[4])) &&
							engine.Operators['~='].p1 == '(^|[\\t\\n\\f\\r ])' &&
							engine.Operators['~='].p2 == '([\\t\\n\\f\\r ]|$)' &&
							engine.Operators['~='].p3 == 'true'
						)
							token = ['', '.', type[4]]
					}
				}
				//#endregion
				//#region src/core/dom/hover.mts
				function hoverChanged(engine, event) {
					var targetDoc = event.target.ownerDocument || event.target,
						record = engine.hoverTracked ? engine.hoverTracked.get(targetDoc) : targetDoc === engine.hoverDoc ? engine.hoverRecord : void 0
					if (record) {
						record.target = event.type == 'mouseover' ? event.target : void 0
						if (targetDoc === engine.doc) engine.Snapshot.HOVER = record.target
					}
				}
				function trackHover(engine) {
					engine.hoverWanted = true
					if (!engine.doc) return
					if (engine.hoverTracked === null) engine.hoverTracked = engine.createWeakMap()
					var record = engine.hoverTracked ? engine.hoverTracked.get(engine.doc) : engine.hoverDoc === engine.doc ? engine.hoverRecord : void 0
					if (!record) {
						record = {
							target: void 0
						}
						if (engine.hoverTracked) engine.hoverTracked.set(engine.doc, record)
						engine.doc.addEventListener('mouseover', engine.hoverChanged, true)
						engine.doc.addEventListener('mouseout', engine.hoverChanged, true)
					}
					engine.hoverDoc = engine.doc
					engine.hoverRecord = record
					engine.Snapshot.HOVER = record.target
				}
				//#endregion
				//#region src/core/select/chain.mts
				function fetchLevel(engine, part, root, out) {
					var found, i, l
					if (part.cls !== void 0) {
						found = engine.collectionSnapshot(root.getElementsByClassName(part.cls), root, void 0, true)
						l = found.length
						if (part.tag === void 0) for (i = 0; l > i; ++i) out[out.length] = found[i]
						else
							for (i = 0; l > i; ++i)
								if (
									found[i].localName == part.tag ||
									(engine.HTML_DOCUMENT && found[i].namespaceURI == engine.NAMESPACE && found[i].localName == part.tag.toLowerCase())
								)
									out[out.length] = found[i]
					} else {
						found = engine.collectionSnapshot(root.getElementsByTagName(part.tag), root, void 0, true)
						l = found.length
						for (i = 0; l > i; ++i) out[out.length] = found[i]
					}
					return out
				}
				function countPart(engine, part, context) {
					var count,
						key = part.cls !== void 0 ? '.' + part.cls : part.tag
					if ((count = engine.partCounts.get(key)) === void 0) {
						count = (part.cls !== void 0 ? context.getElementsByClassName(part.cls) : context.getElementsByTagName(part.tag)).length
						engine.partCounts.set(key, count)
					}
					return count
				}
				function descendChain(engine, chain, context) {
					var budget = -1,
						i,
						j,
						k,
						l,
						level,
						m,
						next,
						node,
						part,
						prev,
						size,
						spent = 0,
						want
					if (engine.Config.LEGACY || !engine.HTML_DOCUMENT || context.nodeType != 9 || !context.getElementsByClassName || !context.getElementsByTagName)
						return null
					l = chain.length
					level = engine.fetchLevel(chain[0], context, [])
					size = level.length
					for (k = 1; l > k; ++k) {
						if (size > engine.DESCENT_PROBE) {
							if (budget < 0) budget = engine.countPart(chain[l - 1], context)
							want = spent + size
							for (m = k + 1; l > m; ++m) want += engine.countPart(chain[m - 1], context)
							if (want > budget) return null
						}
						spent += size
						part = chain[k]
						next = []
						prev = null
						for (i = 0, j = level.length; j > i; ++i) {
							node = level[i]
							if (prev !== null && prev.contains(node)) continue
							prev = node
							engine.fetchLevel(part, node, next)
						}
						level = next
						size = level.length
					}
					return level
				}
				function parseChain(engine, selectors) {
					var key = 'c:' + selectors,
						cached = engine.chainPlans.get(key),
						i,
						l,
						match,
						parts
					if (cached) return cached
					parts = selectors.split(' ')
					for (i = 0, l = parts.length; l > i; ++i) {
						match = engine.reChainPart.exec(parts[i])
						if (!match || (match[1] === void 0 && match[2] === void 0)) return null
						parts[i] = {
							tag: match[1],
							cls: match[2]
						}
					}
					return cacheChain(engine, key, parts)
				}
				function parseSiblingChain(engine, selectors) {
					var key = 's:' + selectors,
						cached = engine.chainPlans.get(key),
						i,
						l,
						match,
						out = [],
						parts,
						raw
					if (cached) return cached
					parts = selectors.split('~')
					for (i = 0, l = parts.length; l > i; ++i) {
						raw = parts[i].replace(/^[\t\n\f\r ]+|[\t\n\f\r ]+$/g, '')
						if (!raw || /[\t\n\f\r ]/.test(raw)) return null
						match = engine.reChainPart.exec(raw)
						if (!match || (match[1] === void 0 && match[2] === void 0)) return null
						out[out.length] = {
							tag: match[1],
							cls: match[2]
						}
					}
					return cacheChain(engine, key, out)
				}
				function cacheChain(engine, key, chain) {
					return engine.chainPlans.set(key, chain)
				}
				function matchesPart(engine, element, part) {
					if (part.tag !== void 0 && !engine.matchesTag(element, part.tag)) return false
					if (part.cls !== void 0 && !engine.hasClass(engine.classOf(element), part.cls)) return false
					return true
				}
				function isSeen(seen, parent) {
					return Array.isArray(seen) ? seen.indexOf(parent) >= 0 : !!seen.get(parent)
				}
				function markSeen(seen, parent) {
					if (Array.isArray(seen)) seen[seen.length] = parent
					else seen.set(parent, true)
				}
				function siblingChain(engine, chain, context) {
					var i,
						l,
						last = chain.length - 1,
						lastWalked = null,
						level,
						node,
						parent,
						results = [],
						seen = engine.createWeakMap() || [],
						unordered = false
					if (
						engine.Config.LEGACY ||
						!engine.HTML_DOCUMENT ||
						engine.QUIRKS_MODE ||
						context.nodeType != 9 ||
						!context.getElementsByClassName ||
						!context.getElementsByTagName
					)
						return null
					level = engine.fetchLevel(chain[last], context, [])
					for (i = 0, l = level.length; i < l; ++i) {
						node = level[i]
						parent = node.parentElement
						if (parent && isSeen(seen, parent)) {
							if (parent !== lastWalked) unordered = true
							continue
						}
						if (parent) {
							markSeen(seen, parent)
							lastWalked = parent
							scanParent(engine, chain, parent, results)
						}
					}
					if (unordered && results.length > 1) results.sort(engine.documentOrder)
					return results
				}
				function scanParent(engine, chain, parent, results) {
					var child = parent.firstElementChild,
						last = chain.length - 1,
						matched = 0
					while (child) {
						if (matched == last) {
							if (matchesPart(engine, child, chain[last])) results[results.length] = child
						} else if (matchesPart(engine, child, chain[matched])) ++matched
						child = child.nextElementSibling
					}
				}
				//#endregion
				//#region src/core/compile/optimize.mts
				function optimize(_engine, selector, token) {
					var index = token.index,
						length = token[1].length + token[2].length
					return (
						selector.slice(0, index) +
						(' >+~'.indexOf(selector.charAt(index - 1)) > -1 ? (':['.indexOf(selector.charAt(index + length + 1)) > -1 ? '*' : '') : '') +
						selector.slice(index + length - (token[1] == '*' ? 1 : 0))
					)
				}
				//#endregion
				//#region src/core/select/group.mts
				function groupSelectors(engine, selectors) {
					if (selectors.length < 2 || !pureCompiler(engine) || !selectors.every(pureSelector)) return selectors
					var groups = engine.primordials.ObjectCreate(null)
					var seeds = []
					for (var index = 0, length = selectors.length; index < length; ++index) {
						var selector = selectors[index]
						var token = selector.match(engine.reOptimizer)
						var seed = token && token[1] !== ':' ? (token[1] || '') + token[2] : '*'
						if (!groups[seed]) {
							groups[seed] = []
							seeds.push(seed)
						}
						groups[seed].push(selector)
					}
					var result = []
					for (var index1 = 0, length1 = seeds.length; index1 < length1; ++index1) {
						var _result
						var seed1 = seeds[index1]
						var branches = groups[seed1]
						var argument = branches.join(',')
						if (branches.length > 1 && branches.length <= 8 && argument.length <= 512) result.push(seed1 + ':is(' + argument + ')')
						else (_result = result).push.apply(_result, _to_consumable_array(branches))
					}
					return result
				}
				//#endregion
				//#region src/core/select/has.mts
				function prepareBulkHas(engine, selector, context) {
					if (!pureCompiler(engine) || !engine.HTML_DOCUMENT) return
					var parts = /^(.+):has\((.+)\)$/.exec(selector)
					if (!parts || !pureCompound(parts[1]) || !pureCompound(parts[2])) return
					var anchor = plan(engine, parts[1], context)
					var witness = plan(engine, parts[2], context)
					return {
						anchor: anchor,
						witness: witness,
						plannerMask: plannerMask(engine, parts[1], parts[2]),
						denseInverse: parts[1][0] === '.' && parts[2][0] === '.' && parts[1] === anchor.nodeset[0] && parts[2] === witness.nodeset[0]
					}
				}
				function plan(engine, selector, context) {
					var prepared = engine.collect([selector], context, void 0, false, true)
					return {
						factory: prepared.factory,
						nodeset: prepared.nodeset
					}
				}
				function selectBulkHas(engine, plan, context, anchors) {
					if (anchors.length < 32) return null
					var witnesses = engine.hasCandidates(plan.witness.nodeset[0], context)
					if (!witnesses.length) return []
					if (witnesses.length > anchors.length * 2 && (!plan.denseInverse || anchors.length > 192 || witnesses.length > anchors.length * 4)) {
						if (!plannerOverride(engine, plan, context, anchors.length, witnesses.length)) return null
					}
					var marks = engine.createWeakMap()
					if (!marks) return null
					markWitnesses(engine, plan, context, witnesses, marks)
					var results = []
					var anchor = plan.anchor.factory[0]
					for (var i = 0, length = anchors.length; i < length; ++i) {
						var element = anchors[i]
						if (marks.has(element) && (!anchor || anchor(element, null, context, false))) results.push(element)
					}
					return results
				}
				function markAncestors(engine, element, context, marks) {
					var node = engine.upOf(element)
					while (node && node !== context && !marks.has(node)) {
						marks.set(node, true)
						node = engine.upOf(node)
					}
				}
				function plannerMask(engine, anchor, witness) {
					if (!engine.Config.NEURAL_PLANNER || !engine.bulkHasPlanner) return
					var supported = /^\.[A-Za-z_][A-Za-z0-9_-]*(?:\[data-ok=(?:"1"|'1')\])?$/
					if (!supported.test(anchor) || !supported.test(witness)) return
					return (anchor.indexOf('[') < 0 ? 0 : 2) + (witness.indexOf('[') < 0 ? 0 : 1)
				}
				function plannerOverride(engine, plan, context, anchors, witnesses) {
					if (!plan.plannerMask || !engine.Config.NEURAL_PLANNER || !engine.bulkHasPlanner) return false
					if (context.nodeType !== 9 || engine.QUIRKS_MODE || !engine.HTML_DOCUMENT || !pureCompiler(engine)) return false
					try {
						return engine.bulkHasPlanner(anchors, witnesses, plan.plannerMask, +plan.denseInverse, witnesses / anchors) === true
					} catch (unused) {
						return false
					}
				}
				function markWitnesses(engine, plan, context, witnesses, marks) {
					var witness = plan.witness.factory[0]
					for (var i = 0, length = witnesses.length; i < length; ++i) {
						var element = witnesses[i]
						if (!witness || witness(element, null, context, false)) markAncestors(engine, element, context, marks)
					}
				}
				//#endregion
				//#region src/core/select/all.mts
				function select(engine, selectors, context, callback) {
					var nodes, resolver
					arguments.length - 1 == 0 && engine.emit(engine.qsNotArgs, TypeError)
					context || (context = engine.doc)
					engine.lastContext !== context && (engine.lastContext = engine.switchContext(context))
					var shortcut = selectByDescent(engine, selectors, context, callback)
					if (shortcut) return shortcut
					if (selectors) {
						var cached = runCachedResolvers(engine, selectors, context, callback)
						if (cached) return cached
					}
					var parsed = engine.parse(selectors, true)
					resolver = engine.collect(callback === void 0 && parsed ? groupSelectors(engine, parsed) : parsed, context, callback)
					nodes = resolver.results
					var bulkHas = prepareBulkHas(engine, selectors, context)
					engine.selectResolvers.set(
						selectors,
						_object_spread(
							{
								factory: resolver.factory,
								nodeset: resolver.nodeset
							},
							bulkHas
								? {
										bulkHas: bulkHas
									}
								: {}
						)
					)
					if (typeof callback == 'function') nodes = engine.concatCall(nodes, callback)
					return !engine.Config.NODE_LIST ? nodes : engine.isInstanceOf(nodes) ? nodes : engine.toNodeList(nodes)
				}
				function selectByDescent(engine, selectors, context, callback) {
					var descended
					var children = selectDirectChildren(engine, selectors, context, callback)
					if (children) return children
					if (
						callback === void 0 &&
						selectors &&
						typeof selectors == 'string' &&
						!engine.Config.LEGACY &&
						engine.HTML_DOCUMENT &&
						context.nodeType == 9 &&
						hasChainRoute(engine, selectors) &&
						!engine.hasForeignTypes(context)
					) {
						descended =
							chainByParts(selectors, context, {
								declined: engine.descentDeclined,
								grammar: engine.reTagChain,
								parse: engine.parseChain,
								answer: engine.descendChain
							}) ||
							chainByParts(selectors, context, {
								declined: engine.siblingDeclined,
								grammar: engine.reSiblingChain,
								parse: engine.parseSiblingChain,
								answer: engine.siblingChain
							})
						if (descended) return !engine.Config.NODE_LIST ? descended : engine.isInstanceOf(descended) ? descended : engine.toNodeList(descended)
					}
				}
				function chainByParts(selectors, context, chain) {
					var descended
					if (chain.declined.get(selectors) === void 0 && chain.grammar.test(selectors) && (descended = chain.parse(selectors))) {
						descended = chain.answer(descended, context)
						if (descended) return descended
						chain.declined.set(selectors, true)
					}
				}
				function selectDirectChildren(engine, selectors, context, callback) {
					var descended
					if (
						typeof selectors == 'string' &&
						engine.includes(selectors, '>') &&
						callback === void 0 &&
						!engine.Config.LEGACY &&
						engine.HTML_DOCUMENT &&
						context.nodeType == 9 &&
						engine.reChildRoute.test(selectors) &&
						!engine.hasForeignTypes(context) &&
						(descended = engine.selectChildren(selectors, context))
					)
						return engine.Config.NODE_LIST ? engine.toNodeList(descended) : descended
				}
				function hasChainRoute(engine, selectors) {
					return engine.reTagChain.test(selectors) || engine.reSiblingChain.test(selectors)
				}
				function runCachedResolvers(engine, selectors, context, callback) {
					var resolver = engine.selectResolvers.get(selectors)
					if (resolver) {
						var nodes = []
						var i,
							l,
							start,
							ends,
							list,
							f = resolver.factory,
							n = resolver.nodeset
						if (n.length > 1) {
							for (i = 0, l = n.length; l > i; ++i) {
								start = nodes.length
								list = selectCandidates(engine, n[i], context, f[i] !== null)
								if (f[i] !== null) f[i](list, callback, context, nodes)
								else engine.concatList(nodes, list)
								if (start && nodes.length > start) {
									if (ends) ends[ends.length] = nodes.length
									else ends = [0, start, nodes.length]
								}
							}
							if (ends) nodes = engine.mergeResults(nodes, ends)
						} else if (n.length) nodes = runSingle(engine, resolver, context, callback)
						if (typeof callback == 'function') nodes = engine.concatCall(nodes, callback)
						return !engine.Config.NODE_LIST ? nodes : engine.isInstanceOf(nodes) ? nodes : engine.toNodeList(nodes)
					}
				}
				function runSingle(engine, plan, context, callback) {
					var _$factory = plan.factory[0]
					var list = selectCandidates(engine, plan.nodeset[0], context, _$factory !== null)
					if (callback === void 0 && plan.bulkHas && plan.nodeset[0] === plan.bulkHas.anchor.nodeset[0]) {
						var bulk = selectBulkHas(engine, plan.bulkHas, context, list)
						if (bulk) return bulk
					}
					return _$factory ? _$factory(list, callback, context, []) : list
				}
				//#endregion
				//#region src/core/first/candidates.mts
				function firstCandidates(engine, token, context, name, api) {
					return !engine.Config.LEGACY &&
						(engine.HTML_DOCUMENT || token[0] != '*') &&
						(token[0] != '*' || !engine.hasForeignTypes(context)) &&
						(token[0] == '*' || (token[0] == '.' && !/[\t\n\f\r ]/.test(name))) &&
						api in context
						? context[api](name)
						: engine.fetch[token[0]](name, context)
				}
				//#endregion
				//#region src/core/first/simple.mts
				function syncLookupContext(engine, context) {
					if (engine.lastContext !== context || (context !== engine.doc && context.ownerDocument !== engine.doc))
						engine.lastContext = engine.switchContext(context)
				}
				function simpleId(engine, selectors, context) {
					var match = engine.reSimpleId.exec(selectors)
					if (match) return match
					if (engine.Config.LEGACY || selectors.charCodeAt(0) !== 91) return null
					var attribute = /^\[id=(?:"([-\w]+)"|'([-\w]+)'|([_a-zA-Z][-\w]*))\]$/.exec(selectors)
					return attribute && engine.isHTML(context.ownerDocument || context) ? attribute : null
				}
				function firstId(engine, selectors, context) {
					if (
						typeof selectors !== 'string' ||
						!selectors ||
						!context.getElementById ||
						!(context.nodeType === 9 || (!engine.Config.LEGACY && context.nodeType === 11))
					)
						return false
					var match = simpleId(engine, selectors, context)
					if (!match) return false
					syncLookupContext(engine, context)
					return context.getElementById(engine.unescapeIdentifier(match[1] || match[2] || match[3])) || null
				}
				function firstCollection(engine, match, context) {
					if (match[2]) return context.getElementsByClassName(match[2])
					if (engine.hasForeignTypes(context)) return engine.byTag(match[1], context)
					if (!engine.HTML_DOCUMENT && match[1] !== '*') return engine.byTagNS(context, match[1])
					return context.getElementsByTagName(match[1])
				}
				function firstWithTag(engine, match, collection) {
					var element = collection[0] || null
					if (match[2] && match[1] && match[1] !== '*') {
						var i = 0
						var length = 0
						while (element && !engine.matchesTag(element, match[1])) {
							if (i === 0) length = collection.length
							element = ++i < length ? collection[i] : null
						}
					}
					return element
				}
				function firstSimple(engine, selectors, context) {
					if (engine.Config.LEGACY || typeof selectors !== 'string' || !selectors) return false
					var match = /^([a-zA-Z][-\w]*|\*)?(?:\.([_a-zA-Z][-\w]*))?$/.exec(selectors)
					if (!match || !(context.nodeType === 9 || context.nodeType === 1) || !context.getElementsByTagName || !context.getElementsByClassName) return false
					syncLookupContext(engine, context)
					return (match[2] && engine.firstClass(context, match[2], match[1])) || firstWithTag(engine, match, firstCollection(engine, match, context))
				}
				function notifyFirst(element, callback) {
					if (element && typeof callback === 'function') callback(element)
					return element
				}
				//#endregion
				//#region src/core/first/select.mts
				function first(engine, selectors, context, callback) {
					if (arguments.length - 1 === 0) {
						engine.emit(engine.qsNotArgs, TypeError)
						return null
					}
					var lookupContext = context || engine.doc
					var id = firstId(engine, selectors, lookupContext)
					if (id !== false) return notifyFirst(id, callback)
					var simple = firstSimple(engine, selectors, lookupContext)
					if (simple !== false) return notifyFirst(simple, callback)
					if (!engine.Config.LEGACY && typeof selectors === 'string' && selectors) return engine.firstCompiled(selectors, context, callback)
					return (
						engine.select(
							selectors,
							context,
							typeof callback === 'function'
								? function firstMatchCallback(element) {
										callback(element)
										return false
									}
								: engine.firstMatch
						)[0] || null
					)
				}
				function firstCompiled(engine, selectors, context, callback) {
					var plan,
						resolver,
						filtered,
						position,
						i,
						token,
						name,
						api,
						collection,
						result,
						element = null
					context || (context = engine.doc)
					if (engine.lastContext !== context || (context !== engine.doc && context.ownerDocument !== engine.doc))
						engine.lastContext = engine.switchContext(context)
					plan = engine.firstResolvers.get(selectors)
					if (!plan) {
						var collected = engine.collect(engine.parse(selectors, true), context, null, false, true)
						plan = {
							factory: collected.factory,
							nodeset: collected.nodeset
						}
						engine.firstResolvers.set(selectors, plan)
					}
					for (var nodesetLength = plan.nodeset.length, i = 0; i < nodesetLength; ++i) {
						resolver = plan.factory[i]
						filtered = resolver.filtered ? {} : void 0
						position = resolver.position
							? {
									element: null,
									index: 0
								}
							: void 0
						token = plan.nodeset[i]
						name = token.slice(1)
						api = engine.method[token[0]]
						result = token.charCodeAt(0) == 46 && !/[\t\n\f\r ]/.test(name) && engine.firstClass(context, name, null, resolver, filtered, position)
						if (result) {
							if (precedes(result, element)) element = result
							continue
						}
						collection = firstCandidates(engine, token, context, name, api)
						result = collection[0]
						scanFirstCandidates()
						if (result && precedes(result, element)) element = result
					}
					return notifyFirst(element, callback)
					function scanFirstCandidates() {
						if (result && !resolver(result, null, context, false, filtered, position)) {
							var j = 1,
								length
							for (; j < 8; ++j) {
								result = collection[j]
								if (!result || resolver(result, null, context, false, filtered, position)) break
							}
							if (j === 8) {
								result = null
								for (length = collection.length; j < length; ++j)
									if (resolver(collection[j], null, context, false, filtered, position)) {
										result = collection[j]
										break
									}
							}
						}
					}
				}
				function selectChildren(engine, selectors, context) {
					var plan = engine.childPlans.get(selectors),
						found,
						roots,
						root,
						candidates,
						element,
						parent,
						previous,
						results = [],
						unordered = false,
						i,
						j,
						k,
						length
					if (plan === void 0) {
						found = engine.reChildRoute.exec(selectors)
						plan = found
							? {
									tag: found[1],
									cls: found[2],
									tags: found[3].split(/\s*>\s*/).slice(1)
								}
							: null
						engine.childPlans.set(selectors, plan)
					}
					if (!plan) return null
					roots = context.getElementsByClassName(plan.cls)
					length = roots.length
					if (length > engine.DESCENT_PROBE) return null
					if (length >= 16) {
						if (context.getElementsByTagName(plan.tags[plan.tags.length - 1]).length <= length) return null
						roots = engine.collectionSnapshot(roots, context, length)
					}
					collectChildChains()
					if (unordered && results.length > 1) results.sort(engine.documentOrder)
					return results
					function collectChildChains() {
						for (i = 0; i < length; ++i) {
							root = roots[i]
							if (plan.tag !== void 0 && root.localName != plan.tag) continue
							if (previous && previous.contains(root)) unordered = true
							previous = root
							candidates = engine.collectionSnapshot(root.getElementsByTagName(plan.tags[plan.tags.length - 1]), root, void 0, true)
							for (j = 0, k = candidates.length; j < k; ++j) {
								element = candidates[j]
								parent = element.parentElement
								for (var depth = plan.tags.length - 2; depth >= 0; --depth) {
									if (!parent || parent.localName != plan.tags[depth]) break
									parent = parent.parentElement
								}
								if (depth < 0 && parent === root) results[results.length] = element
							}
						}
					}
				}
				function precedes(result, element) {
					return !element || (element !== result && !!(result.compareDocumentPosition(element) & 4))
				}
				//#endregion
				//#region src/core/predicate/css-whitespace.mts
				function isCssWhitespace(code) {
					return code === 32 || code === 9 || code === 10 || code === 12 || code === 13
				}
				//#endregion
				//#region src/core/first/class.mts
				function firstClass(engine, context, name, tag, resolver, filtered, position) {
					var element, next, value, offset, before, after, state, cached, nodes, candidates, i, view
					if (engine.QUIRKS_MODE) return null
					prepareClassCache()
					collectClassPrefix()
					cached = cached
					candidates = cached.classes.get(name)
					candidates = collectClassCandidates(cached)
					for (var candidatesLength = candidates.length, i = 0; i < candidatesLength; ++i) {
						element = candidates[i]
						if ((!tag || tag == '*' || engine.matchesTag(element, tag)) && (!resolver || resolver(element, null, context, false, filtered, position)))
							return element
					}
					return null
					function prepareClassCache() {
						state = engine.firstRoots && engine.firstRoots.get(context)
						if (state) {
							if (state.observer.takeRecords().length) state.copies = engine.createWeakMap()
							cached = state.copies.get(context)
						} else if (engine.primordials.WeakRefCtor && (view = (context.ownerDocument || context).defaultView) && view.MutationObserver) {
							engine.firstRoots || (engine.firstRoots = engine.createWeakMap())
							if (engine.firstRoots) {
								state = {
									copies: engine.createWeakMap(),
									observer: null
								}
								state.observer = engine.Factory['_observeCollections'](context, view, state)
								engine.firstRoots.set(context, state)
							}
						}
					}
					function collectClassCandidates(cached) {
						if (!candidates) {
							candidates = []
							for (var cachedNodesLength = cached.nodes.length, i = 0; i < cachedNodesLength; ++i) {
								element = cached.nodes[i]
								value = engine.classOf(element)
								offset = -1
								while (value && (offset = value.indexOf(name, offset + 1)) >= 0) {
									before = offset ? value.charCodeAt(offset - 1) : 32
									after = offset + name.length < value.length ? value.charCodeAt(offset + name.length) : 32
									if (isCssWhitespace(before) && isCssWhitespace(after)) {
										candidates[candidates.length] = element
										break
									}
								}
							}
							cached.classes.set(name, candidates)
						}
						return candidates
					}
					function collectClassPrefix() {
						if (!cached) {
							nodes = []
							element = context.firstElementChild
							while (element && nodes.length < 16) {
								nodes[nodes.length] = element
								next = element.firstElementChild
								if (!next) {
									while (element !== context && !(next = element.nextElementSibling)) {
										element = element.parentNode
										if (!element) break
									}
									if (!element || element === context) break
								}
								element = next
							}
							cached = {
								nodes: nodes,
								classes: engine.createCache(64)
							}
							state && state.copies.set(context, cached)
						}
					}
				}
				//#endregion
				//#region src/core/match/relative.mts
				function hasCandidates(engine, token, context) {
					var kind = token[0],
						name = token.slice(1),
						api = kind == '.' ? engine.method['.'] : engine.method['*'],
						nodes,
						snapshot
					if (
						!engine.Config.LEGACY &&
						(kind == '.' || (kind == '*' && (name == '*' || (engine.HTML_DOCUMENT && !engine.hasForeignTypes(context))))) &&
						!/[\t\n\f\r ]/.test(name) &&
						api in context
					) {
						nodes = context[api](name)
						snapshot = engine.collectionSnapshot(nodes, context, void 0, void 0, kind == '*' && name == '*' ? context : void 0)
						if (snapshot !== nodes) return snapshot
						return engine.collectionCopy(nodes, context, snapshot)
					}
					return engine.fetch[kind](name, context)
				}
				function has(engine, argument, anchor) {
					var compileRelativePlansDone = false
					var compileRelativePlansValue
					var key = typeof argument == 'string' ? 's:' + argument : 'a:' + JSON.stringify(argument),
						plans = (
							engine.hasPlans ||
							(engine.hasPlans = engine.createCache(void 0, {
								bytes: 2097152,
								weight: relativeWeight
							}))
						).get(key),
						list,
						parsed,
						normalized,
						range,
						result,
						context,
						root,
						candidates,
						matched = [],
						resolver,
						token,
						i,
						j,
						previousErrors = engine.errors,
						previous = engine.Snapshot.anchor
					engine.Snapshot.anchor = anchor
					try {
						compileRelativePlans()
						plans = plans
						if (compileRelativePlansDone) return compileRelativePlansValue
						for (var plansLength = plans.length, i = 0; i < plansLength; ++i) {
							context = plans[i].sibling ? engine.upOf(anchor) : anchor
							if (!context) continue
							root = plans[i].subtree ? engine.nextOf(anchor) : context
							while (root) {
								if (!plans[i].subtree || engine.firstOf(root))
									for (var nodesetLength = plans[i].nodeset.length, j = 0; j < nodesetLength; ++j) {
										token = plans[i].nodeset[j]
										resolver = plans[i].factory[j]
										candidates = engine.hasCandidates(token, root)
										if (hasMatch(resolver, candidates, context, matched)) return true
									}
								root = plans[i].subtree == 126 ? engine.nextOf(root) : null
							}
						}
						return false
					} finally {
						engine.Snapshot.anchor = previous
					}
					function compileRelativePlans() {
						if (!plans) {
							list = typeof argument == 'string' ? engine.splitList(argument) : argument
							plans = []
							for (var listLength = list.length, i = 0; i < listLength; ++i) {
								if (!list[i]) {
									engine.emit(engine.qsInvalid)
									compileRelativePlansValue = false
									compileRelativePlansDone = true
									return
								}
								parsed = engine.parse('* ' + list[i], true)
								if (!parsed || !parsed.length) {
									compileRelativePlansValue = false
									compileRelativePlansDone = true
									return
								}
								normalized = parsed.map(function (selector) {
									return selector.slice(1).replace(/^\s+/, '')
								})
								range = normalized[0].match(/^[+~][\t\n\f\r ]*(?:[a-zA-Z][\w-]*|\*)(?:[\t\n\f\r ]+|>)([\s\S]+)$/)
								result = engine.collect(normalized, anchor, void 0, true, true, true)
								plans.push({
									sibling: /^[+~]/.test(list[i]),
									subtree:
										!engine.Config.LEGACY && normalized.length == 1 && range && !/[+~]/.test(range[1]) && Object.keys(engine.Combinators).length == 0
											? normalized[0].charCodeAt(0)
											: 0,
									factory: result.factory,
									nodeset: result.nodeset
								})
							}
							if (engine.errors != previousErrors) {
								compileRelativePlansValue = false
								compileRelativePlansDone = true
								return
							}
							engine.hasPlans.set(key, plans)
						}
					}
				}
				function hasMatch(resolver, candidates, context, matched) {
					if (!resolver) return candidates.length > 0
					matched.length = 0
					return resolver(candidates, null, context, matched).length > 0
				}
				function firstMatch(_engine) {
					return false
				}
				//#endregion
				//#region src/core/initialize/api.mts
				function initializeApi(engine) {
					engine.parse = parse.bind(null, engine)
					engine.match = match.bind(null, engine)
					engine.matchPublic = matchPublic.bind(null, engine)
					engine.matchForgiving = matchForgiving.bind(null, engine)
					engine.hasChild = hasChild.bind(null, engine)
					engine.hasCandidates = hasCandidates.bind(null, engine)
					engine.has = has.bind(null, engine)
					engine.firstMatch = firstMatch.bind(null, engine)
					engine.firstRoots = null
					engine.firstClass = firstClass.bind(null, engine)
					engine.first = first.bind(null, engine)
					engine.firstCompiled = firstCompiled.bind(null, engine)
					engine.DESCENT_PROBE = 128
					engine.childPlans = engine.createCache()
					engine.chainPlans = engine.createCache(256)
					engine.selectChildren = selectChildren.bind(null, engine)
					engine.partCounts = engine.createCache()
					engine.reTagChain = /^[.A-Za-z][-\w]*(?:\.[-\w]+)?(?:\x20[.A-Za-z][-\w]*(?:\.[-\w]+)?)+$/
					engine.reSiblingChain = /^[.A-Za-z][-\w.]*(?:[\t\n\f\r ]*~[\t\n\f\r ]*[.A-Za-z][-\w.]*)+$/
					engine.reChildRoute = /^([a-z][a-z0-9-]*)?\.([_a-zA-Z][-\w]*)([\t\n\f\r ]*>[\t\n\f\r ]*[a-z][a-z0-9-]*(?:[\t\n\f\r ]*>[\t\n\f\r ]*[a-z][a-z0-9-]*)*)$/
					engine.reChainPart = /^([A-Za-z][-\w]*)?(?:\.([-\w]+))?$/
					engine.fetchLevel = fetchLevel.bind(null, engine)
					engine.countPart = countPart.bind(null, engine)
					engine.descendChain = descendChain.bind(null, engine)
					engine.parseChain = parseChain.bind(null, engine)
					engine.siblingChain = siblingChain.bind(null, engine)
					engine.parseSiblingChain = parseSiblingChain.bind(null, engine)
					engine.descentDeclined = engine.createCache()
					engine.siblingDeclined = engine.createCache()
					engine.select = select.bind(null, engine)
					engine.optimize = optimize.bind(null, engine)
					engine.collect = collect.bind(null, engine)
					engine.hoverWanted = false
					engine.hoverTracked = null
					engine.hoverChanged = hoverChanged.bind(null, engine)
					engine.trackHover = trackHover.bind(null, engine)
					engine.argsWith = argsWith.bind(null, engine)
					engine.install = install.bind(null, engine)
					engine.uninstall = uninstall.bind(null, engine)
					engine.none = Array()
					engine.matchLambdas = engine.createCache(void 0, {
						bytes: PLAN_BYTES,
						weight: resolverWeight
					})
					engine.selectLambdas = engine.createCache(void 0, {
						bytes: PLAN_BYTES,
						weight: resolverWeight
					})
					engine.matchResolvers = engine.createCache(void 0, {
						bytes: PLAN_BYTES,
						weight: resolverListWeight
					})
					engine.forgivingResolvers = engine.createCache(void 0, {
						bytes: PLAN_BYTES,
						weight: forgivingWeight
					})
					engine.selectorGeneration = 0
					engine.selectResolvers = engine.createCache(void 0, {
						bytes: PLAN_BYTES,
						weight: queryWeight
					})
					engine.firstResolvers = engine.createCache(void 0, {
						bytes: PLAN_BYTES,
						weight: queryWeight
					})
					engine.Snapshot = {
						doc: engine.doc,
						from: engine.doc,
						root: engine.root,
						anchor: null,
						byTag: engine.byTag,
						includes: engine.includes,
						attrOf: engine.attrOf,
						hasAttrOf: engine.hasAttrOf,
						tagOf: engine.tagOf,
						idOf: engine.idOf,
						legacyClassOf: engine.modernReaders.legacyClassOf,
						upOf: engine.upOf,
						nextOf: engine.nextOf,
						prevOf: engine._prevOf,
						firstOf: engine.firstOf,
						connectedOf: engine.connectedOf,
						has: engine.has,
						hasChild: engine.hasChild,
						first: engine.first,
						match: engine.match,
						matchForgiving: engine.matchForgiving,
						select: engine.select,
						ancestor: engine.ancestor,
						matchesTag: engine.matchesTag,
						hasClass: engine.hasClass,
						createWeakMap: engine.createWeakMap,
						mayMatch: engine.mayMatch,
						ancestorMask: engine.ancestorMask,
						clearAncestorMasks: engine.clearAncestorMasks,
						nthOfType: engine.nthOfType,
						nthElement: engine.nthElement,
						firstPosition: firstPosition,
						nthFiltered: engine.nthFiltered,
						isDirection: engine.isDirection,
						isLanguage: engine.isLanguage,
						isHost: engine.isHost,
						hasSlotted: engine.hasSlotted,
						shadowParent: engine.shadowParent,
						matchesNative: engine.matchesNative,
						isDefined: engine.isDefined,
						isRequired: engine.isRequired,
						isOpen: engine.isOpen,
						isClosed: engine.isClosed,
						isDisabled: engine.isDisabled,
						isModal: engine.isModal,
						isFullscreen: engine.isFullscreen,
						classOf: engine.classOf,
						isPictureInPicture: engine.isPictureInPicture,
						isPopoverOpen: engine.isPopoverOpen,
						isFocusable: engine.isFocusable,
						isContentEditable: engine.isContentEditable,
						isLink: engine.isLink,
						hasAttributeNS: engine.hasAttributeNS,
						attributeValueNS: engine.attributeValueNS,
						isMediaState: engine.isMediaState,
						matchForgivingKey: engine.matchForgivingKey
					}
					engine.Dom = {
						matchLambdas: engine.matchLambdas,
						selectLambdas: engine.selectLambdas,
						matchResolvers: engine.matchResolvers,
						selectResolvers: engine.selectResolvers,
						CFG: engine.CFG,
						S_BODY: engine.S_BODY,
						M_BODY: engine.M_BODY,
						N_BODY: engine.M_BODY,
						S_TEST: engine.S_TEST,
						M_TEST: engine.M_TEST,
						N_TEST: engine.N_TEST,
						byId: engine.byId,
						byTag: engine.byTag,
						byClass: engine.byClass,
						first: engine.first,
						match: engine.matchPublic,
						select: engine.select,
						closest: engine.ancestor,
						compile: engine.compile,
						configure: engine.configure,
						emit: engine.emit,
						Config: engine.Config,
						Snapshot: engine.Snapshot,
						Version: engine.version,
						install: engine.install,
						uninstall: engine.uninstall,
						Operators: engine.Operators,
						Selectors: engine.Selectors,
						useNeuralPlanner: function (host) {
							engine.bulkHasPlanner = host === null ? void 0 : neuralPlannerPolicy(host)
							engine.configure(
								{
									NEURAL_PLANNER: host !== null
								},
								true
							)
						},
						registerBulkHasPlanner: function (planner) {
							if (planner !== null && typeof planner !== 'function') throw new TypeError('Expected a bulk :has() planner function or null')
							engine.bulkHasPlanner = planner || void 0
							engine.configure({}, true)
						},
						registerLegacyHooks: function (factory) {
							if (engine.legacyHooks) return false
							engine.legacyHooks = factory({
								MapCtor: engine.primordials.MapCtor,
								WeakMapCtor: engine.primordials.WeakMapCtor,
								StringPrototypeIncludes: engine.primordials.StringPrototypeIncludes,
								isHTML: function () {
									return engine.HTML_DOCUMENT
								},
								isQuirks: function () {
									return engine.QUIRKS_MODE
								},
								byTag: function (tag, context) {
									return engine.byTag(tag, context)
								}
							})
							engine.createWeakMap = engine.legacyHooks.createWeakMap
							if (!engine.legacyHooks.hasMap) {
								engine.createCache = engine.legacyHooks.createCache
								engine.typeRoutes = engine.createCache()
								engine.childPlans = engine.createCache()
								engine.chainPlans = engine.createCache(256)
								engine.partCounts = engine.createCache()
								engine.descentDeclined = engine.createCache()
								engine.hasPlans = void 0
								engine.Dom.matchLambdas = engine.matchLambdas = engine.createCache()
								engine.Dom.selectLambdas = engine.selectLambdas = engine.createCache()
								engine.Dom.matchResolvers = engine.matchResolvers = engine.createCache()
								engine.forgivingResolvers = engine.createCache()
								engine.Dom.selectResolvers = engine.selectResolvers = engine.createCache()
								engine.firstResolvers = engine.createCache()
							}
							engine.initialize(engine.doc)
							engine.configure({}, true)
							return true
						},
						registerCombinator: function (combinator, resolver) {
							var i = 0,
								l = combinator.length,
								symbol
							for (; l > i; ++i)
								if (combinator[i] != '=') {
									symbol = combinator[i]
									break
								}
							if (engine.CFG.combinators.indexOf(symbol) < 0) {
								engine.CFG.combinators = engine.CFG.combinators.replace('](', symbol + '](')
								engine.CFG.combinators = engine.CFG.combinators.replace('])', symbol + '])')
								engine.Combinators[combinator] = resolver
								engine.setIdentifierSyntax()
								engine.selectorGeneration++
								engine.configure({}, true)
							} else console.warn("Warning: the '" + combinator + "' combinator is already registered.")
						},
						registerOperator: function (operator, resolver) {
							var i = 0,
								l = operator.length,
								symbol
							for (; l > i; ++i)
								if (operator[i] != '=') {
									symbol = operator[i]
									break
								}
							if (engine.CFG.operators.indexOf(symbol) < 0 && !engine.Operators[operator]) {
								engine.CFG.operators = engine.CFG.operators.replace(']=', symbol + ']=')
								engine.Operators[operator] = resolver
								engine.setIdentifierSyntax()
								engine.selectorGeneration++
								engine.configure({}, true)
							} else console.warn("Warning: the '" + operator + "' operator is already registered.")
						},
						registerSelector: function (name, rexp, func) {
							if (!engine.Selectors[name]) {
								engine.Selectors[name] = {
									Expression: rexp,
									Callback: func
								}
								engine.selectorGeneration++
								engine.configure({}, true)
							}
						}
					}
				}
				//#endregion
				//#region src/core/dom/attribute.mts
				function attributeValueNS(engine, e, name) {
					if (e.getAttributeNS) return e.getAttributeNS(null, name)
					var attribute = e.getAttributeNode && e.getAttributeNode(name)
					return attribute && attribute.namespaceURI ? null : engine.attrOf(e, name)
				}
				function hasAttributeNS(engine, e, name, pattern, expected) {
					var i,
						l,
						local,
						attribute,
						attr = engine.attrNamesOf(e)
					if (engine.HTML_DOCUMENT) name = name.toLowerCase()
					for (i = 0, l = attr.length; l > i; ++i) {
						local = attr[i]
						if (local.indexOf(':') >= 0) {
							attribute = e.getAttributeNode && e.getAttributeNode(local)
							local = attribute && attribute.localName ? attribute.localName : local.slice(local.indexOf(':') + 1)
						}
						if ((engine.HTML_DOCUMENT ? local.toLowerCase() : local) == name && (!pattern || pattern.test(engine.attrOf(e, attr[i])) === expected)) return true
					}
					return false
				}
				//#endregion
				//#region src/core/dom/readers.mts
				function tagOf(_engine, e) {
					return e.localName
				}
				function idOf(_engine, e) {
					return e.id
				}
				function firstOf(_engine, e) {
					return e.firstElementChild
				}
				function attrNamesOf(_engine, e) {
					return e.getAttributeNames()
				}
				function connectedOf(_engine, e) {
					return e.isConnected
				}
				function useLegacy(engine, on) {
					var readers = on ? engine.legacyHooks : engine.modernReaders,
						name
					if (on) engine.legacyHooks.initialize(engine.doc)
					engine.includes = readers.includes
					engine.attrOf = readers.attrOf
					engine.hasAttrOf = readers.hasAttrOf
					engine.tagOf = readers.tagOf
					engine.idOf = readers.idOf
					engine.upOf = readers.upOf
					engine.nextOf = readers.nextOf
					engine._prevOf = readers.prevOf
					engine.firstOf = readers.firstOf
					engine.attrNamesOf = readers.attrNamesOf
					engine.connectedOf = readers.connectedOf
					for (name in engine.modernReaders) engine.Snapshot[name] = readers[name]
				}
				function classOf(engine, e) {
					var value = e.className
					if (typeof value == 'string') return value
					if (value && typeof value.baseVal == 'string') return value.baseVal
					return engine.attrOf(e, 'class') || ''
				}
				//#endregion
				//#region src/core/lookup/class.mts
				function byClass(engine, cls, context) {
					var e,
						nodes,
						api = engine.method['.'],
						reCls
					if (engine.Config.LEGACY) nodes = engine.legacyHooks.byClass(cls, context)
					else if (api in context) return engine.collectionCopy(context[api](cls), context)
					else if ((e = context.firstElementChild)) {
						reCls = engine.QUIRKS_MODE ? RegExp('(^|\\s)' + cls + '(\\s|$)', 'i') : null
						if (!(e.nextElementSibling || hasToken(e))) return engine.sliceCall(e[api](cls))
						else {
							nodes = []
							do {
								if (hasToken(e)) nodes[nodes.length] = e
								engine.concatList(nodes, e[api](cls))
							} while ((e = e.nextElementSibling))
						}
					} else nodes = engine.none
					return !engine.Config.NODE_LIST ? nodes : engine.isInstanceOf(nodes) ? nodes : engine.toNodeList(nodes)
					function hasToken(element) {
						return reCls ? reCls.test(element.className) : hasClass(engine, engine.classOf(element), cls)
					}
				}
				function hasClass(_engine, value, name) {
					var offset = -1,
						before,
						after
					while (value && (offset = value.indexOf(name, offset + 1)) >= 0) {
						before = offset ? value.charCodeAt(offset - 1) : 32
						after = offset + name.length < value.length ? value.charCodeAt(offset + name.length) : 32
						if (isCssWhitespace(before) && isCssWhitespace(after)) return true
					}
					return false
				}
				//#endregion
				//#region src/core/lookup/tag.mts
				function byTags(engine, names, context) {
					if (engine.Config.LEGACY || !engine.HTML_DOCUMENT || !context.getElementsByTagName || engine.hasForeignTypes(context))
						return engine.byTag('*', context)
					var route = engine.typeRoutes.get(names)
					if (route && --route.remaining > 0 && route.broad) return engine.byTag('*', context)
					var probe = !route || route.remaining <= 0,
						tags = names.split(','),
						seen = engine.primordials.ObjectCreate(null),
						collections = [],
						count = 0,
						nodes = [],
						list,
						merged,
						left,
						right,
						i,
						tag
					for (var tagsLength = tags.length, i = 0; i < tagsLength; ++i) {
						tag = tags[i].trim()
						if (!seen[tag]) {
							seen[tag] = true
							list = context.getElementsByTagName(tag)
							count += list.length
							collections[collections.length] = list
						}
					}
					if (probe) {
						route = {
							broad: count > 0 && count * 3 > context.getElementsByTagName('*').length,
							remaining: 64
						}
						engine.typeRoutes.set(names, route)
						if (route.broad) return engine.byTag('*', context)
					}
					mergeTagCollections()
					return nodes
					function mergeTagCollections() {
						for (var collectionsLength = collections.length, i = 0; i < collectionsLength; ++i) {
							if (!collections[i].length) continue
							list = engine.collectionCopy(collections[i], context)
							if (!nodes.length) {
								nodes = list
								continue
							}
							merged = []
							left = right = 0
							while (left < nodes.length && right < list.length)
								merged[merged.length] = nodes[left].compareDocumentPosition(list[right]) & 4 ? nodes[left++] : list[right++]
							while (left < nodes.length) merged[merged.length] = nodes[left++]
							while (right < list.length) merged[merged.length] = list[right++]
							nodes = merged
						}
					}
				}
				function asciiLower(_engine, name) {
					for (var i = 0, l = name.length; l > i; ++i) {
						var c = name.charCodeAt(i)
						if (c > 64 && c < 91)
							return name.replace(/[A-Z]/g, function (letter) {
								return letter.toLowerCase()
							})
					}
					return name
				}
				function matchesTag(engine, element, name) {
					var local = engine.tagOf(element)
					if (!local || !engine.HTML_DOCUMENT) return local == name
					name = engine.asciiLower(name)
					if (local == name) return true
					return (element.namespaceURI == engine.NAMESPACE ? local : engine.asciiLower(local)) == name
				}
				function hasForeignTypes(engine, context) {
					if (!engine.HTML_DOCUMENT) return false
					var root = context.getRootNode ? context.getRootNode() : context,
						view = (context.ownerDocument || context).defaultView || engine.global,
						state,
						node,
						foreign = false
					engine.foreignTypeRoots || (engine.foreignTypeRoots = engine.createWeakMap())
					state = engine.foreignTypeRoots && engine.foreignTypeRoots.get(root)
					if (state && !state.dirty && !state.observer.takeRecords().length) return state.foreign
					node = root.nodeType == 1 ? root : root.firstElementChild
					scanForeignElements()
					storeForeignTypes()
					return foreign
					function storeForeignTypes() {
						if (!state && engine.foreignTypeRoots && view.MutationObserver && engine.primordials.WeakRefCtor && !engine.Config.LEGACY) {
							state = {
								observer: null,
								foreign: foreign,
								dirty: false
							}
							state.observer = engine.Factory['_observeCollections'](root, view, state)
							engine.foreignTypeRoots.set(root, state)
						} else if (state) {
							state.foreign = foreign
							state.dirty = false
							state.observer.takeRecords()
						}
					}
					function scanForeignElements() {
						while (node) {
							if (node.namespaceURI != engine.NAMESPACE || node.prefix || /[A-Z]/.test(node.localName)) {
								foreign = true
								break
							}
							if (node.firstElementChild) node = node.firstElementChild
							else {
								while (node && node !== root && !node.nextElementSibling) node = node.parentElement
								node = node && node !== root ? node.nextElementSibling : null
							}
						}
					}
				}
				function byTag(engine, tag, context) {
					var fetchTagCollectionDone = false
					var fetchTagCollectionValue
					if (tag != '*' && engine.hasForeignTypes(context)) {
						var all = engine.byTag('*', context),
							matched = []
						for (var index = 0, allLength = all.length; index < allLength; ++index) if (engine.matchesTag(all[index], tag)) matched[matched.length] = all[index]
						return engine.Config.NODE_LIST ? engine.toNodeList(matched) : matched
					}
					if (!engine.HTML_DOCUMENT && tag != '*') return engine.byTagNS(context, tag)
					var e,
						nodes,
						api = engine.method['*']
					fetchTagCollection()
					if (fetchTagCollectionDone) return fetchTagCollectionValue
					return !engine.Config.NODE_LIST ? nodes : engine.isInstanceOf(nodes) ? nodes : engine.toNodeList(nodes)
					function fetchTagCollection() {
						if (engine.Config.LEGACY) nodes = engine.legacyHooks.byTag(tag, context)
						else if (api in context) {
							fetchTagCollectionValue = engine.collectionCopy(context[api](tag), context, void 0, tag == '*' ? context : void 0)
							fetchTagCollectionDone = true
							return
						} else {
							tag = tag.toLowerCase()
							if ((e = context.firstElementChild)) {
								if (!(e.nextElementSibling || tag == '*' || e.localName == tag)) {
									fetchTagCollectionValue = engine.sliceCall(e[api](tag))
									fetchTagCollectionDone = true
									return
								} else {
									nodes = []
									do {
										if (tag == '*' || e.localName == tag) nodes[nodes.length] = e
										engine.concatList(nodes, e[api](tag))
									} while ((e = e.nextElementSibling))
								}
							} else nodes = engine.none
						}
					}
				}
				//#endregion
				//#region src/core/collection/copy.mts
				function collectionCopy(engine, nodes, context, snapshot, identity) {
					snapshot = snapshot || (engine.Config.LEGACY ? nodes : engine.collectionSnapshot(nodes, context, void 0, void 0, identity))
					if (snapshot !== nodes) return snapshot.slice()
					var length = nodes.length,
						i,
						result = new Array(length)
					for (i = 0; i < length; ++i) result[i] = nodes[i]
					return result
				}
				//#endregion
				//#region src/core/collection/snapshot/skip.mts
				function skipsCollectionSnapshot(length, small, engine, context) {
					return (length < 16 && !small) || engine.Config.LEGACY || !engine.primordials.WeakRefCtor || !context.getRootNode
				}
				//#endregion
				//#region src/core/collection/snapshot/get.mts
				function collectionSnapshot(engine, nodes, context, length, small, identity) {
					var state, root, view, i, result
					identity = identity || nodes
					var cached = reuseCollectionSnapshot(engine, context, identity)
					if (cached) return cached
					length === void 0 && (length = nodes.length)
					if (skipsCollectionSnapshot(length, small, engine, context)) return nodes
					view = (context.ownerDocument || context).defaultView
					if (!view || !view.MutationObserver || !view.HTMLCollection || !(nodes instanceof view.HTMLCollection)) return nodes
					root = context.getRootNode()
					engine.collectionRoots || (engine.collectionRoots = engine.createWeakMap())
					if (!engine.collectionRoots) return nodes
					state = prepareCollectionState(engine, context, root, view)
					engine.collectionStates || (engine.collectionStates = engine.createWeakMap())
					engine.collectionStates.set(identity, state)
					result = new Array(length)
					for (i = 0; i < length; ++i) result[i] = nodes[i]
					state.copies.set(identity, result)
					return result
				}
				function prepareCollectionState(engine, context, root, view) {
					var state = engine.collectionRoots.get(root)
					if (!state) {
						state = {
							copies: engine.createWeakMap(),
							observer: null,
							document: new engine.primordials.WeakRefCtor(context.ownerDocument || context)
						}
						state.observer = engine.Factory['_observeCollections'](root, view, state)
						engine.collectionRoots.set(root, state)
					} else if (state.observer.takeRecords().length || state.document.deref() !== (context.ownerDocument || context)) {
						state.copies = engine.createWeakMap()
						state.document = new engine.primordials.WeakRefCtor(context.ownerDocument || context)
					}
					return state
				}
				function reuseCollectionSnapshot(engine, context, identity) {
					var state
					var cached
					if (engine.collectionStates && (state = engine.collectionStates.get(identity))) {
						if (state.observer.takeRecords().length) state.copies = engine.createWeakMap()
						cached = state.copies.get(identity)
						if (cached && state.document.deref() === (context.ownerDocument || context)) return cached
					}
				}
				//#endregion
				//#region src/core/unicode/code-point.mts
				function codePointToUTF16(_engine, codePoint) {
					if (codePoint < 1 || codePoint > 1114111 || (codePoint > 55295 && codePoint < 57344)) return '\\ufffd'
					if (codePoint < 65536) {
						var lowHex = '000' + codePoint.toString(16)
						return '\\u' + lowHex.substr(lowHex.length - 4)
					}
					return '\\u' + (((codePoint - 65536) >> 10) + 55296).toString(16) + '\\u' + (((codePoint - 65536) % 1024) + 56320).toString(16)
				}
				//#endregion
				//#region src/core/collection/append.mts
				function concatCall(_engine, nodes, callback) {
					var i = 0,
						l = nodes.length,
						list = Array(l)
					while (l > i) {
						if (false === callback((list[i] = nodes[i]))) {
							list.length = i + 1
							break
						}
						++i
					}
					return list
				}
				function concatList(_engine, list, nodes) {
					var i = -1,
						l = nodes.length
					while (l--) list[list.length] = nodes[++i]
					return list
				}
				//#endregion
				//#region src/core/cache/weighted.mts
				function createWeightedCache(engine, limit, budget) {
					var young
					var old
					var youngBytes = 0
					var oldBytes = 0
					var half = Math.max(1, limit >> 1)
					var halfBytes = budget.bytes / 2
					function insert(key, entry) {
						if (!young || young.size >= half || youngBytes + entry.bytes > halfBytes) {
							old = young
							oldBytes = youngBytes
							young = new engine.primordials.MapCtor()
							youngBytes = 0
						}
						young.set(key, entry)
						youngBytes += entry.bytes
					}
					function remove(key) {
						var recent = young === null || young === void 0 ? void 0 : young.get(key)
						var previous = old === null || old === void 0 ? void 0 : old.get(key)
						if (recent) {
							young.delete(key)
							youngBytes -= recent.bytes
						}
						if (previous) {
							old.delete(key)
							oldBytes -= previous.bytes
						}
					}
					return {
						clear: function () {
							young = old = void 0
							youngBytes = oldBytes = 0
						},
						get: function (key) {
							var recent = young === null || young === void 0 ? void 0 : young.get(key)
							if (recent) return recent.value
							var previous = old === null || old === void 0 ? void 0 : old.get(key)
							if (previous) {
								old.delete(key)
								oldBytes -= previous.bytes
								insert(key, previous)
							}
							return previous === null || previous === void 0 ? void 0 : previous.value
						},
						set: function (key, value) {
							if (typeof key !== 'string') return value
							var bytes = key.length * 2 + budget.weight(value) + 64
							remove(key)
							if (bytes <= halfBytes)
								insert(key, {
									value: value,
									bytes: bytes
								})
							return value
						},
						size: function () {
							return ((young === null || young === void 0 ? void 0 : young.size) || 0) + ((old === null || old === void 0 ? void 0 : old.size) || 0)
						},
						bytes: function () {
							return youngBytes + oldBytes
						}
					}
				}
				//#endregion
				//#region src/core/cache/plan.mts
				function createCache(engine, limit, budget) {
					if (budget) return createWeightedCache(engine, limit || engine.CACHE_LIMIT, budget)
					var young, old, half
					limit || (limit = engine.CACHE_LIMIT)
					half = limit > 1 ? limit >> 1 : 1
					return {
						clear: function () {
							young = void 0
							old = void 0
						},
						get: function (key) {
							if (!young) return
							var value = young.get(key)
							if (value !== void 0) return value
							if (!old) return
							value = old.get(key)
							if (value !== void 0) {
								old.delete(key)
								if (young.size >= half) {
									old = young
									young = new engine.primordials.MapCtor()
								}
								young.set(key, value)
							}
							return value
						},
						set: function (key, value) {
							if (!young || young.size >= half) {
								old = young
								young = new engine.primordials.MapCtor()
							}
							young.set(key, value)
							return value
						},
						size: function () {
							return (young ? young.size : 0) + (old ? old.size : 0)
						}
					}
				}
				//#endregion
				//#region src/core/cache/weak-map.mts
				function createWeakMap(engine) {
					var Constructor = engine.primordials.WeakMapCtor
					engine.createWeakMap = function () {
						return new Constructor()
					}
					return engine.createWeakMap()
				}
				//#endregion
				//#region src/core/collection/order.mts
				function documentOrder(engine, a, b) {
					if (!engine.hasDupes && a === b) {
						engine.hasDupes = true
						return 0
					}
					return a.compareDocumentPosition(b) & 4 ? -1 : 1
				}
				function mergeResults(engine, nodes, ends) {
					var length = nodes.length,
						count = ends.length - 1,
						output,
						swap,
						width,
						group,
						i,
						j,
						end,
						middle,
						out,
						a,
						b
					if (length < 2 || count < 2) return nodes
					for (group = 1; group < count; ++group) {
						i = ends[group]
						a = nodes[i - 1]
						b = nodes[i]
						if (a === b || !(a.compareDocumentPosition(b) & 4)) break
					}
					if (group == count) return nodes
					output = Array(length)
					mergeSortedGroups()
					return engine.hasDupes ? engine.unique(nodes) : nodes
					function mergeSortedGroups() {
						for (width = 1; width < count; width *= 2) {
							for (group = 0; group < count; group += width * 2) {
								i = ends[group]
								middle = ends[Math.min(group + width, count)]
								j = middle
								end = ends[Math.min(group + width * 2, count)]
								out = i
								while (i < middle && j < end) {
									a = nodes[i]
									b = nodes[j]
									if (a === b) {
										engine.hasDupes = true
										output[out++] = a
										++i
									} else if (a.compareDocumentPosition(b) & 4) {
										output[out++] = a
										++i
									} else {
										output[out++] = b
										++j
									}
								}
								while (i < middle) output[out++] = nodes[i++]
								while (j < end) output[out++] = nodes[j++]
							}
							swap = nodes
							nodes = output
							output = swap
						}
					}
				}
				function unique(engine, nodes) {
					var i = 0,
						j = -1,
						l = nodes.length + 1,
						list = []
					while (--l) {
						if (nodes[i++] === nodes[i]) continue
						list[++j] = nodes[i - 1]
					}
					engine.hasDupes = false
					return list
				}
				//#endregion
				//#region src/core/collection/node-list.mts
				function toNodeList(engine, nodeArray) {
					if (!engine.global.NodeList || engine.isInstanceOf(nodeArray)) return nodeArray
					var list = engine.primordials.ObjectCreate(engine.global.NodeList.prototype),
						i
					engine.primordials.ObjectDefineProperties(list, {
						length: {
							value: nodeArray.length
						},
						item: {
							value: function (index) {
								if (!arguments.length) throw new TypeError(engine.qsNotArgs)
								return nodeArray[index >>> 0] || null
							}
						},
						forEach: {
							value: function (callback, receiver) {
								if (typeof callback != 'function') throw new TypeError('callback must be a function')
								for (var j = 0, nodeArrayLength = nodeArray.length; j < nodeArrayLength; ++j) callback.call(receiver, nodeArray[j], j, list)
							}
						}
					})
					for (var nodeArrayLength = nodeArray.length, i = 0; i < nodeArrayLength; ++i)
						engine.primordials.ObjectDefineProperty(list, i, {
							value: nodeArray[i],
							enumerable: true
						})
					if (engine.primordials.SymbolIterator) {
						var iterator = function (kind) {
							var index = 0,
								result = {
									next: function () {
										if (index >= nodeArray.length)
											return {
												value: void 0,
												done: true
											}
										var current = index++
										return {
											value: kind == 1 ? current : kind == 2 ? [current, nodeArray[current]] : nodeArray[current],
											done: false
										}
									}
								}
							result[engine.primordials.SymbolIterator] = function () {
								return this
							}
							return result
						}
						engine.primordials.ObjectDefineProperties(list, {
							values: {
								value: function () {
									return iterator(0)
								}
							},
							keys: {
								value: function () {
									return iterator(1)
								}
							},
							entries: {
								value: function () {
									return iterator(2)
								}
							}
						})
						engine.primordials.ObjectDefineProperty(list, engine.primordials.SymbolIterator, {
							value: list.values
						})
					}
					return list
				}
				function isInstanceOf(engine, nodes) {
					return !!engine.global.NodeList && nodes instanceof engine.global.NodeList
				}
				//#endregion
				//#region src/core/dom/context.mts
				function switchContext(engine, context, force) {
					var oldDoc = engine.doc
					engine.partCounts.clear()
					engine.typeRoutes.clear()
					engine.descentDeclined.clear()
					engine.siblingDeclined.clear()
					engine.doc = context.ownerDocument || context
					if (oldDoc && oldDoc !== engine.doc && engine.codeFactories === void 0) engine.codeFactories = null
					if (force || oldDoc !== engine.doc) {
						engine.root = engine.doc.documentElement
						engine.matchLambdas.clear()
						engine.selectLambdas.clear()
						engine.matchResolvers.clear()
						engine.forgivingResolvers.clear()
						engine.selectResolvers.clear()
						engine.firstResolvers.clear()
						engine.hasPlans = void 0
						if (engine.legacyHooks && !engine.Config.LEGACY && engine.legacyHooks.detect(engine.doc)) engine.Config.LEGACY = true
						engine.useLegacy(engine.Config.LEGACY)
						engine.HTML_DOCUMENT = engine.isHTML(engine.doc)
						engine.QUIRKS_MODE = engine.HTML_DOCUMENT && engine.doc.compatMode.indexOf('CSS') < 0
						engine.NAMESPACE = engine.root && engine.root.namespaceURI
						engine.Snapshot.doc = engine.doc
						engine.Snapshot.root = engine.root
						engine.hoverWanted && engine.trackHover()
					}
					return (engine.Snapshot.from = context)
				}
				//#endregion
				//#region src/core/lookup/id.mts
				function byIdRaw(engine, id, context, from) {
					var node = context,
						nodes = [],
						next
					if (engine.Config.LEGACY) return engine.legacyHooks.byIdRaw(id, context, from)
					next = from || node.firstElementChild
					while ((node = next)) {
						node.id == id && (nodes[nodes.length] = node)
						if ((next = node.firstElementChild || node.nextElementSibling)) continue
						while (!next && (node = node.parentElement) && node !== context) next = node.nextElementSibling
					}
					return nodes
				}
				function byId(engine, id, context) {
					var findIdCandidatesDone = false
					var findIdCandidatesValue
					var e,
						i,
						l,
						nodes,
						lookupRoot,
						api = engine.method['#']
					findIdCandidates()
					if (findIdCandidatesDone) return findIdCandidatesValue
					lookupRoot = context.nodeType == 9 ? context : context.getRootNode ? context.getRootNode() : null
					if (lookupRoot && lookupRoot.nodeType == 9) {
						e = lookupRoot.getElementById(id)
						if (!e) return engine.none
						if (context.nodeType == 9) return engine.byIdRaw(id, context, e)
					}
					return engine.byIdRaw(id, context)
					function findIdCandidates() {
						if (engine.Config.IDS_DUPES === false) {
							if (api in context) {
								findIdCandidatesValue = (e = context[api](id)) ? [e] : engine.none
								findIdCandidatesDone = true
								return
							}
						} else if ('all' in context) {
							if ((e = context.all[id])) {
								if (e.nodeType == 1) {
									findIdCandidatesValue = engine.attrOf(e, 'id') != id ? [] : [e]
									findIdCandidatesDone = true
									return
								} else if (id == 'length') {
									findIdCandidatesValue = (e = context[api](id)) ? [e] : engine.none
									findIdCandidatesDone = true
									return
								}
								for (i = 0, l = e.length, nodes = []; l > i; ++i) {
									var candidate = e[i]
									if (candidate && candidate.nodeType == 1 && engine.idOf(candidate) == id) nodes[nodes.length] = candidate
								}
								findIdCandidatesValue = nodes
								findIdCandidatesDone = true
								return
							} else {
								findIdCandidatesValue = engine.none
								findIdCandidatesDone = true
								return
							}
						}
					}
				}
				//#endregion
				//#region src/core/lookup/namespace.mts
				function byTagNS(engine, context, tag) {
					if (context.getElementsByTagNameNS) return engine.collectionCopy(context.getElementsByTagNameNS('*', tag), context)
					var candidates = engine.byTag('*', context),
						nodes = [],
						i
					if (tag == '*') {
						for (var candidatesLength = candidates.length, i = 0; i < candidatesLength; ++i) nodes[nodes.length] = candidates[i]
						return nodes
					}
					for (var candidatesLength = candidates.length, i = 0; i < candidatesLength; ++i)
						if (engine.tagOf(candidates[i]) == tag) nodes[nodes.length] = candidates[i]
					return nodes
				}
				//#endregion
				//#region src/core/parser/identifier.mts
				function stringFromCodePoint(engine, codePoint) {
					if (codePoint < 1 || codePoint > 1114111 || (codePoint > 55295 && codePoint < 57344)) return '�'
					if (codePoint < 65536) return engine.primordials.StringFromCharCode(codePoint)
					if (engine.primordials.StringFromCodePoint) return engine.primordials.StringFromCodePoint(codePoint)
					return engine.primordials.StringFromCharCode(((codePoint - 65536) >> 10) + 55296, ((codePoint - 65536) % 1024) + 56320)
				}
				function escapeIdentifier(engine, str) {
					return engine.REX.HasEscapes.test(str)
						? str.replace(engine.REX.FixEscapes, function (substring, p1, p2) {
								return p2
									? '\\' + p2
									: engine.REX.HexNumbers.test(p1)
										? engine.codePointToUTF16(parseInt(p1, 16))
										: engine.REX.EscOrQuote.test(p1)
											? substring
											: p1
							})
						: str
				}
				function unescapeIdentifier(engine, str) {
					return engine.REX.HasEscapes.test(str)
						? str.replace(engine.REX.FixEscapes, function (substring, p1, p2) {
								return p2 ? p2 : engine.REX.HexNumbers.test(p1) ? engine.stringFromCodePoint(parseInt(p1, 16)) : engine.REX.EscOrQuote.test(p1) ? substring : p1
							})
						: str
				}
				//#endregion
				//#region src/core/parser/logical.mts
				function matchLogical(engine, selector, prefix) {
					var chr,
						close,
						escaped,
						depth = 1,
						i,
						l,
						quote = 0,
						match = selector.match(prefix || engine.REX.LogicalPfx)
					if (!match) return null
					for (i = match[0].length, l = selector.length; l > i; ++i) {
						chr = selector.charCodeAt(i)
						if (escaped) {
							escaped = false
							continue
						}
						if (chr == 92) escaped = true
						else if (quote) {
							if (chr == quote) quote = 0
						} else if (chr == 34 || chr == 39) quote = chr
						else if (chr == 40) ++depth
						else if (chr == 41 && --depth === 0) break
					}
					close = l > i ? i + 1 : i
					return [selector.slice(0, close), match[1], selector.slice(match[0].length, i).replace(engine.REX.TrimSpaces, ''), selector.slice(close)]
				}
				function matchNth(engine, selector) {
					var match = engine.matchLogical(selector, engine.Patterns['treestruct']),
						parts
					if (!match) return null
					parts = /^(even|odd|[+-]?(?:\d*n(?:[\t\n\f\r ]*[+-][\t\n\f\r ]*\d+)?|\d+))(?:[\t\n\f\r ]+of(?![-\w\u0080-\uFFFF\\])[\t\n\f\r ]*([\s\S]+))?$/i.exec(
						match[2]
					)
					if (!parts) {
						engine.emit("'" + selector + "'" + engine.qsInvalid)
						return null
					}
					return [match[0], match[1], parts[1].toLowerCase().replace(/[\t\n\f\r ]/g, ''), parts[2], match[3]]
				}
				//#endregion
				//#region src/core/predicate/top-level-combinator.mts
				function isTopLevelCombinator(depth, char) {
					return !depth && (char == '>' || char == '+' || char == '~')
				}
				//#endregion
				//#region src/core/parser/combinator.mts
				function normalizeCombinators(_engine, text) {
					if (!/[>+~]/.test(text)) return text
					var result = '',
						depth = 0,
						quote = '',
						i = 0,
						char
					for (var textLength = text.length; i < textLength; ++i) {
						char = text.charAt(i)
						if (char == '\\') {
							result += char + text.charAt(++i)
							continue
						}
						if (quote) {
							if (char == quote) quote = ''
						} else if (char == '"' || char == "'") quote = char
						else if (char == '(' || char == '[') ++depth
						else if (char == ')' || char == ']') --depth
						else if (isTopLevelCombinator(depth, char)) {
							result = result.replace(/[\t\n\f\r ]+$/, '')
							while (/[\t\n\f\r ]/.test(text.charAt(i + 1)) && i + 1 < text.length) ++i
						}
						result += char
					}
					return result
				}
				//#endregion
				//#region src/core/parser/list.mts
				function splitList(engine, text) {
					var chr,
						depth = 0,
						escaped,
						i = 0,
						l = text.length,
						quote = 0,
						start = 0,
						list = []
					for (; l > i; ++i) {
						chr = text.charCodeAt(i)
						if (escaped) {
							escaped = false
							continue
						}
						if (chr == 92) escaped = true
						else if (quote) {
							if (chr == quote) quote = 0
						} else if (chr == 34 || chr == 39) quote = chr
						else if (chr == 40 || chr == 91) ++depth
						else if (chr == 41 || chr == 93) --depth
						else if (chr == 44 && depth === 0) {
							list[list.length] = text.slice(start, i).replace(engine.REX.TrimSpaces, '')
							start = i + 1
						}
					}
					list[list.length] = text.slice(start).replace(engine.REX.TrimSpaces, '')
					return list
				}
				//#endregion
				//#region src/core/initialize/runtime.mts
				function initializeRuntime(engine) {
					engine.version = 'nwsapi-2.3.0-prerelease'
					engine.primordials = engine.Factory['_primordials']
					engine.hostReaders = engine.global.hostReaders
					engine.doc = engine.global.document
					engine.root = engine.doc.documentElement
					engine.ELEMENT_PROTO = engine.global.Element && engine.global.Element.prototype
					engine.sliceCall = engine.primordials.ArrayPrototypeSlice
					engine.CFG = {
						operators: '[~*^$|]=|=',
						combinators: '[\\x20\\t>+~](?=[^>+~])'
					}
					engine.REX = {
						HasEscapes: /\\/,
						HexNumbers: /^[0-9a-fA-F]/,
						EscOrQuote: /^\\|[\x22\x27]/,
						RegExpChar: /(?!\\)[\\^$.,*+?()[\]{}|\/]/g,
						TrimSpaces: /^[\x20\t\r\n\f]+|[\x20\t\r\n\f]+$/g,
						SplitGroup: /(\([^)]*\)|\[[^[]*\]|\\.|[^,])+/g,
						CommaGroup: /(\s*,\s*)(?![^\x5b]*\x5d)(?![^\x28]*\x29)/g,
						FixEscapes: /\\([0-9a-fA-F]{1,6}[\x20\t\r\n\f]?|.)|([\x22\x27])/g,
						CombineWSP: /\\[0-9a-fA-F]{1,6}(?:\r\n|[\t\n\r\f\x20])?|[\n\r\f\x20]+(?=(?:[^']*['][^']*['])*[^']*$)(?=(?:[^"]*["][^"]*["])*[^"]*$)/g,
						TabCharWSP: /(\x20?\t+\x20?)(?=(?:[^']*['][^']*['])*[^']*$)(?=(?:[^"]*["][^"]*["])*[^"]*$)/g,
						LogicalPfx: /^:(is|where|matches|not|has)\x28/i
					}
					engine.STD = {
						apimethods: /^(?:\w+|\*)\|/
					}
					engine.Patterns = {
						treestruct: /^:(nth(?:-last)?(?:-child|-of-type))\(/i,
						structural: /^:(?:(scope|root|empty|(?:(?:first|last|only)(?:-child|\-of\-type)))\b)(.*)/i,
						linguistic: /^:(?:(dir)(?:\x28\s?([-\w]{2,})\s?(?:\x29|$)))(.*)/i,
						useraction: /^:(?:(hover|active|focus\-within|focus\-visible|focus)\b)(.*)/i,
						inputstate: /^:(?:(enabled|disabled|read\-only|read\-write|placeholder\-shown|default|autofill|-webkit\-autofill)\b)(.*)/i,
						inputvalue: /^:(?:(checked|indeterminate|required|optional|valid|invalid|in\-range|out\-of\-range)\b)(.*)/i,
						rsrc_state: /^:(?:(playing|paused|seeking|buffering|stalled|muted|volume\-locked)\b)(.*)/i,
						disp_state: /^:(?:(open|closed|modal|fullscreen|picture\-in\-picture|popover\-open|popover)\b)(.*)/i,
						time_state: /^:(?:(current|past|future)\b)(.*)/i,
						locationpc: /^:(?:(any\-link|link|visited|target|defined)\b)(.*)/i,
						logicalsel: /^:(?:(is|where|matches|not|has)(?:\x28\s?([^()]*|.*)\s?(?:\x29|$)))(.*)/i,
						pseudo_sng: /^:(?:(after|before|first\-letter|first\-line)\b)(.*)/i,
						children: /^[\x20\t\r\n\f]?\>[\x20\t\r\n\f]?(.*)/,
						adjacent: /^[\x20\t\r\n\f]?\+[\x20\t\r\n\f]?(.*)/,
						relative: /^[\x20\t\r\n\f]?\~[\x20\t\r\n\f]?(.*)/,
						ancestor: /^[\x20\t\r\n\f]+(.*)/,
						universal: /^(\*)(.*)/,
						namespace: /^(\*|[\w-]+)?\|(.*)/
					}
					engine.reLinkName = /^(?:a|area)$/i
					engine.qsNotArgs = 'Not enough arguments'
					engine.qsInvalid = ' is not a valid selector'
					engine.reNthElem = /(:nth(?:-last)?-child)/i
					engine.reNthType = /(:nth(?:-last)?-of-type)/i
					engine.Config = {
						IDS_DUPES: true,
						FORGIVING: true,
						LEGACY: false,
						NEURAL_PLANNER: true,
						NODE_LIST: false,
						LOGERRORS: true,
						USR_EVENT: true,
						VERBOSITY: true
					}
					engine.bulkHasPlanner = neuralPlannerPolicy('chromium')
					engine.createWeakMap = createWeakMap.bind(null, engine)
					engine.ATTR_STD_OPS = {
						'=': 1,
						'^=': 1,
						'$=': 1,
						'|=': 1,
						'*=': 1,
						'~=': 1
					}
					engine.HTML_TABLE = {
						accept: 1,
						'accept-charset': 1,
						align: 1,
						alink: 1,
						axis: 1,
						bgcolor: 1,
						charset: 1,
						checked: 1,
						clear: 1,
						codetype: 1,
						color: 1,
						compact: 1,
						declare: 1,
						defer: 1,
						dir: 1,
						direction: 1,
						disabled: 1,
						enctype: 1,
						face: 1,
						frame: 1,
						hreflang: 1,
						'http-equiv': 1,
						lang: 1,
						language: 1,
						link: 1,
						media: 1,
						method: 1,
						multiple: 1,
						nohref: 1,
						noresize: 1,
						noshade: 1,
						nowrap: 1,
						readonly: 1,
						rel: 1,
						rev: 1,
						rules: 1,
						scope: 1,
						scrolling: 1,
						selected: 1,
						shape: 1,
						target: 1,
						text: 1,
						type: 1,
						valign: 1,
						valuetype: 1,
						vlink: 1
					}
					engine.Combinators = {}
					engine.Selectors = {}
					engine.Operators = {
						'=': {
							p1: '^',
							p2: '$',
							p3: 'true'
						},
						'^=': {
							p1: '^',
							p2: '',
							p3: 'true'
						},
						'$=': {
							p1: '',
							p2: '$',
							p3: 'true'
						},
						'*=': {
							p1: '',
							p2: '',
							p3: 'true'
						},
						'|=': {
							p1: '^',
							p2: '(-|$)',
							p3: 'true'
						},
						'~=': {
							p1: '(^|[\\t\\n\\f\\r ])',
							p2: '([\\t\\n\\f\\r ]|$)',
							p3: 'true'
						}
					}
					engine.concatCall = concatCall.bind(null, engine)
					engine.concatList = concatList.bind(null, engine)
					engine.CACHE_LIMIT = 4096
					engine.createCache = createCache.bind(null, engine)
					engine.toNodeList = toNodeList.bind(null, engine)
					engine.isInstanceOf = isInstanceOf.bind(null, engine)
					engine.documentOrder = documentOrder.bind(null, engine)
					engine.mergeResults = mergeResults.bind(null, engine)
					engine.hasDupes = false
					engine.unique = unique.bind(null, engine)
					engine.switchContext = switchContext.bind(null, engine)
					engine.codePointToUTF16 = codePointToUTF16.bind(null, engine)
					engine.stringFromCodePoint = stringFromCodePoint.bind(null, engine)
					engine.escapeIdentifier = escapeIdentifier.bind(null, engine)
					engine.unescapeIdentifier = unescapeIdentifier.bind(null, engine)
					engine.splitList = splitList.bind(null, engine)
					engine.matchLogical = matchLogical.bind(null, engine)
					engine.matchNth = matchNth.bind(null, engine)
					engine.normalizeCombinators = normalizeCombinators.bind(null, engine)
					engine.method = {
						'#': 'getElementById',
						'*': 'getElementsByTagName',
						'|': 'getElementsByTagNameNS',
						'.': 'getElementsByClassName'
					}
					engine.fetch = {
						'#': function (n, c) {
							return engine.byId(n, c)
						},
						'*': function (n, c) {
							return engine.byTag(n, c)
						},
						'|': function (n, c) {
							return engine.byTagNS(c, n)
						},
						'.': function (n, c) {
							return /[\t\n\f\r ]/.test(n) ? [] : engine.byClass(n, c)
						},
						'?': function (n, c) {
							return engine.byTags(n, c)
						}
					}
					engine.byIdRaw = byIdRaw.bind(null, engine)
					engine.byId = byId.bind(null, engine)
					engine.byTagNS = byTagNS.bind(null, engine)
					engine.typeRoutes = engine.createCache()
					engine.byTags = byTags.bind(null, engine)
					engine.collectionRoots = null
					engine.collectionStates = null
					engine.collectionSnapshot = collectionSnapshot.bind(null, engine)
					engine.collectionCopy = collectionCopy.bind(null, engine)
					engine.asciiLower = asciiLower.bind(null, engine)
					engine.matchesTag = matchesTag.bind(null, engine)
					engine.hasClass = hasClass.bind(null, engine)
					engine.foreignTypeRoots = null
					engine.hasForeignTypes = hasForeignTypes.bind(null, engine)
					engine.byTag = byTag.bind(null, engine)
					engine.byClass = byClass.bind(null, engine)
					engine.attributeValueNS = attributeValueNS.bind(null, engine)
					engine.hasAttributeNS = hasAttributeNS.bind(null, engine)
					engine.includes = engine.primordials.StringPrototypeIncludes
					engine.attrOf =
						(engine.hostReaders && engine.hostReaders.attrOf) ||
						function (e, name) {
							return e.getAttribute(name)
						}
					engine.hasAttrOf =
						(engine.hostReaders && engine.hostReaders.hasAttrOf) ||
						function (e, name) {
							return e.hasAttribute(name)
						}
					engine.tagOf = tagOf.bind(null, engine)
					engine.idOf = idOf.bind(null, engine)
					engine.upOf =
						(engine.hostReaders && engine.hostReaders.upOf) ||
						function (e) {
							return e.parentElement
						}
					engine.nextOf =
						(engine.hostReaders && engine.hostReaders.nextOf) ||
						function (e) {
							return e.nextElementSibling
						}
					engine._prevOf =
						(engine.hostReaders && engine.hostReaders.prevOf) ||
						function (e) {
							return e.previousElementSibling
						}
					engine.firstOf = firstOf.bind(null, engine)
					engine.attrNamesOf = attrNamesOf.bind(null, engine)
					engine.connectedOf = connectedOf.bind(null, engine)
					engine.modernReaders = {
						includes: engine.includes,
						attrOf: engine.attrOf,
						hasAttrOf: engine.hasAttrOf,
						tagOf: engine.tagOf,
						idOf: engine.idOf,
						legacyClassOf: function (e) {
							return engine.classOf(e) || ''
						},
						upOf: engine.upOf,
						nextOf: engine.nextOf,
						prevOf: engine._prevOf,
						firstOf: engine.firstOf,
						attrNamesOf: engine.attrNamesOf,
						connectedOf: engine.connectedOf
					}
					engine.useLegacy = useLegacy.bind(null, engine)
					engine.classOf = classOf.bind(null, engine)
					engine.readDirect = {
						tag: function (v) {
							return v + '.localName'
						},
						id: function (v) {
							return v + '.id'
						},
						cls: function (v) {
							return 's.classOf(' + v + ')'
						},
						up: function (v) {
							return engine.hostReaders && engine.hostReaders.upOf ? 's.upOf(' + v + ')' : v + '.parentElement'
						},
						next: function (v) {
							return engine.hostReaders && engine.hostReaders.nextOf ? 's.nextOf(' + v + ')' : v + '.nextElementSibling'
						},
						prev: function (v) {
							return engine.hostReaders && engine.hostReaders.prevOf ? 's.prevOf(' + v + ')' : v + '.previousElementSibling'
						},
						attr: function (v, name) {
							return engine.hostReaders && engine.hostReaders.attrOf ? 's.attrOf(' + v + ',"' + name + '")' : v + '.getAttribute("' + name + '")'
						},
						has: function (v, name) {
							return engine.hostReaders && engine.hostReaders.hasAttrOf ? 's.hasAttrOf(' + v + ',"' + name + '")' : v + '.hasAttribute("' + name + '")'
						}
					}
					engine.readGuarded = {
						tag: engine.readDirect.tag,
						id: engine.readDirect.id,
						cls: engine.readDirect.cls,
						up: engine.readDirect.up,
						next: engine.readDirect.next,
						prev: engine.readDirect.prev,
						attr: function (v, name) {
							return engine.hostReaders && engine.hostReaders.attrOf
								? engine.readDirect.attr(v, name)
								: v + '.getAttribute&&' + v + '.getAttribute("' + name + '")'
						},
						has: function (v, name) {
							return engine.hostReaders && engine.hostReaders.hasAttrOf
								? engine.readDirect.has(v, name)
								: v + '.hasAttribute&&' + v + '.hasAttribute("' + name + '")'
						}
					}
				}
				//#endregion
				//#region src/core/initialize/factory.mts
				function createEngine(global, Factory) {
					var engine = createState(global, Factory)
					initializeRuntime(engine)
					initializeMatching(engine)
					initializeApi(engine)
					engine.initialize(engine.doc)
					return engine.Dom
				}
				//#endregion
				exports1.createEngine = createEngine
				return exports1
			})({})
			return core
		})()
	})
	primordials.ObjectDefineProperty(factory, '_direction', {
		value: (function () {
			var unicodeDirection = (function (exports1) {
				//#region src/core/unicode/dom.mts
				function htmlName(element) {
					return element.namespaceURI === 'http://www.w3.org/1999/xhtml' ? element.localName : ''
				}
				function explicitDirection(element) {
					return htmlName(element) ? (element.getAttribute('dir') || '').toLowerCase() : ''
				}
				function shadowHost(node) {
					return node.nodeType === 11 ? node.host || null : null
				}
				function directionParent(element) {
					return element.parentElement || (element.parentNode && shadowHost(element.parentNode))
				}
				function excluded(element) {
					var name = htmlName(element)
					return !!name && (/^(?:bdi|script|style|textarea)$/.test(name) || /^(?:ltr|rtl|auto)$/.test(explicitDirection(element)))
				}
				function slotHost(element) {
					return htmlName(element) === 'slot' && element.getRootNode ? shadowHost(element.getRootNode()) : null
				}
				//#endregion
				//#region node_modules/.pnpm/@unicode+unicode-17.0.0@2.0.2/node_modules/@unicode/unicode-17.0.0/Bidi_Class/Left_To_Right/regex.mjs
				var regex_default$2 =
					/[A-Za-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02B8\u02BB-\u02C1\u02D0\u02D1\u02E0-\u02E4\u02EE\u0370-\u0373\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0482\u048A-\u052F\u0531-\u0556\u0559-\u0589\u0903-\u0939\u093B\u093D-\u0940\u0949-\u094C\u094E-\u0950\u0958-\u0961\u0964-\u0980\u0982\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD-\u09C0\u09C7\u09C8\u09CB\u09CC\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09FA\u09FC\u09FD\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3E-\u0A40\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A76\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD-\u0AC0\u0AC9\u0ACB\u0ACC\u0AD0\u0AE0\u0AE1\u0AE6-\u0AF0\u0AF9\u0B02\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B3E\u0B40\u0B47\u0B48\u0B4B\u0B4C\u0B57\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE\u0BBF\u0BC1\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCC\u0BD0\u0BD7\u0BE6-\u0BF2\u0C01-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C41-\u0C44\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C77\u0C7F\u0C80\u0C82-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD-\u0CC4\u0CC6-\u0CC8\u0CCA\u0CCB\u0CD5\u0CD6\u0CDC-\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1-\u0CF3\u0D02-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D40\u0D46-\u0D48\u0D4A-\u0D4C\u0D4E\u0D4F\u0D54-\u0D61\u0D66-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCF-\u0DD1\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2-\u0DF4\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E4F-\u0E5B\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00-\u0F17\u0F1A-\u0F34\u0F36\u0F38\u0F3E-\u0F47\u0F49-\u0F6C\u0F7F\u0F85\u0F88-\u0F8C\u0FBE-\u0FC5\u0FC7-\u0FCC\u0FCE-\u0FDA\u1000-\u102C\u1031\u1038\u103B\u103C\u103F-\u1057\u105A-\u105D\u1061-\u1070\u1075-\u1081\u1083\u1084\u1087-\u108C\u108E-\u109C\u109E-\u10C5\u10C7\u10CD\u10D0-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1360-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u167F\u1681-\u169A\u16A0-\u16F8\u1700-\u1711\u1715\u171F-\u1731\u1734-\u1736\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17B6\u17BE-\u17C5\u17C7\u17C8\u17D4-\u17DA\u17DC\u17E0-\u17E9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1923-\u1926\u1929-\u192B\u1930\u1931\u1933-\u1938\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A19\u1A1A\u1A1E-\u1A55\u1A57\u1A61\u1A63\u1A64\u1A6D-\u1A72\u1A80-\u1A89\u1A90-\u1A99\u1AA0-\u1AAD\u1B04-\u1B33\u1B35\u1B3B\u1B3D-\u1B41\u1B43-\u1B4C\u1B4E-\u1B6A\u1B74-\u1B7F\u1B82-\u1BA1\u1BA6\u1BA7\u1BAA\u1BAE-\u1BE5\u1BE7\u1BEA-\u1BEC\u1BEE\u1BF2\u1BF3\u1BFC-\u1C2B\u1C34\u1C35\u1C3B-\u1C49\u1C4D-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CC7\u1CD3\u1CE1\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5-\u1CF7\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200E\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u214F\u2160-\u2188\u2336-\u237A\u2395\u249C-\u24E9\u26AC\u2800-\u28FF\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D70\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u302E\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3190-\u31BF\u31F0-\u321C\u3220-\u324F\u3260-\u327B\u327F-\u32B0\u32C0-\u32CB\u32D0-\u3376\u337B-\u33DD\u33E0-\u33FE\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA60C\uA610-\uA62B\uA640-\uA66E\uA680-\uA69D\uA6A0-\uA6EF\uA6F2-\uA6F7\uA722-\uA787\uA789-\uA7DC\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA824\uA827\uA830-\uA837\uA840-\uA873\uA880-\uA8C3\uA8CE-\uA8D9\uA8F2-\uA8FE\uA900-\uA925\uA92E-\uA946\uA952\uA953\uA95F-\uA97C\uA983-\uA9B2\uA9B4\uA9B5\uA9BA\uA9BB\uA9BE-\uA9CD\uA9CF-\uA9D9\uA9DE-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA2F\uAA30\uAA33\uAA34\uAA40-\uAA42\uAA44-\uAA4B\uAA4D\uAA50-\uAA59\uAA5C-\uAA7B\uAA7D-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAAEB\uAAEE-\uAAF5\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB69\uAB70-\uABE4\uABE6\uABE7\uABE9-\uABEC\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uE000-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD00\uDD02\uDD07-\uDD33\uDD37-\uDD3F\uDD8D\uDD8E\uDDD0-\uDDFC\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF23\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDF9F-\uDFC3\uDFC8-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD6F-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDDC0-\uDDF3\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD804[\uDC00\uDC02-\uDC37\uDC47-\uDC4D\uDC66-\uDC6F\uDC71\uDC72\uDC75\uDC82-\uDCB2\uDCB7\uDCB8\uDCBB-\uDCC1\uDCCD\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD03-\uDD26\uDD2C\uDD36-\uDD47\uDD50-\uDD72\uDD74-\uDD76\uDD82-\uDDB5\uDDBF-\uDDC8\uDDCD\uDDCE\uDDD0-\uDDDF\uDDE1-\uDDF4\uDE00-\uDE11\uDE13-\uDE2E\uDE32\uDE33\uDE35\uDE38-\uDE3D\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA9\uDEB0-\uDEDE\uDEE0-\uDEE2\uDEF0-\uDEF9\uDF02\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D-\uDF3F\uDF41-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF80-\uDF89\uDF8B\uDF8E\uDF90-\uDFB5\uDFB7-\uDFBA\uDFC2\uDFC5\uDFC7-\uDFCA\uDFCC\uDFCD\uDFCF\uDFD1\uDFD3-\uDFD5\uDFD7\uDFD8]|\uD805[\uDC00-\uDC37\uDC40\uDC41\uDC45\uDC47-\uDC5B\uDC5D\uDC5F-\uDC61\uDC80-\uDCB2\uDCB9\uDCBB-\uDCBE\uDCC1\uDCC4-\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB1\uDDB8-\uDDBB\uDDBE\uDDC1-\uDDDB\uDE00-\uDE32\uDE3B\uDE3C\uDE3E\uDE41-\uDE44\uDE50-\uDE59\uDE80-\uDEAA\uDEAC\uDEAE\uDEAF\uDEB6\uDEB8\uDEB9\uDEC0-\uDEC9\uDED0-\uDEE3\uDF00-\uDF1A\uDF1E\uDF20\uDF21\uDF26\uDF30-\uDF46]|\uD806[\uDC00-\uDC2E\uDC38\uDC3B\uDCA0-\uDCF2\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD35\uDD37\uDD38\uDD3D\uDD3F-\uDD42\uDD44-\uDD46\uDD50-\uDD59\uDDA0-\uDDA7\uDDAA-\uDDD3\uDDDC-\uDDDF\uDDE1-\uDDE4\uDE00\uDE07\uDE08\uDE0B-\uDE32\uDE39\uDE3A\uDE3F-\uDE46\uDE50\uDE57\uDE58\uDE5C-\uDE89\uDE97\uDE9A-\uDEA2\uDEB0-\uDEF8\uDF00-\uDF09\uDF61\uDF65\uDF67\uDFC0-\uDFE1\uDFF0-\uDFF9]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2F\uDC3E-\uDC45\uDC50-\uDC6C\uDC70-\uDC8F\uDCA9\uDCB1\uDCB4\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD50-\uDD59\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD8E\uDD93\uDD94\uDD96\uDD98\uDDA0-\uDDA9\uDDB0-\uDDDB\uDDE0-\uDDE9\uDEE0-\uDEF2\uDEF5-\uDEF8\uDF02-\uDF10\uDF12-\uDF35\uDF3E\uDF3F\uDF41\uDF43-\uDF59\uDFB0\uDFC0-\uDFD4\uDFFF]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC70-\uDC74\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF2]|[\uD80C\uD80E\uD80F\uD81C-\uD822\uD840-\uD868\uD86A-\uD86D\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD88C\uDB80-\uDBBE\uDBC0-\uDBFE][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC3F\uDC41-\uDC46\uDC60-\uDFFF]|\uD810[\uDC00-\uDFFA]|\uD811[\uDC00-\uDE46]|\uD818[\uDD00-\uDD1D\uDD2A-\uDD2C\uDD30-\uDD39]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDE6E-\uDEBE\uDEC0-\uDEC9\uDED0-\uDEED\uDEF5\uDF00-\uDF2F\uDF37-\uDF45\uDF50-\uDF59\uDF5B-\uDF61\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDD40-\uDD79\uDE40-\uDE9A\uDEA0-\uDEB8\uDEBB-\uDED3\uDF00-\uDF4A\uDF50-\uDF87\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3\uDFF0-\uDFF6]|\uD823[\uDC00-\uDCD5\uDCFF-\uDD1E\uDD80-\uDDF2]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9C\uDC9F]|\uD833[\uDCD6-\uDCEF\uDF50-\uDFC3]|\uD834[\uDC00-\uDCF5\uDD00-\uDD26\uDD29-\uDD66\uDD6A-\uDD72\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDDE8\uDEC0-\uDED3\uDEE0-\uDEF3\uDF60-\uDF78]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE8B]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD40-\uDD49\uDD4E\uDD4F\uDE90-\uDEAD\uDEC0-\uDEEB\uDEF0-\uDEF9]|\uD839[\uDCD0-\uDCEB\uDCF0-\uDCF9\uDDD0-\uDDED\uDDF0-\uDDFA\uDDFF\uDEC0-\uDEDE\uDEE0-\uDEE2\uDEE4\uDEE5\uDEE7-\uDEED\uDEF0-\uDEF4\uDEFE\uDEFF\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83C[\uDD10-\uDD2E\uDD30-\uDD69\uDD70-\uDDAC\uDDE6-\uDE02\uDE10-\uDE3B\uDE40-\uDE48\uDE50\uDE51]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEAD\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD88D[\uDC00-\uDC79]|[\uDBBF\uDBFF][\uDC00-\uDFFD]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/
				//#endregion
				//#region node_modules/.pnpm/@unicode+unicode-17.0.0@2.0.2/node_modules/@unicode/unicode-17.0.0/Bidi_Class/Right_To_Left/regex.mjs
				var regex_default$1 =
					/[\u05BE\u05C0\u05C3\u05C6\u05D0-\u05EA\u05EF-\u05F4\u07C0-\u07EA\u07F4\u07F5\u07FA\u07FE-\u0815\u081A\u0824\u0828\u0830-\u083E\u0840-\u0858\u085E\u200F\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFB4F]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC57-\uDC9E\uDCA7-\uDCAF\uDCE0-\uDCF2\uDCF4\uDCF5\uDCFB-\uDD1B\uDD20-\uDD39\uDD3F-\uDD59\uDD80-\uDDB7\uDDBC-\uDDCF\uDDD2-\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE40-\uDE48\uDE50-\uDE58\uDE60-\uDE9F\uDEC0-\uDEE4\uDEEB-\uDEF6\uDF00-\uDF35\uDF40-\uDF55\uDF58-\uDF72\uDF78-\uDF91\uDF99-\uDF9C\uDFA9-\uDFAF]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDCFA-\uDCFF\uDD4A-\uDD65\uDD6F-\uDD85\uDD8E\uDD8F\uDE80-\uDEA9\uDEAD\uDEB0\uDEB1\uDF00-\uDF27\uDF70-\uDF81\uDF86-\uDF89\uDFB0-\uDFCB\uDFE0-\uDFF6]|\uD83A[\uDC00-\uDCC4\uDCC7-\uDCCF\uDD00-\uDD43\uDD4B\uDD50-\uDD59\uDD5E\uDD5F]/
				//#endregion
				//#region node_modules/.pnpm/@unicode+unicode-17.0.0@2.0.2/node_modules/@unicode/unicode-17.0.0/Bidi_Class/Arabic_Letter/regex.mjs
				var regex_default =
					/[\u0608\u060B\u060D\u061B-\u064A\u066D-\u066F\u0671-\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u070D\u070F\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u0860-\u086A\u0870-\u088F\u08A0-\u08C9\uFB50-\uFBC2\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFC\uFE70-\uFE74\uFE76-\uFEFC]|\uD803[\uDD00-\uDD23\uDEC2-\uDEC7\uDF30-\uDF45\uDF51-\uDF59]|\uD83B[\uDC71-\uDCB4\uDD01-\uDD3D\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]/
				//#endregion
				//#region src/core/unicode/text-direction.mts
				function textDirection(text) {
					var left = text.search(regex_default$2)
					if (left === 0) return 'ltr'
					var prefix = left < 0 ? text : text.slice(0, left)
					if (regex_default$1.test(prefix) || regex_default.test(prefix)) return 'rtl'
					return left < 0 ? null : 'ltr'
				}
				//#endregion
				//#region src/core/unicode/direction.mts
				function containedText(root, excludeRoot) {
					if (excludeRoot && excluded(root)) return null
					var node = root
					while (node) {
						var skip = false
						if (node.nodeType === 3) {
							var value = textDirection(node.data)
							if (value) return value
						} else if (node.nodeType === 1) {
							var element = node
							skip = element !== root && excluded(element)
							if (!skip) {
								var host = slotHost(element)
								if (host) return directionality(host)
							}
						}
						if (!skip && node.firstChild) {
							node = node.firstChild
							continue
						}
						while (node !== root && !node.nextSibling) node = node.parentNode
						node = node === root ? null : node.nextSibling
					}
					return null
				}
				function autoDirection(element) {
					var name = htmlName(element)
					if (name === 'textarea' || (name === 'input' && /^(?:hidden|text|search|tel|url|email|password|submit|reset|button)$/.test(element.type))) {
						var value = element.value
						return textDirection(value) || (value ? 'ltr' : null)
					}
					if (name === 'slot' && element.getRootNode && shadowHost(element.getRootNode())) {
						var assigned = element.assignedNodes()
						if (assigned.length) {
							for (var index = 0, assignedLength = assigned.length; index < assignedLength; index++) {
								var node = assigned[index]
								var value1 = node.nodeType === 3 ? textDirection(node.data) : node.nodeType === 1 ? containedText(node, true) : null
								if (value1) return value1
							}
							return null
						}
					}
					return containedText(element, false)
				}
				function directionality(element) {
					var current = element
					while (current) {
						var dir = explicitDirection(current)
						if (dir === 'ltr' || dir === 'rtl') return dir
						var name = htmlName(current)
						if (dir === 'auto' || name === 'bdi') return autoDirection(current) || 'ltr'
						if (name === 'input' && current.type === 'tel') return 'ltr'
						current = directionParent(current)
					}
					return 'ltr'
				}
				//#endregion
				exports1.autoDirection = autoDirection
				exports1.containedText = containedText
				exports1.directionParent = directionParent
				exports1.directionality = directionality
				exports1.excluded = excluded
				exports1.explicitDirection = explicitDirection
				exports1.htmlName = htmlName
				exports1.shadowHost = shadowHost
				exports1.slotHost = slotHost
				exports1.textDirection = textDirection
				return exports1
			})({})
			return unicodeDirection
		})()
	})
	// Share immutable grammar templates, never the mutable lastIndex of a
	// validation regexp. Custom grammars stay local and are not retained here.
	var defaultSyntax
	primordials.ObjectDefineProperty(factory, '_identifierSyntax', {
		value: function (operators, combinators) {
			var standard = operators == '[~*^$|]=|=' && combinators == '[\\x20\\t>+~](?=[^>+~])'
			if (standard && defaultSyntax) {
				return defaultSyntax
			}
			var HSP = '\\x20\\t',
				VSP = '\\r\\n\\f',
				WSP = '[' + HSP + VSP + ']'
			//
			// NOTE: SPECIAL CASES IN CSS SYNTAX PARSING RULES
			//
			// The <EOF-token> https://drafts.csswg.org/css-syntax/#typedef-eof-token
			// allow mangled|unclosed selector syntax at the end of selectors strings
			//
			// Literal equivalent hex representations of the characters: " ' ` ] )
			//
			//     \\x22 = " - double quotes    \\x5b = [ - open square bracket
			//     \\x27 = ' - single quote     \\x5d = ] - closed square bracket
			//     \\x60 = ` - back tick        \\x28 = ( - open round parens
			//     \\x5c = \ - back slash       \\x29 = ) - closed round parens
			//
			// using hex format prevents false matches of opened/closed instances
			// pairs, coloring breakage and other editors highlightning problems.
			//
			var parenthesized,
				noascii = '[^\\x00-\\x7f]',
				unicode = '\\\\[0-9a-fA-F]{1,6}',
				escaped = '(?:' + unicode + WSP + '?|\\\\[^' + VSP + '])',
				identStart = '(?:[_a-zA-Z]|' + noascii + '|' + escaped + ')',
				identifier = '(?:--|-?' + identStart + ')(?:[\\w-]|' + noascii + '|' + escaped + ')*',
				pseudonames = '[-\\w]+',
				pseudoparms = '(?:[-+]?(?:\\d*n(?:\\s?[-+]?\\s?\\d*)?|\\d+))',
				doublequote = '"[^"\\\\' + VSP + ']*(?:\\\\.[^"\\\\' + VSP + ']*)*(?:"|$)',
				singlequote = "'[^'\\\\" + VSP + "]*(?:\\\\.[^'\\\\" + VSP + "]*)*(?:'|$)",
				attrparser = identifier + '|' + doublequote + '|' + singlequote,
				attrvalues = '([\\x22\\x27]?)((?!\\3)*|(?:\\\\?.)*?)(?:\\3|$)',
				attributes =
					'\\[' +
					WSP +
					'?' +
					'(?:\\*\\||\\|)?' +
					'(' +
					identifier +
					'(?::' +
					identifier +
					')?)' +
					WSP +
					'?' +
					'(?:' +
					'(' +
					operators +
					')' +
					WSP +
					'?' +
					'(?:' +
					attrparser +
					')' +
					')?' +
					'(?:' +
					WSP +
					'?\\b([iIsS]))?' +
					WSP +
					'?' +
					'(?:\\]|$)',
				attrmatcher = attributes.replace(attrparser, attrvalues),
				pseudoclass =
					'(?:\\x28' +
					WSP +
					'*' +
					'(?:' +
					pseudoparms +
					'?)?|' +
					'(?:\\*\\||\\||\\*)|' +
					'(?:' +
					'(?::' +
					pseudonames +
					'(?:\\x28' +
					pseudoparms +
					'?(?:\\x29|$))?|' +
					')|' +
					doublequote +
					'|' +
					singlequote +
					'|' +
					'(?:[-+]?\\d+)|' +
					'(?:[.#]?' +
					identifier +
					')|' +
					'(?:' +
					attributes +
					')' +
					')+|' +
					'(?:' +
					WSP +
					'?[>+~](?=[^>+~])' +
					WSP +
					'?)|' +
					'(?:' +
					WSP +
					'?,' +
					WSP +
					'?)|' +
					'(?:' +
					WSP +
					'?)|' +
					'(?:\\x29|$)' +
					')*',
				standardValidator =
					'(?=' +
					WSP +
					'?[^>+~(){}<>])' +
					'(?:' +
					'(?:\\*\\||\\||\\*)|' +
					'(?:[.#]?' +
					identifier +
					')+|' +
					'(?:' +
					attributes +
					')+|' +
					'(?:::?' +
					pseudonames +
					pseudoclass +
					')|' +
					'(?:' +
					WSP +
					'?' +
					combinators +
					WSP +
					'?)|' +
					'(?:' +
					WSP +
					'?,' +
					WSP +
					'?)|' +
					'(?:' +
					WSP +
					'?)' +
					')+'
			// the following global RE is used to return the
			// deepest localName in selector strings and then
			// use it to retrieve all possible matching nodes
			// that will be filtered by compiled resolvers
			// The parenthesized part has to tolerate nesting. Written as
			// '\x28[^\x29]+' it stops at the first ')', so a final compound
			// holding a nested functional pseudo-class matches nothing at all, and
			// a selector the optimizer cannot read is answered by testing every
			// element in the context instead of the elements of one tag or class.
			parenthesized = '\\x28[^\\x28\\x29]*(?:\\x29|$)'
			parenthesized = '\\x28(?:[^\\x28\\x29]|' + parenthesized + ')*(?:\\x29|$)'
			parenthesized = '\\x28(?:[^\\x28\\x29]|' + parenthesized + ')*(?:\\x29|$)'
			var optimizer = RegExp('(?:([.:#*]?)' + '(' + identifier + ')' + '(?:' + ':[-\\w]+|' + '\\[[^\\]]+(?:\\]|$)|' + parenthesized + ')*)$')
			var syntax = {
				optimizer: optimizer,
				validator: RegExp(standardValidator, 'g'),
				simpleId: RegExp('^#(' + identifier + ')$'),
				id: RegExp('^#(' + identifier + ')(.*)'),
				tagName: RegExp('^(' + identifier + ')(.*)'),
				className: RegExp('^\\.(' + identifier + ')(.*)'),
				attribute: RegExp('^(?:' + attrmatcher + ')(.*)')
			}
			if (standard) {
				defaultSyntax = syntax
			}
			return syntax
		}
	})
	// Keep observer callbacks outside an engine's closure. Weak ownership lets
	// an engine and its snapshots disappear while the document stays alive.
	var collectionFinalizer
	primordials.ObjectDefineProperty(factory, '_observeCollections', {
		value: function (root, view, state) {
			var reference = new primordials.WeakRefCtor(state)
			var observer = new view.MutationObserver(function (_records, current) {
				var snapshot = reference.deref()
				if (snapshot) {
					if ('dirty' in snapshot) {
						snapshot.dirty = true
					} else {
						snapshot.copies = new primordials.WeakMapCtor()
					}
				} else {
					current.disconnect()
				}
			})
			if (primordials.FinalizationRegistryCtor) {
				collectionFinalizer ||
					(collectionFinalizer = new primordials.FinalizationRegistryCtor(function (reference) {
						var observer = reference.deref()
						if (observer) {
							observer.disconnect()
						}
					}))
				collectionFinalizer.register(state, new primordials.WeakRefCtor(observer))
			}
			observer.observe(
				root,
				'dirty' in state
					? {
							childList: true,
							subtree: true
						}
					: {
							childList: true,
							subtree: true,
							attributes: true,
							attributeFilter: ['class']
						}
			)
			return observer
		}
	})
	if (typeof module == 'object' && typeof exports == 'object') {
		module.exports = factory
		primordials.ObjectDefineProperty(module.exports, 'DOMSelector', {
			get: function () {
				return require('./adapter/dom-selector.js')
			}
		})
	} else if (typeof define == 'function' && define['amd']) {
		define(factory)
	} else {
		global.NW || (global.NW = {})
		global.NW.Dom = factory(global)
	}
	function validateMapConstructors() {
		for (var mapIndex = 0, mapNamesLength = mapNames.length; mapIndex < mapNamesLength; ++mapIndex) {
			var name = mapNames[mapIndex],
				Constructor = primordials[name]
			if (!isNative(Constructor)) {
				primordials[name] = undefined
				continue
			}
			try {
				var map = new Constructor(),
					key = Object.freeze({}),
					other = {}
				if (
					!isNative(map.get) ||
					!isNative(map.set) ||
					!isNative(map.has) ||
					!isNative(map.delete) ||
					map.set(key, other) !== map ||
					map.get(key) !== other ||
					map.has(other) ||
					!map.delete(key) ||
					map.has(key)
				) {
					primordials[name] = undefined
				}
			} catch (_error) {
				primordials[name] = undefined
			}
		}
	}
})(
	this,
	(function () {
		var nwsapiFactory = (function () {
			//#region nwsapi:factory
			function Factory(global) {
				return Factory._core.createEngine(global, Factory)
			}
			//#endregion
			return Factory
		})()
		return nwsapiFactory
	})()
)

var originalFactory = module.exports;
module.exports = function (window) {
  var engine = originalFactory(window);
  engine.useNeuralPlanner("chromium");
  return engine;
};
Object.assign(module.exports, originalFactory);
